using System.Threading;
using System.Threading.Tasks;
using IBM.XMS;
using Microsoft.Extensions.Logging;
using SP.Core.Queues.IBMMQ;

namespace ServiceWithIBMMQ
{
  internal class QueueReaderConsumer : IBMIntegrationEventConsumer<QueueReaderEvent>
  {
    private readonly ILogger<QueueReaderConsumer> _logger;

    public QueueReaderConsumer(ILogger<QueueReaderConsumer> logger)
    {
      _logger = logger;
    }

    public QueueReaderEvent Event { get; set; }
    public string QueueName { get => "IMP.PAYMENT.TEST"; init { } }

    public Task HandleAsync(IMessage message, CancellationToken cancellationToken)
    {
      _logger.LogInformation(((ITextMessage)message).Text);
      message.Acknowledge();
      return Task.CompletedTask;
    }
  }
}