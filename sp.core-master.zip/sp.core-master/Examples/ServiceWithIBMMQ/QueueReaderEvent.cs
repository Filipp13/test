using System;
using SP.Core.Mediator;

namespace ServiceWithIBMMQ
{
  internal class QueueReaderEvent : IIntegrationEvent
  {
    public Guid Id { get; set; }
    public DateTime CreatedAt { get; set; }
  }
}