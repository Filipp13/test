using IBM.XMS;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using SP.Core.Queues.IBMMQ;

namespace ServiceWithIBMMQ
{
  public class Startup
  {
    public Startup(IConfiguration configuration)
    {
      Configuration = configuration;
    }

    public IConfiguration Configuration { get; }

    // This method gets called by the runtime. Use this method to add services to the container.
    public void ConfigureServices(IServiceCollection services)
    {

      services.AddEventConsumer<QueueReaderConsumer>();
      services.AddIbmMqConnection(XMSFactoryFactory.GetInstance(XMSC.CT_WMQ).CreateConnectionFactory(), Configuration.GetSection(IBMOptions.SectionName).Get<IBMOptions>());
      services.AddIbmMq(Configuration);

      services.AddControllers();
      services.AddSwaggerGen(c =>
      {
        c.SwaggerDoc("v1", new OpenApiInfo { Title = "ServiceWithIbmMq", Version = "v1" });
      });
    }

    // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
      if (env.IsDevelopment())
      {
        app.UseDeveloperExceptionPage();
        app.UseSwagger();
        app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "ServiceWithIbmMq v1"));
      }

      app.UseHttpsRedirection();

      app.UseRouting();

      app.UseAuthorization();

      app.UseEndpoints(endpoints =>
      {
        endpoints.MapControllers();
      });
    }


  }
  public static class Extension
  {
    public static IServiceCollection AddEventConsumer<TEventHandler>(
      this IServiceCollection services)
      where TEventHandler : class, IBMIntegrationEventConsumer
    {
      return services.AddTransient<IBMIntegrationEventConsumer, TEventHandler>();
    }
  }
}