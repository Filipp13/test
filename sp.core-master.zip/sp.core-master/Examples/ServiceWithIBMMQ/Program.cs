using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NLog;
using NLog.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServiceWithIBMMQ
{
  public class Program
  {
    public static void Main(string[] args)
    {

      var logger = NLogBuilder
        .ConfigureNLog("nlog.config").GetCurrentClassLogger();

      try
      {
        logger.Debug("The service has started.");
        CreateHostBuilder(args).Build().Run();
      }
      catch (Exception ex)
      {
        logger.Error(ex, "The service has stopped because of exception.");
        throw;
      }
      finally
      {
        logger.Debug("The service has stopped.");
        LogManager.Shutdown();
      }
    }

    public static IHostBuilder CreateHostBuilder(string[] args) =>
      Host.CreateDefaultBuilder(args)
        .ConfigureWebHostDefaults(webBuilder =>
        {
          webBuilder.UseStartup<Startup>();
        })
        .ConfigureLogging(logging => logging.ClearProviders())
        .UseNLog();
  }
}