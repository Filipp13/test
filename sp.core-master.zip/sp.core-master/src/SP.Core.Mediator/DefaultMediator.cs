﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SP.Core.Mediator.Seedwork;

namespace SP.Core.Mediator.Mediators
{
  /// <summary>
  ///   Представляет простую реализацию шаблона "Посредник".
  ///   <para>
  ///     Одно из применений типа - это реализация шаблона CQRS.
  ///     Класс спроектирован для упрощения реализации шаблона CQRS.
  ///   </para>
  /// </summary>
  /// <remarks>
  ///   Тип получает обработчики через механизм внедрения зависимостей в конструктор.
  ///   <para>
  ///     Для корректной работы рекомендуется регистрировать обработчики и самого посредника с объявленной областью
  ///     ServiceLifetime.Scoped.
  ///     Иначе возникает риск захвата службой с ServiceLifetime.Singleton служб с ServiceLifetime.Scoped.
  ///   </para>
  ///   <para>
  ///     Например DbContext EntityFramework по умолчанию регистрируется как Scoped.
  ///     Если разрешить эту зависимость в Singleton то время жизник DbContext повысится до времени жизни захватившей его
  ///     службы.
  ///   </para>
  ///   <para>
  ///     Использовать Transient так же не рекомендуется - это может привести к неверномум состоянию Scoped служб.
  ///     Кроме того разрешение Scoped служб, через Transient может привести к утечкам памяти.
  ///   </para>
  ///   Если требуется разрешить Scoped в одноилементной службе, тогда следует использовать внедрение в метод, а не
  ///   конструктор.
  /// </remarks>
  public class DefaultMediator : IMediator
  {
    private readonly ConcurrentBag<IMessageHandler> _handlers;

    /// <summary>
    ///   Инициализирует новый экземпляр класса <see cref="DefaultMediator" />.
    /// </summary>
    /// <param name="handlers">Коллекция обработчиков сообщений <see cref="IMessageHandler" />.</param>
    /// <exception cref="ArgumentNullException">
    ///   Возникает если значение параметра <paramref name="handlers" /> = <see langword="null" />.
    /// </exception>
    public DefaultMediator(IEnumerable<IMessageHandler> handlers)
    {
      _handlers = new ConcurrentBag<IMessageHandler>(handlers ?? throw new ArgumentNullException(nameof(handlers)));
    }

    /// <summary>
    ///   Асинхронно отправить сообщение.
    /// </summary>
    /// <remarks>
    ///   Отправляемые сообщения разделяются на команды и события.
    ///   "Посредник" гарантирует что у команд есть только один обработчик,
    ///   а у событий может быть 0 или бесконечное количество обработчиков.
    ///   "Посредник" также гарантирует, что команды и события не возвращают результат в вызывающий код.
    ///   Для возврата результата используйте запросы.
    /// </remarks>
    /// <param name="message">Ссылка на объект <see cref="IMessage" />.</param>
    /// <param name="cancellationToken">Значение <see cref="CancellationToken" /> для отмены задачи.</param>
    /// <typeparam name="TMessage">
    ///   Тип отправляемого сообщения.
    ///   Допустимые значения: класс реализующий <see cref="IEvent" /> или <see cref="ICommand" />.
    /// </typeparam>
    /// <exception cref="ArgumentNullException">
    /// Возникает если значение параметра <paramref name="message" /> = <see langword="null" />.
    /// </exception>
    /// <exception cref="InvalidOperationException">
    ///   Возникает если для <typeparamref name="TMessage" /> не зарегистрировано <see cref="IMessageHandler" />,
    ///   а также если для <typeparamref name="TMessage" /> реализующего <see cref="ICommand" /> зарегистрировано больше
    ///   одного <see cref="IMessageHandler" />.
    /// </exception>
    /// <returns>Ссылка на объект <see cref="Task" />.</returns>
    public Task SendMessageAsync<TMessage>(TMessage message, CancellationToken cancellationToken = default)
      where TMessage : class, IMessage
    {
      return message switch
      {
        null => throw new ArgumentNullException(nameof(message)),
        IEvent => PublishEventAsync(message, cancellationToken),
        ICommand => ExecuteCommandAsync(message, cancellationToken),
        _ => throw new ArgumentOutOfRangeException(nameof(message), message, "Unsupported message type.")
      };
    }

    /// <summary>
    ///   Асинхронно отправить сообщение.
    /// </summary>
    /// <remarks>
    ///   Отправляемые сообщения представляют запросы.
    ///   "Посредник" гарантирует что у запроса есть только один обработчик.
    ///   "Посредник" также гарантирует, что на запрос <typeparamref name="TMessage"/>
    ///   будет возвращён результат указанного типа <typeparamref name="TResponse"/>.
    /// </remarks>
    public Task<TResponse?> SendMessageAsync<TMessage, TResponse>(TMessage message,
      CancellationToken cancellationToken = default)
      where TMessage : class, IMessage
    {
      return message switch
      {
        null => throw new ArgumentNullException(nameof(message)),
        IRequest _ => SendRequestAsync<TMessage, TResponse?>(message, cancellationToken),
        _ => throw new ArgumentOutOfRangeException(nameof(message), message, "Unsupported message type.")
      };
    }

    /// <inheritdoc />
    /// <exception cref="T:System.ArgumentNullException" />
    /// <exception cref="T:ViennaNET.Mediator.Exceptions.UnsupportedTypeMessageException" />
    public void SendMessage<TMessage>(TMessage message) where TMessage : class, IMessage
    {
      switch (message)
      {
        case null:
          throw new ArgumentNullException(nameof(message));
        case IEvent _:
          PublishEvent(message);
          break;
        case ICommand _:
          ExecuteCommand(message);
          break;
        default:
          throw new ArgumentOutOfRangeException(nameof(message), message, "Unsupported message type.");
      }
    }

    /// <inheritdoc />
    /// <exception cref="T:System.ArgumentNullException" />
    /// <exception cref="T:ViennaNET.Mediator.Exceptions.UnsupportedTypeMessageException" />
    public TResponse? SendMessage<TMessage, TResponse>(TMessage message) where TMessage : class, IMessage
    {
      return message switch
      {
        null => throw new ArgumentNullException(nameof(message)),
        IRequest _ => SendRequest<TMessage, TResponse>(message),
        _ => throw new ArgumentOutOfRangeException(nameof(message), message, "Unsupported message type.")
      };
    }

    private Task PublishEventAsync<TEvent>(TEvent @event, CancellationToken cancellationToken = default)
      where TEvent : class, IMessage
      => Task.WhenAll(_handlers.OfType<IMessageHandlerAsync<TEvent>>()
        .Select(handler => handler.HandleAsync(@event, cancellationToken)));

    private void PublishEvent<TEvent>(TEvent evt) where TEvent : class, IMessage
      => _handlers.OfType<IMessageHandler<TEvent>>().ToList().ForEach(handler => handler.Handle(evt));

    private Task ExecuteCommandAsync<TCommand>(TCommand command, CancellationToken cancellationToken = default)
      where TCommand : class, IMessage
      => _handlers.OfType<IMessageHandlerAsync<TCommand>>().Single().HandleAsync(command, cancellationToken);

    private void ExecuteCommand<TCommand>(TCommand command) where TCommand : class, IMessage
      => _handlers.OfType<IMessageHandler<TCommand>>().Single().Handle(command);

    private Task<TResponse?> SendRequestAsync<TRequest, TResponse>(
      TRequest request, CancellationToken cancellationToken = default) where TRequest : class, IMessage
      => _handlers.OfType<IMessageHandlerAsync<TRequest, TResponse>>().Single().HandleAsync(request, cancellationToken);

    private TResponse? SendRequest<TRequest, TResponse>(TRequest request) where TRequest : class, IMessage
      => _handlers.OfType<IMessageHandler<TRequest, TResponse>>().Single().Handle(request);
  }
}