﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("SP.Core.Mediator.Tests")]