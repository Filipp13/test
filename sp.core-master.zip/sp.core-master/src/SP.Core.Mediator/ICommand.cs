﻿using SP.Core.Mediator.Seedwork;

namespace SP.Core.Mediator
{
  /// <summary>
  ///   Интерфейс-маркер, определяющий команду.
  /// </summary>
  public interface ICommand : IMessage
  {
  }
}