using System;
using SP.Core.Mediator.Seedwork;

namespace SP.Core.Mediator
{
  /// <summary>
  /// Представляет событие интеграции.
  /// </summary>
  public interface IIntegrationEvent : IEvent
  {
    /// <summary>
    /// Получает или задаёт уникальный идентификатор события.
    /// </summary>
    public Guid Id { get; set; }
    
    /// <summary>
    /// Получает или задаёт момент создания события.
    /// </summary>
    public DateTime CreatedAt { get; set; }
  }
}