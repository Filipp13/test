﻿using SP.Core.Mediator.Seedwork;

namespace SP.Core.Mediator
{
  /// <summary>
  ///   Интерфейс-маркер, определяющий запрос
  /// </summary>
  public interface IRequest : IMessage
  {
  }
}