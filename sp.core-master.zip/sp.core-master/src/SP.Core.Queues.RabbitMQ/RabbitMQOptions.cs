using System.Collections.Generic;
using RabbitMQ.Client;

namespace SP.Core.Queues.RabbitMQ
{
  /// <summary>
  /// Представляет параметры конечной точки RabbitMQ.
  /// </summary>
  public class RabbitMQOptions
  {
    /// <summary>
    ///   Получает наименование секции в конфигурации приложения.
    /// </summary>
    public static readonly string SectionName = "Endpoints:RabbitMQ";

    public RabbitMQOptions()
    {
      Exchanges = new []{new RabbitMQExchangeOptions()
      {
        Name = string.Empty,
        Type = ExchangeType.Direct,
        Queues = new []
        {
          new RabbitMQQueueOptions()
          {
            
          }
        }
      }};
    }

    /// <summary>
    ///   Базовый адрес.
    ///   Значение по умолчанию amqp://guest:guest@localhost:5672.
    /// </summary>
    public string BaseAddress { get; set; } = "amqp://guest:guest@localhost:5672";

    /// <summary>
    ///   Получает или задаёт колекцию параметров обменов.
    /// </summary>
    public IEnumerable<RabbitMQExchangeOptions> Exchanges { get; set; }

    /// <summary>
    ///   Получает или задаёт общее время ожидания для всех попыток в секундах.
    /// </summary>
    public int OverallTimeout { get; set; } = 60;

    /// <summary>
    ///   Получает или задаёт время ожидания для каждой отдельной попыти в секундах.
    /// </summary>
    /// <remarks>
    ///   Общее время выполнения запроса ограничено значением <see cref="OverallTimeout" />.
    ///   Независимо от количества повторных попыток.
    /// </remarks>
    public int TryTimeout { get; set; } = 3;

    /// <summary>
    ///   Получает или задаёт время задержки первой повторной попытки в секундах.
    /// </summary>
    /// <remarks>
    ///   Последующие попытки будут выполняться с экспоненциальной задержкой.
    /// </remarks>
    public int RetryDelay { get; set; } = 3;

    /// <summary>
    ///   Задаёт максимальное количество повторных попыток.
    /// </summary>
    public int RetryCount { get; set; } = 10;
  }
}