using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace SP.Core.Queues.RabbitMQ
{
  /// <summary>
  /// 
  /// </summary>
  public class RabbitMQHostedService : IHostedService
  {
    private readonly IConnection _connection;
    private readonly ILogger<RabbitMQHostedService> _logger;
    private readonly IOptions<RabbitMQOptions> _options;

    /// <summary>
    /// 
    /// </summary>
    /// <param name="connection"></param>
    /// <param name="logger"></param>
    /// <param name="options"></param>
    public RabbitMQHostedService(
      IConnection connection,
      ILogger<RabbitMQHostedService> logger,
      IOptions<RabbitMQOptions> options)
    {
      _connection = connection ?? throw new ArgumentNullException(nameof(connection));
      _logger = logger ?? throw new ArgumentNullException(nameof(logger));
      _options = options ?? throw new ArgumentNullException(nameof(options));
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    /// <exception cref="NotImplementedException"></exception>
    public Task StartAsync(CancellationToken cancellationToken)
    {
      if (_options.Value is null)
      {
        return Task.CompletedTask;
      }

      _connection.ConnectionShutdown += ConnectionOnConnectionShutdown;
      _connection.ConnectionBlocked += ConnectionOnConnectionBlocked;
      _connection.ConnectionUnblocked += ConnectionOnConnectionUnblocked;

      return Task.CompletedTask;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    /// <exception cref="NotImplementedException"></exception>
    public Task StopAsync(CancellationToken cancellationToken)
    {
      return Task.CompletedTask;
    }

    [SuppressMessage("ReSharper", "AccessToDisposedClosure")]
    private void RestoreTopology()
    {
      using IModel channel = _connection.CreateModel();

      if (channel is null)
      {
        throw new InvalidOperationException("Failed to restore topology, channel is null.");
      }

      foreach (var exchange in _options.Value.Exchanges)
      {
        channel.ExchangeDeclare(
          exchange.Name, exchange.Type, exchange.Durable, exchange.AutoDelete, exchange.Arguments);

        var results = exchange.Queues
          .Select(queue =>
            channel.QueueDeclare(queue.Name, queue.Durable, queue.Exclusive, queue.AutoDelete, queue.Arguments))
          .ToList();

        results.ForEach(result => _logger.LogDebug(
          "Queue {QueueName} has been declared. Current consumers {ConsumerCount} and messages in queue {MessageCount}",
          result.QueueName, result.ConsumerCount, result.MessageCount));
      }
    }

    private void ConnectionOnConnectionShutdown(object? sender, ShutdownEventArgs e)
      => _logger.LogWarning(e.ReplyCode, "RabbitMQ connection has been shutdown for reason: {Reason}", e.ReplyText);

    private void ConnectionOnConnectionBlocked(object? sender, ConnectionBlockedEventArgs e)
      => _logger.LogWarning("RabbitMQ connection has been blocked for {Reason}", e.Reason);

    private void ConnectionOnConnectionUnblocked(object? sender, EventArgs e)
      => _logger.LogWarning("RabbitMQ connection has been unblocked. The service resumed sending messages");
  }
}