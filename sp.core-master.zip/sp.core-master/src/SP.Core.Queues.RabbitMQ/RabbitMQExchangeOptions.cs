﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace SP.Core.Queues.RabbitMQ
{
  /// <summary>
  /// Представляет параметры обмена RabbitMQ.
  /// </summary>
  [SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
  public class RabbitMQExchangeOptions
  {
    /// <summary>
    /// Получает или задаёт наименование.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Получает или задаёт тип. Значение по умолчанию "direct".
    /// </summary>
    public string Type { get; set; } = "direct";

    /// <summary>
    /// Получает или задаёт признак долговечности, определяющий выдержит ли обмен перезапуск брокера.
    /// Значение по умолчанию <see langword="true"/>.
    /// </summary>
    public bool Durable { get; set; } = true;

    /// <summary>
    /// Получает или задаёт признак автоматичекого удаления, определяющий
    /// удаляется ли обмен, когда от него отвязывается последняя очередь.
    /// Значение по умолчанию <see langword="false"/>.
    /// </summary>
    public bool AutoDelete { get; set; } = false;

    /// <summary>
    /// Получает или задаёт массив не обязательных аргументов обмена.
    /// </summary>
    /// <remarks>
    /// Используются плагинами и функциями брокера.
    /// </remarks>
    public IDictionary<string, object>? Arguments { get; set; }

    /// <summary>
    ///   Получает или задаёт коллекцию очередей связанных с обменом.
    /// </summary>
    public IEnumerable<RabbitMQQueueOptions> Queues { get; set; }
  }
}