using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace SP.Core.Queues.RabbitMQ
{
  /// <summary>
  /// Представляет параметры очереди сообщений RabbitMQ.
  /// </summary>
  [SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
  public class RabbitMQQueueOptions
  {
    /// <summary>
    /// Получает или задаёт наименование очереди.
    /// Значение по умолчанию: пустая строка.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Получает или задаёт массив ключей маршрутизации.
    /// </summary>
    public string[]? RoutingKeys { get; set; }

    /// <summary>
    /// Получает или задаёт признак долговечности, определяющий выдержит ли очередь перезапуск брокера.
    /// Значение по умолчанию <see langword="true"/>.
    /// </summary>
    public bool Durable { get; set; } = true;

    /// <summary>
    /// Получает или задаёт признак эксклюзивности, определяющий
    /// используется ли очередь только одним соединением,
    /// и будет удалена при закрытии этого соединения.
    /// Значение по умолчанию <see langword="false"/>.
    /// </summary>
    public bool Exclusive { get; set; } = false;

    /// <summary>
    /// Получает или задаёт признак автоматичекого удаления, определяющий
    /// удаляется ли очередь, когда последний потребитель откажется от подписки.
    /// Значение по умолчанию <see langword="false"/>.
    /// </summary>
    public bool AutoDelete { get; set; } = false;

    /// <summary>
    /// Получает или задаёт массив не обязательных аргументов очереди.
    /// </summary>
    /// <remarks>
    /// Используются плагинами и специфичными для брокера функциями,
    /// такими как TTL сообщения, ограничение длины очереди и т. д.
    /// </remarks>
    public IDictionary<string, object>? Arguments { get; set; }
  }
}