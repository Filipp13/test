using System;
using System.Linq;
using NUnit.Framework;

namespace SP.Core.Utils.Tests
{
  [TestFixture(Category = "Unit", TestOf = typeof(GenericUtilitiesTests))]
  public class GenericUtilitiesTests
  {
    private const string TestStringValue = "test string value";
    private const string TestAlternateStringValue = "test alternate string value";
    private const int TestIntValue = 0;
    private const int TestAlternateIntValue = 1;

    [TestCase(null)]
    [TestCase(TestStringValue)]
    [TestCase(TestAlternateStringValue)]
    public void NullableReferenceTypeThrowIf(string? instance)
    {
      var exception = new InvalidOperationException();
      var predicate = new Predicate<string?>(obj => obj == TestStringValue);

      switch (instance)
      {
        case null:
          Assert.AreEqual(null, instance.ThrowIf(predicate, exception));
          break;
        case TestStringValue:
          Assert.Throws<InvalidOperationException>(() => instance.ThrowIf(predicate, exception));
          break;
        default:
          Assert.AreEqual(instance, instance.ThrowIf(predicate, exception));
          break;
      }
    }

    [TestCase(null)]
    [TestCase(TestIntValue)]
    [TestCase(TestAlternateIntValue)]
    public void NullableValueTypeThrowIf(int? data)
    {
      var exception = new InvalidOperationException();
      var predicate = new Predicate<int?>(value => value == TestIntValue);

      switch (data)
      {
        case null:
          Assert.AreEqual(null, data.ThrowIf(predicate, exception));
          break;
        case TestIntValue:
          Assert.Throws<InvalidOperationException>(() => data.ThrowIf(predicate, exception));
          break;
        default:
          Assert.AreEqual(data, data.ThrowIf(predicate, exception));
          break;
      }
    }

    [TestCase(null)]
    [TestCase(TestStringValue)]
    [TestCase(TestAlternateStringValue)]
    public void NullableReferenceTypeThrowIfWithCallback(string? instance)
    {
      var callback = new Func<string?, InvalidOperationException>(obj => throw new InvalidOperationException());
      var predicate = new Predicate<string?>(obj => obj == TestStringValue);

      switch (instance)
      {
        case null:
          Assert.AreEqual(null, instance.ThrowIf(predicate, callback));
          break;
        case TestStringValue:
          Assert.Throws<InvalidOperationException>(() => instance.ThrowIf(predicate, callback));
          break;
        default:
          Assert.AreEqual(instance, instance.ThrowIf(predicate, callback));
          break;
      }
    }

    [TestCase(null)]
    [TestCase(TestIntValue)]
    [TestCase(TestAlternateIntValue)]
    public void NullableValueTypeThrowIfWithCallback(int? data)
    {
      var callback = new Func<int?, InvalidOperationException>(obj => throw new InvalidOperationException());
      var predicate = new Predicate<int?>(value => value == TestIntValue);

      switch (data)
      {
        case null:
          Assert.AreEqual(null, data.ThrowIf(predicate, callback));
          break;
        case TestIntValue:
          Assert.Throws<InvalidOperationException>(() => data.ThrowIf(predicate, callback));
          break;
        default:
          Assert.AreEqual(data, data.ThrowIf(predicate, callback));
          break;
      }
    }

    [TestCase(null)]
    [TestCase(TestStringValue)]
    [TestCase(TestAlternateStringValue)]
    public void NullableReferenceTypeThrowIfNot(string? instance)
    {
      var exception = new InvalidOperationException();
      var predicate = new Predicate<string?>(obj => obj == TestAlternateStringValue);

      switch (instance)
      {
        case null:
          Assert.AreEqual(null, instance.ThrowIfNot(predicate, exception));
          break;
        case TestStringValue:
          Assert.Throws<InvalidOperationException>(() => instance.ThrowIfNot(predicate, exception));
          break;
        default:
          Assert.AreEqual(instance, instance.ThrowIfNot(predicate, exception));
          break;
      }
    }

    [TestCase(null)]
    [TestCase(TestIntValue)]
    [TestCase(TestAlternateIntValue)]
    public void NullableValueTypeThrowIfNot(int? instance)
    {
      var exception = new InvalidOperationException();
      var predicate = new Predicate<int?>(value => value == TestAlternateIntValue);

      switch (instance)
      {
        case null:
          Assert.AreEqual(null, instance.ThrowIfNot(predicate, exception));
          break;
        case TestIntValue:
          Assert.Throws<InvalidOperationException>(() => instance.ThrowIfNot(predicate, exception));
          break;
        default:
          Assert.AreEqual(instance, instance.ThrowIfNot(predicate, exception));
          break;
      }
    }

    [TestCase(null)]
    [TestCase(TestStringValue)]
    [TestCase(TestAlternateStringValue)]
    public void NullableReferenceTypeThrowIfNotWithCallback(string? instance)
    {
      var callback = new Func<string?, InvalidOperationException>(obj => throw new InvalidOperationException());
      var predicate = new Predicate<string?>(obj => obj == TestAlternateStringValue);

      switch (instance)
      {
        case null:
          Assert.AreEqual(null, instance.ThrowIfNot(predicate, callback));
          break;
        case TestStringValue:
          Assert.Throws<InvalidOperationException>(() => instance.ThrowIfNot(predicate, callback));
          break;
        default:
          Assert.AreEqual(instance, instance.ThrowIfNot(predicate, callback));
          break;
      }
    }

    [TestCase(null)]
    [TestCase(TestIntValue)]
    [TestCase(TestAlternateIntValue)]
    public void NullableValueTypeThrowIfNotWithCallback(int? data)
    {
      var callback = new Func<int?, InvalidOperationException>(_ => throw new InvalidOperationException());
      var predicate = new Predicate<int?>(value => value == TestAlternateIntValue);

      switch (data)
      {
        case null:
          Assert.AreEqual(null, data.ThrowIfNot(predicate, callback));
          break;
        case TestIntValue:
          Assert.Throws<InvalidOperationException>(() => data.ThrowIfNot(predicate, callback));
          break;
        default:
          Assert.AreEqual(data, data.ThrowIfNot(predicate, callback));
          break;
      }
    }

    [TestCase(null)]
    [TestCase(TestStringValue)]
    public void At(string? instance)
    {
      switch (instance)
      {
        case null:
          Assert.AreEqual(default, instance?.ToArray().At(2, @char => @char + 10, default));
          break;
        case TestStringValue:
          Assert.AreEqual(instance.ElementAt(2) + 10, instance.ToArray().At(2, @char => @char + 10, default));
          break;
      }
    }

    [TestCase(null)]
    [TestCase(TestStringValue)]
    public void Do(string? instance)
    {
      var length = 0;

      switch (instance)
      {
        case null:
          instance.Do(s => length = s!.Length);
          Assert.AreEqual(0, length);
          break;
        case TestStringValue:
          instance.Do(s => length = s.Length);
          Assert.AreEqual(instance.Length, length);
          break;
      }
    }

    [TestCase(null)]
    [TestCase(TestIntValue)]
    public void Do(int? value)
    {
      const int increment = 10;
      var sum = 0;

      switch (value)
      {
        case null:
          value.Do(v => sum = v!.Value + increment);
          Assert.AreEqual(0, sum);
          break;
        case TestIntValue:
          value.Do(v => sum = v!.Value + increment);
          Assert.AreEqual(increment, sum);
          break;
      }
    }

    [TestCase(null)]
    [TestCase(TestStringValue)]
    public void If(string? instance)
    {
      switch (instance)
      {
        case null:
          Assert.AreEqual(null, instance.If(v => v!.Length > 0));
          break;
        case TestStringValue:
          Assert.AreEqual(instance, instance.If(v => v!.Length > 0));
          break;
      }
    }

    [TestCase(null)]
    [TestCase(TestIntValue)]
    public void If(int? value)
    {
      switch (value)
      {
        case null:
          Assert.AreEqual(null, value.If(v => v.HasValue));
          break;
        case TestIntValue:
          Assert.AreEqual(0, value.If(v => v.HasValue));
          break;
      }
    }
  }
}