using System;
using SP.Core.Mediator;

namespace Helpers
{
  public class QueueReaderEvent : IIntegrationEvent
  {
    public Guid Id { get; set; }
    public DateTime CreatedAt { get; set; }
  }
}