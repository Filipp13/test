using System;

namespace Helpers
{
  public class ConsumerException: Exception
  {
  }
}