using System.Threading;
using System.Threading.Tasks;
using IBM.XMS;
using SP.Core.Queues.IBMMQ;

namespace Helpers
{
  public class QueueReaderConsumer : IBMIntegrationEventConsumer<QueueReaderEvent>
  {

    public QueueReaderConsumer()
    {}

    public QueueReaderEvent Event { get; set; }
    public string QueueName { get => "test"; init { } }

    public Task HandleAsync(IMessage message, CancellationToken cancellationToken)
    {
      message.Acknowledge();
      throw new ConsumerException();
    }
  }
}