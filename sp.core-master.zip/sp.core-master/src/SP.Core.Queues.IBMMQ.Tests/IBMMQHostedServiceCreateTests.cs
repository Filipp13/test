using System;
using System.Collections.Generic;
using Helpers;
using IBM.XMS;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;

namespace SP.Core.Queues.IBMMQ.Tests
{
  public class IBMMQHostedServiceCreateTests
  {
    [Test]
    public void New_IbmMqHostedService_MissingLogger_ArgumentNullException()
    {
      var ibmOptions = new Mock<IOptions<IBMOptions>>();


      var consumers = new Mock<IEnumerable<IBMIntegrationEventConsumer>>();


      var connection = new Mock<IConnection>();

      var ex = Assert.Throws<ArgumentNullException>(() => new IBMMQHostedService(
            null,
            ibmOptions.Object,
            consumers.Object,
            connection.Object));

      Assert.That(ex.ParamName, Is.EqualTo("logger"));
    }

    [Test]
    public void New_IbmMqHostedService_MissingIbmOptions_ArgumentNullException()
    {
      var logger = new Mock<ILogger<IBMMQHostedService>>();

      var consumers = new Mock<IEnumerable<IBMIntegrationEventConsumer>>();

      var connection = new Mock<IConnection>();

      var ex = Assert.Throws<ArgumentNullException>(() => new IBMMQHostedService(
            logger.Object,
            null,
            consumers.Object,
            connection.Object));

      Assert.That(ex.ParamName, Is.EqualTo("options"));
    }

    [Test]
    public void New_IbmMqHostedService_MissingConsumers_ArgumentNullException()
    {
      var logger = new Mock<ILogger<IBMMQHostedService>>();

      var ibmOptions = new Mock<IOptions<IBMOptions>>();


      var connection = new Mock<IConnection>();

      var ex = Assert.Throws<ArgumentNullException>(() => new IBMMQHostedService(
            logger.Object,
            ibmOptions.Object,
            null,
            connection.Object));

      Assert.That(ex.ParamName, Is.EqualTo("consumers"));
    }

    [Test]
    public void New_IbmMqHostedService_MissingConnection_ArgumentNullException()
    {
      var logger = new Mock<ILogger<IBMMQHostedService>>();

      var ibmOptions = Options.Create(new IBMOptions { 
       HostedServiceOptions = new HostedServiceOptions { }
      });

      var consumer1 = new Mock<QueueReaderConsumer>();

      var consumer2 = new Mock<QueueReaderConsumerMod>();

      var consumers = new Mock<IEnumerable<IBMIntegrationEventConsumer>>();

      var ex = Assert.Throws<ArgumentNullException>(() => new IBMMQHostedService(
            logger.Object,
            ibmOptions,
            new IBMIntegrationEventConsumer[] { consumer1.Object, consumer2.Object },
            null));

      Assert.That(ex.ParamName, Is.EqualTo("connection"));
    }
  }
}