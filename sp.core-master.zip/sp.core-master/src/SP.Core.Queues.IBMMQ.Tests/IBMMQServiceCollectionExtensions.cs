using System;
using IBM.XMS;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using NUnit.Framework;

namespace SP.Core.Queues.IBMMQ.Tests
{
public class IbmMqServiceCollectionExtensionsTests
  {

    [Test]
    public void AddIbmMq_MissingConfiguration_ArgumentNullException()
    {
      var services = new ServiceCollection();
      var ex = Assert.Throws<ArgumentNullException>(() => services.AddIbmMq(null!));
      Assert.That(ex.ParamName, Is.EqualTo("configuration"));
    }

    [Test]
    public void AddIbmMq_MissingConfigurationSection_ArgumentNullException()
    {
      var services = new ServiceCollection();
      var ex = Assert.Throws<ArgumentNullException>(() => services.AddIbmMq(Mock.Of<IConfiguration>()));
      Assert.That(ex.ParamName, Is.EqualTo(IBMOptions.SectionName));
    }

    [Test]
    public void AddIbmMqConnection_MissingIbmOptions_ArgumentNullException()
    {
      var services = new ServiceCollection();
      var ex = Assert.Throws<ArgumentNullException>(() => services.AddIbmMqConnection(Mock.Of<IConnectionFactory>(), null!));
      Assert.That(ex.ParamName, Is.EqualTo("ibmOptions"));
    }

    [Test]
    public void AddIbmMqConnection_ConnectionFactory_Call_CreateConnection()
    {
      var services = new ServiceCollection();
      var mockConnectionFactory = new Mock<IConnectionFactory>();

      services.AddIbmMqConnection(mockConnectionFactory.Object, new IBMOptions { });

      mockConnectionFactory.Verify(connectionFactory => connectionFactory.SetStringProperty(XMSC.WMQ_HOST_NAME, It.IsAny<string>()), Times.Once);
      mockConnectionFactory.Verify(connectionFactory => connectionFactory.SetStringProperty(XMSC.WMQ_CHANNEL, It.IsAny<string>()), Times.Once);
      mockConnectionFactory.Verify(connectionFactory => connectionFactory.SetStringProperty(XMSC.WMQ_QUEUE_MANAGER, It.IsAny<string>()), Times.Once);

      mockConnectionFactory.Verify(connectionFactory => connectionFactory.SetIntProperty(XMSC.WMQ_PORT, It.IsAny<int>()), Times.Once);
      mockConnectionFactory.Verify(connectionFactory => connectionFactory.SetIntProperty(XMSC.WMQ_CONNECTION_MODE, XMSC.WMQ_CM_CLIENT), Times.Once);


      mockConnectionFactory.Verify(connectionFactory => connectionFactory.CreateConnection(), Times.Once);
    }
  }
}