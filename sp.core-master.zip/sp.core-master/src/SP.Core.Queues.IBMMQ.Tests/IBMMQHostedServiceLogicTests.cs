using System;
using System.Threading;
using System.Threading.Tasks;
using Helpers;
using IBM.XMS;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;

namespace SP.Core.Queues.IBMMQ.Tests
{
  public class IBMMQHostedServiceLogicTests
  {
    [Test]
    public async Task IbmMqHostedService_StartAsync_Test()
    {
      var logger = new Mock<ILogger<IBMMQHostedService>>();

      var ibmOptions = Options.Create(new IBMOptions
      {
        BaseAddress = "baseadrress",
        Channel = "channel",
        Port = 1500,
        QueueManager = "queueManager",
        QueueNames = new string[] { "test" },
        HostedServiceOptions = new HostedServiceOptions
        {
          ConcurrencyLevel = 1,
          WorkRepeatDelay = new TimeSpan(0, 0, 5)
        }

      });

      var consumer1 = new Mock<QueueReaderConsumer>();

      var consumer2 = new Mock<QueueReaderConsumerMod>();

      var messageMoc = GetMessage();

      var consumerMock = GetMessageConsumer(messageMoc.Object);

      var sessionMock = GetSession(consumerMock.Object);

      var connection = new Mock<IConnection>();

      connection.Setup(c => c.CreateSession(false, AcknowledgeMode.ClientAcknowledge))
          .Returns(sessionMock.Object);

      var ibmMqHostedService = new IBMMQHostedService(
            logger.Object,
            ibmOptions,
            new IBMIntegrationEventConsumer[] { consumer1.Object, consumer2.Object },
            connection.Object);


      await ibmMqHostedService.StartAsync(CancellationToken.None);

      connection.Verify(connection => connection.CreateSession(false, AcknowledgeMode.ClientAcknowledge), Times.Once);

      //sessionMock.Verify(session => session.CreateConsumer(It.IsAny<IDestination>()), Times.Once);

      //consumerMock.Verify(consumer => consumer.ReceiveNoWait(), Times.Once);

      //messageMoc.Verify(m => m.Acknowledge(), Times.Once);
    }


    [Test]
    public async Task IbmMqHostedService_StopAsync_Test()
    {
      var logger = new Mock<ILogger<IBMMQHostedService>>();

      var ibmOptions = Options.Create(new IBMOptions
      {
        BaseAddress = "baseadrress",
        Channel = "channel",
        Port = 1500,
        QueueManager = "queueManager",
        QueueNames = new string[] { "test" }

      });

      var hostedOptions = Options.Create(new HostedServiceOptions
      {
        ConcurrencyLevel = 1,
        WorkRepeatDelay = new TimeSpan(0, 0, 5)
      });

      var consumers = new Mock<QueueReaderConsumer>();


      var messageMoc = GetMessage();

      var consumerMock = GetMessageConsumer(messageMoc.Object);

      var sessionMock = GetSession(consumerMock.Object);

      var connection = new Mock<IConnection>();

      connection.Setup(c => c.CreateSession(false, AcknowledgeMode.ClientAcknowledge))
        .Returns(sessionMock.Object);

      connection.Setup(c => c.Close());

      var ibmMqHostedService = new IBMMQHostedService(
            logger.Object,
            ibmOptions,
            new IBMIntegrationEventConsumer[] { consumers.Object },
            connection.Object);

      await ibmMqHostedService.StartAsync(CancellationToken.None);

      await ibmMqHostedService.StopAsync(CancellationToken.None);

      connection.Verify(connection => connection.Close(), Times.Once);

      sessionMock.Verify(session => session.Close(), Times.Once);

    }

    private Mock<ISession> GetSession(IMessageConsumer messageConsumer)
    {
      var sessionMock = new Mock<ISession>();
      sessionMock.Setup(s => s.CreateQueue(It.IsAny<string>()))
      .Returns(GetDestination());

      sessionMock.Setup(s => s.CreateConsumer(It.IsAny<IDestination>()))
        .Returns(messageConsumer);

      sessionMock.Setup(s => s.Close());
      return sessionMock;
    }

    private IDestination GetDestination()
    {
      var d = new Mock<IDestination>();

      return d.Object;
    }

    private Mock<IMessageConsumer> GetMessageConsumer(IMessage message)
    {
      var consumer = new Mock<IMessageConsumer>();
      consumer.Setup(c => c.ReceiveNoWait())
        .Returns(message);

      return consumer;
    }

    private Mock<IMessage> GetMessage()
    {
      var message = new Mock<IMessage>();
      return message;
    }
  }
}