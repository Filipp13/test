﻿using SP.Core.Validation.Tests.Data;
using SP.Core.Validation.Validators;

namespace SP.Core.Validation.Tests.RuleValidation
{
  internal class FluentRuleRuleSet : BaseValidationRuleSet<IMainEntity>
  {
    public FluentRuleRuleSet(FluentRule rule)
    {
      SetRule(rule);
    }
  }
}