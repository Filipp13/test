﻿using SP.Core.Validation.Tests.Data;
using SP.Core.Validation.Validators;

namespace SP.Core.Validation.Tests.RuleValidation.When
{
  internal class WhenRuleSet : BaseValidationRuleSet<IMainEntity>
  {
    public WhenRuleSet()
    {
      SetRule(new WhenRule());
    }
  }
}