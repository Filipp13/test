﻿using SP.Core.Validation.Tests.Data;
using SP.Core.Validation.Validators;

namespace SP.Core.Validation.Tests.RuleValidation.When
{
  internal class LoadingWhenRuleSet : BaseValidationRuleSet<IMainEntity>
  {
    public LoadingWhenRuleSet(IDbAccessor accessor)
    {
      When(new AccountTypeRule(accessor),
        () => SetRule(new ContractAccountRule(accessor)));
    }
  }
}