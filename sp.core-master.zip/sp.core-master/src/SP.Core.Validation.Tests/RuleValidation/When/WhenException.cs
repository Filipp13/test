﻿using System;

namespace SP.Core.Validation.Tests.RuleValidation.When
{
  public sealed class WhenException : Exception
  {
    public WhenException(string message, params object[] args)
      : base(string.Format(message, args))
    {
    }

    public WhenException(Exception innerException, string message, params object[] args)
      : base(string.Format(message, args), innerException)
    {
    }
  }
}