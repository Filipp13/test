﻿using SP.Core.Validation.Tests.Data;
using SP.Core.Validation.Validators;

namespace SP.Core.Validation.Tests.RuleValidation
{
  internal class LoadingDependsOnRuleSet : BaseValidationRuleSet<IMainEntity>
  {
    public LoadingDependsOnRuleSet(IDbAccessor accessor)
    {
      SetRule(new ContractAccountRule(accessor)).DependsOn(new AccountTypeRule(accessor));

      SetCollectionContext(x => x.Salaries, new SalaryLoadingRuleSet());
    }
  }
}