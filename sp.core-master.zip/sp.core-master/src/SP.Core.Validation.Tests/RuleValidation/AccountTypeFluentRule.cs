﻿using SP.Core.Validation.Rules.FluentRule;
using SP.Core.Validation.Tests.Data;

namespace SP.Core.Validation.Tests.RuleValidation
{
  internal class AccountTypeFluentRule : BaseFluentRule<IAccInfo>
  {
    public AccountTypeFluentRule()
    {
      ForProperty(a => a.Account)
        .NotNull()
        .WithErrorMessage("Account is null");
      ForProperty(a => a.AccountCba)
        .NotNull()
        .WithErrorMessage("AccountCba is null");
      ForProperty(a => a.AccountType)
        .NotNull()
        .WithErrorMessage("AccountType is null");
    }
  }
}