﻿using SP.Core.Validation.Rules;
using SP.Core.Validation.Rules.ValidationResults;
using SP.Core.Validation.Rules.ValidationResults.RuleMessages;
using SP.Core.Validation.Tests.Data;

namespace SP.Core.Validation.Tests.RuleValidation
{
  internal class ContractAccountRule : BaseRule<IMainEntity>
  {
    private const string InternalCode = "CPAY2";
    private readonly IDbAccessor _dbAccessor;

    public ContractAccountRule(IDbAccessor accessor)
      : base(InternalCode)
    {
      _dbAccessor = accessor;
    }

    public override RuleValidationResult Validate(IMainEntity entity, ValidationContext context)
    {
      if (_dbAccessor.GetContractAccount(entity.ContractId, entity.AccountsInfo.AccountCba) == null)
      {
        return new RuleValidationResult(Identity, new ErrorRuleMessage(new MessageIdentity("CPAY2M1"),
          string.Format("Не найден счёт {0} для договора {1}",
            entity.AccountsInfo.AccountCba,
            entity.ContractId)));
      }

      return null;
    }
  }
}