﻿using SP.Core.Validation.Rules.FluentRule;
using SP.Core.Validation.Tests.Data;

namespace SP.Core.Validation.Tests.RuleValidation
{
  internal class UseIRuleFluentRule : BaseFluentRule<IMainEntity>
  {
    public UseIRuleFluentRule()
    {
      ForProperty(e => e.AccountsInfo)
        .UseRule(new AccountTypeFluentRule());
    }
  }
}