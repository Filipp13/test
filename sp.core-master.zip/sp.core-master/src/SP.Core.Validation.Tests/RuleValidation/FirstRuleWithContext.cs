﻿using SP.Core.Validation.Rules;
using SP.Core.Validation.Rules.ValidationResults;
using SP.Core.Validation.Tests.Data;

namespace SP.Core.Validation.Tests.RuleValidation
{
  internal class FirstRuleWithContext : BaseRule<IMainEntity>
  {
    private const string InternalCode = "CPAY11";

    public FirstRuleWithContext()
      : base(InternalCode)
    {
    }

    public override RuleValidationResult Validate(IMainEntity value, ValidationContext context)
    {
      context.Context = 10;
      return null;
    }
  }
}