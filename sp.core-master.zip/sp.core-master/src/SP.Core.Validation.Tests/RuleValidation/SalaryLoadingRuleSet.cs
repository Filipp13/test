﻿using SP.Core.Validation.Tests.Data;
using SP.Core.Validation.Validators;

namespace SP.Core.Validation.Tests.RuleValidation
{
  internal class SalaryLoadingRuleSet : BaseValidationRuleSet<ICollectionEntity>
  {
    public SalaryLoadingRuleSet()
    {
      SetRule(new CheckAmountRule());
    }
  }
}