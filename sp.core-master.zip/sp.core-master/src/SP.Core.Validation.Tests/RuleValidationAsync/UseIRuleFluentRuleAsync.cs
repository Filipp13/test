﻿using SP.Core.Validation.Rules.FluentRule;
using SP.Core.Validation.Tests.Data;

namespace SP.Core.Validation.Tests.RuleValidationAsync
{
  internal class UseIRuleFluentRuleAsync : BaseFluentRuleAsync<IMainEntity>
  {
    public UseIRuleFluentRuleAsync()
    {
      ForProperty(e => e.AccountsInfo)
        .UseRuleAsync(new AccountTypeRuleAsync());
    }
  }
}