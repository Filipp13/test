﻿using System.Threading.Tasks;
using SP.Core.Validation.Rules.FluentRule;
using SP.Core.Validation.Tests.Data;

namespace SP.Core.Validation.Tests.RuleValidationAsync
{
  public class AccountTypeRuleAsync : BaseFluentRuleAsync<IAccInfo>
  {
    public AccountTypeRuleAsync()
    {
      ForProperty(a => Task.FromResult(a.Account))
        .Must((x, c) => Task.FromResult(false))
        .WithErrorMessage("Account is null");
    }
  }
}