﻿namespace SP.Core.Mediator.Seedwork
{
  /// <summary>
  ///   Интерфейс-маркер, определяющий сообщение.
  /// </summary>
  /// <remarks>
  ///   Базовый интерфейс для команд, событий и запросов.
  /// </remarks>
  public interface IMessage
  {
  }
}