﻿namespace SP.Core.Mediator.Seedwork
{
  /// <summary>
  ///   Интерфейс-маркер, определяющий событие.
  /// </summary>
  public interface IEvent : IMessage
  {
  }
}