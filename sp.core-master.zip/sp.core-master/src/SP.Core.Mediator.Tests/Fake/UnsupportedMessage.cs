﻿using SP.Core.Mediator.Seedwork;

namespace SP.Core.Mediator.Tests.Fake
{
  /// <summary>
  /// Простой объект передачи данных, представляющий не поддерживаемый тип сообщения.
  /// </summary>
  public record UnsupportedMessage : IMessage;
}