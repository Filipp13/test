﻿namespace SP.Core.Mediator.Tests.Fake
{
  /// <summary>
  /// Простой объект передачи данных, представляющий команду для которой зарегистрирован обработчик.
  /// </summary>
  public record Command(string Name) : ICommand;

  /// <summary>
  /// Простой объект передачи данных, представляющий команду для которой не зарегистрирован обработчик.
  /// </summary>
  public record CommandWithoutHandler : ICommand;
}