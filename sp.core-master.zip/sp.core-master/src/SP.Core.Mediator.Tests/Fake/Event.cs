﻿using System;
using SP.Core.Mediator.Seedwork;

namespace SP.Core.Mediator.Tests.Fake
{
    /// <summary>
    /// Простой объект передачи данных, представляющий событие для которого зарегистрированы обработчики. 
    /// </summary>
    public record Event(Guid Id, string Name) : IEvent
    {
      public int CountHandle { get; set; }
    }

    /// <summary>
    /// Простой объект передачи данных, представляющий событие для которого не зарегистрированы обработчики.
    /// </summary>
    public record EventWithoutHandler(Guid Id) : IEvent;
}