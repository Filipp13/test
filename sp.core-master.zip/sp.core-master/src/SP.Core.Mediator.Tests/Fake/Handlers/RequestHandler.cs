﻿using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using static System.Threading.Tasks.Task;

namespace SP.Core.Mediator.Tests.Fake.Handlers
{
  public class RequestHandler : IMessageHandler<Request, int>, IMessageHandlerAsync<Request, int>
  {
    public const int Result = 10;

    private static int Log(Request message)
    {
      TestContext.WriteLine($"The {nameof(RequestHandler)} handle {message.GetType().FullName}");
      return Result;
    }

    private static Task<int> LogAsync(Request message) => FromResult(Log(message));

    public int Handle(Request message) => Log(message);

    public Task<int> HandleAsync(Request message, CancellationToken cancellationToken)
      => Delay(200, cancellationToken)
        .ContinueWith(_ => LogAsync(message), TaskContinuationOptions.OnlyOnRanToCompletion)
        .Unwrap();
  }
}