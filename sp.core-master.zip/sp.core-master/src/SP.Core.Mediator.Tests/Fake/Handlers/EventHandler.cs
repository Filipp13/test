using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using static System.Threading.Tasks.Task;

namespace SP.Core.Mediator.Tests.Fake.Handlers
{
  public class EventHandler : IMessageHandler<Event>, IMessageHandlerAsync<Event>
  {
    private static void Log(Event message)
    {
      message.CountHandle++;
      TestContext.WriteLine($"The {nameof(EventHandler)} handle {message.GetType().FullName}");
    }

    private static Task LogAsync(Event message) => Run(() => Log(message));

    public void Handle(Event message) => Log(message);

    public Task HandleAsync(Event message, CancellationToken cancellationToken)
      => Delay(200, cancellationToken)
        .ContinueWith(_ => LogAsync(message), TaskContinuationOptions.OnlyOnRanToCompletion)
        .Unwrap();
  }
}