using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using static System.Threading.Tasks.Task;

namespace SP.Core.Mediator.Tests.Fake.Handlers
{
  public class CommandHandler : IMessageHandler<Command>, IMessageHandlerAsync<Command>
  {
    private static void Log(Command message)
      => TestContext.WriteLine($"The {nameof(CommandHandler)} handle {message.GetType().FullName}");

    private static Task LogAsync(Command message) => Run(() => Log(message));

    public void Handle(Command message) => Log(message);

    public Task HandleAsync(Command message, CancellationToken cancellationToken)
      => Delay(200, cancellationToken)
        .ContinueWith(_ => LogAsync(message), TaskContinuationOptions.OnlyOnRanToCompletion)
        .Unwrap();
  }
}