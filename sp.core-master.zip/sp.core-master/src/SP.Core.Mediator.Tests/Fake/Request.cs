﻿namespace SP.Core.Mediator.Tests.Fake
{
  /// <summary>
  /// Простой объект передачи данных, представляющий запрос для которого зарегистрирован обработчик.
  /// </summary>
  public record Request(string Name) : IRequest;
  
  /// <summary>
  /// Простой объект передачи данных, представляющий запрос для которого не зарегистрирован обработчик.
  /// </summary>
  public record RequestWithoutHandler : IRequest;
}