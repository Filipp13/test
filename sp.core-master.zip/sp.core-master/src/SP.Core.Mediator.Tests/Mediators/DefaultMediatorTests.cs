﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using SP.Core.Mediator.Tests.Fake;
using SP.Core.Mediator.Tests.Fake.Handlers;
using EventHandler = SP.Core.Mediator.Tests.Fake.Handlers.EventHandler;

// ReSharper disable CheckNamespace

namespace SP.Core.Mediator.Mediators.Tests
{
  [TestFixture(Category = "Unit", TestOf = typeof(DefaultMediator))]
  public class DefaultMediatorTests
  {
    [OneTimeSetUp]
    public void Setup()
    {
      _mediator = new DefaultMediator(new List<IMessageHandler>()
      {
        new CommandHandler(), new EventHandler(), new RequestHandler(),
      });
    }

    private IMediator _mediator;

    [Test]
    public void Ctor_HandlersIsNull_ArgumentNullException()
      => Assert.Catch<ArgumentNullException>(() => _ = new DefaultMediator(null!));

    [Test]
    public void Ctor_Handlers_DoesNotThrow()
      => Assert.DoesNotThrow(() => _ = new DefaultMediator(Enumerable.Empty<IMessageHandler>()));

    [Test]
    public void SendMessageAsync_TMessageIsNull_ArgumentNullException()
    {
      Assert.Multiple(() =>
      {
        Assert.CatchAsync<ArgumentNullException>(() => _mediator.SendMessageAsync<Event>(null!));
        Assert.CatchAsync<ArgumentNullException>(() => _mediator.SendMessageAsync<Request, int>(null!));
      });
    }

    [Test]
    public void SendMessageAsync_TMessageIsUnsupportedMessage_ArgumentOutOfRangeException()
    {
      Assert.Multiple(() =>
      {
        Assert.CatchAsync<ArgumentOutOfRangeException>(() => _mediator.SendMessageAsync(new UnsupportedMessage()));
        Assert.CatchAsync<ArgumentOutOfRangeException>(
          () => _mediator.SendMessageAsync<UnsupportedMessage, int>(new UnsupportedMessage()));
      });
    }

    [Test]
    public void SendMessageAsync_TMessageIsEventWithoutHandler_DoesNotThrow()
      => Assert.DoesNotThrowAsync(() => _mediator.SendMessageAsync(new EventWithoutHandler(Guid.Empty)));

    [Test]
    public async Task SendMessageAsync_TMessageIsEvent_OnceHandled()
    {
      var @event = new Event(Guid.NewGuid(), "Event one");

      await _mediator.SendMessageAsync(@event);

      Assert.AreEqual(1, @event.CountHandle);
    }

    [Test]
    public async Task SendMessageAsync_TMessageIsEvent_TwiceCountHandled()
    {
      var mediator = new DefaultMediator(new IMessageHandler[] {new EventHandler(), new EventHandler()});
      var @event = new Event(Guid.NewGuid(), "Event one");

      await mediator.SendMessageAsync(@event);

      Assert.AreEqual(2, @event.CountHandle);
    }

    [Test]
    public void SendMessageAsync_TMessageIsEvent_CancellationRequested()
    {
      using var cancellationTokenSource = new CancellationTokenSource(100);

      Assert.CatchAsync<TaskCanceledException>(() =>
        _mediator.SendMessageAsync(new Event(Guid.Empty, "Event one"), cancellationTokenSource.Token));
    }

    [Test]
    public void SendMessageAsync_TMessageIsCommandWithoutHandler_InvalidOperationException()
      => Assert.CatchAsync<InvalidOperationException>(() => _mediator.SendMessageAsync(new CommandWithoutHandler()));

    [Test]
    public void SendMessageAsync_TMessageIsCommandWithTwoHandlers_InvalidOperationException()
    {
      var mediator =
        new DefaultMediator(new IMessageHandler[] {new CommandHandler(), new CommandHandler()});

      Assert.CatchAsync<InvalidOperationException>(() => mediator.SendMessageAsync(new Command("Command one")));
    }

    [Test]
    public void SendMessageAsync_TMessageIsCommandWithOneHandler_DoesNotThrow()
      => Assert.DoesNotThrowAsync(() => _mediator.SendMessageAsync(new Command("Command one")));

    [Test]
    public void SendMessageAsync_TMessageIsCommandWithOneHandler_CancellationRequested()
    {
      using var cancellationTokenSource = new CancellationTokenSource(100);
      Assert.CatchAsync<TaskCanceledException>(() =>
        _mediator.SendMessageAsync(new Command("Command one"), cancellationTokenSource.Token));
    }

    [Test]
    public void SendMessageAsync_TMessageIsRequestWithoutHandler_InvalidOperationException()
      => Assert.CatchAsync<InvalidOperationException>(
        () => _mediator.SendMessageAsync<RequestWithoutHandler, int>(new RequestWithoutHandler()));

    [Test]
    public void SendMessageAsync_TMessageIsRequestWithTwoHandlers_InvalidOperationException()
    {
      var mediator =
        new DefaultMediator(new IMessageHandler[] {new RequestHandler(), new RequestHandler()});

      Assert.CatchAsync<InvalidOperationException>(
        () => mediator.SendMessageAsync<Request, int>(new Request("Request one")));
    }

    [Test(ExpectedResult = RequestHandler.Result)]
    public async Task<int> SendMessageAsync_TMessageIsRequestWithOneHandler_Ten()
      => await _mediator.SendMessageAsync<Request, int>(new Request("Request one"));

    [Test]
    public void SendMessageAsync_TMessageIsRequestWithOneHandler_CancellationRequested()
    {
      using var cancellationTokenSource = new CancellationTokenSource(100);
      Assert.CatchAsync<TaskCanceledException>(() =>
        _mediator.SendMessageAsync<Request, int>(new Request("Request one"), cancellationTokenSource.Token));
    }

    [Test]
    public void SendMessage_TMessageIsNull_ArgumentNullException()
    {
      Assert.Multiple(() =>
      {
        Assert.Catch<ArgumentNullException>(() => _mediator.SendMessage<Event>(null!));
        Assert.Catch<ArgumentNullException>(() => _mediator.SendMessage<Request, int>(null!));
      });
    }

    [Test]
    public void SendMessage_TMessageIsUnsupportedMessage_ArgumentOutOfRangeException()
    {
      Assert.Multiple(() =>
      {
        Assert.Catch<ArgumentOutOfRangeException>(() => _mediator.SendMessage(new UnsupportedMessage()));
        Assert.Catch<ArgumentOutOfRangeException>(
          () => _mediator.SendMessage<UnsupportedMessage, int>(new UnsupportedMessage()));
      });
    }

    [Test]
    public void SendMessage_TMessageIsEventWithoutHandler_DoesNotThrow()
      => Assert.DoesNotThrow(() => _mediator.SendMessage(new EventWithoutHandler(Guid.Empty)));

    [Test]
    public void SendMessage_TMessageIsEvent_OnceHandled()
    {
      var @event = new Event(Guid.NewGuid(), "Event one");

      _mediator.SendMessage(@event);

      Assert.AreEqual(1, @event.CountHandle);
    }

    [Test]
    public void SendMessage_TMessageIsEvent_TwiceCountHandled()
    {
      var mediator = new DefaultMediator(new IMessageHandler[] {new EventHandler(), new EventHandler()});
      var @event = new Event(Guid.NewGuid(), "Event one");

      mediator.SendMessage(@event);

      Assert.AreEqual(2, @event.CountHandle);
    }

    [Test]
    public void SendMessage_TMessageIsCommandWithoutHandler_InvalidOperationException()
      => Assert.Catch<InvalidOperationException>(() => _mediator.SendMessage(new CommandWithoutHandler()));

    [Test]
    public void SendMessage_TMessageIsCommandWithTwoHandlers_InvalidOperationException()
    {
      var mediator =
        new DefaultMediator(new IMessageHandler[] {new CommandHandler(), new CommandHandler()});

      Assert.Catch<InvalidOperationException>(() => mediator.SendMessage(new Command("Command one")));
    }

    [Test]
    public void SendMessage_TMessageIsCommandWithOneHandler_DoesNotThrow()
      => Assert.DoesNotThrow(() => _mediator.SendMessage(new Command("Command one")));


    [Test]
    public void SendMessage_TMessageIsRequestWithoutHandler_InvalidOperationException()
      => Assert.Catch<InvalidOperationException>(
        () => _mediator.SendMessage<RequestWithoutHandler, int>(new RequestWithoutHandler()));

    [Test]
    public void SendMessageA_TMessageIsRequestWithTwoHandlers_InvalidOperationException()
    {
      var mediator =
        new DefaultMediator(new IMessageHandler[] {new RequestHandler(), new RequestHandler()});

      Assert.Catch<InvalidOperationException>(
        () => mediator.SendMessage<Request, int>(new Request("Request one")));
    }

    [Test(ExpectedResult = RequestHandler.Result)]
    public int SendMessage_TMessageIsRequestWithOneHandler_Ten()
      => _mediator.SendMessage<Request, int>(new Request("Request one"));


    [Test]
    public async Task SendMessageAsync_Concurrent_DoesNotThrow()
    {
      var sendCommandMessageTask = _mediator.SendMessageAsync(new Command("Command one"));
      var sendEventMessageTask = _mediator.SendMessageAsync(new Event(Guid.Empty, "Event one"));
      var sendEventMessageTask2 = _mediator.SendMessageAsync(new Event(Guid.Empty, "Event one"));
      var sendRequestMessageTask = _mediator.SendMessageAsync<Request, int>(new Request("Request one"));
      TestContext.WriteLine("Other action...");
      await Task.WhenAll(sendCommandMessageTask, sendEventMessageTask, sendEventMessageTask2, sendRequestMessageTask);
    }
  }
}