﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using SP.Core.Mediator.Seedwork;

namespace SP.Core.Domain.Seedwork
{
  /// <summary>
  ///   Представляет сущность.
  /// </summary>
  public interface IEntity
  {
  }

  /// <summary>
  ///   Представляет обобщённую сущность, с параметром типа ключа.
  /// </summary>
  /// <typeparam name="TKey">Тип идентификатора сущности.</typeparam>
  public class Entity<TKey> : IEntity
  {
    private readonly ConcurrentQueue<IEvent> _events;

    /// <summary>
    ///   Инициализирует поля базового класса <see cref="Entity{TKey}" />.
    /// </summary>
    protected Entity()
    {
      _events = new ConcurrentQueue<IEvent>();
    }

    /// <summary>
    ///   Получает уникальный идентификатор сущности.
    /// </summary>
    public virtual TKey Id { get; protected set; }

    /// <summary>
    ///   Получает ссылку на объект <see cref="IReadOnlyCollection{T}" /> представляющий коллекцию событий предметной области.
    /// </summary>
    public IReadOnlyCollection<IEvent> Events => _events.ToList().AsReadOnly();

    /// <summary>
    ///   Добавляет событие в очередь.
    /// </summary>
    /// <param name="event">Ссылка на объект <see cref="IEvent" />.</param>
    public void Enqueue(IEvent @event)
    {
      _events.Enqueue(@event);
    }

    /// <summary>
    ///   Очищает очередь событий.
    /// </summary>
    public void ClearQueue()
    {
      if (_events.IsEmpty)
      {
        return;
      }

      while (!_events.IsEmpty)
      {
        _events.TryDequeue(out _);
      }
    }

    /// <inheritdoc />
    public override bool Equals(object? obj)
    {
      if (obj is not Entity<TKey> entity)
      {
        return false;
      }

      if (ReferenceEquals(this, entity))
      {
        return true;
      }

      if (GetType() != obj.GetType())
      {
        return false;
      }

      if (Equals(Id, default(TKey)) || Equals(entity.Id, default(TKey)))
      {
        return false;
      }

      return entity.Id.Equals(Id);
    }

    /// <inheritdoc />
    public override int GetHashCode()
    {
      return HashCode.Combine(Id);
    }
  }
}