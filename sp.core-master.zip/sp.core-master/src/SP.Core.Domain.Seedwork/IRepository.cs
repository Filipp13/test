﻿namespace SP.Core.Domain.Seedwork
{
  /// <summary>
  ///   Представляет обобщённый репозиторий.
  /// </summary>
  /// <typeparam name="T">
  ///   Тип элементов доступных в репозитории и реализующих <see cref="IAggregateRoot" />.
  /// </typeparam>
  public interface IRepository<T> where T : IAggregateRoot
  {
    /// <summary>
    ///   Получает ссылку на объект <see cref="IUnitOfWork" />.
    /// </summary>
    IUnitOfWork UnitOfWork { get; }
  }
}