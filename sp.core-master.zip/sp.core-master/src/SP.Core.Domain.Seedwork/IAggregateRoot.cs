namespace SP.Core.Domain.Seedwork
{
  /// <summary>
  ///   Представляет корень агрегата.
  /// </summary>
  public interface IAggregateRoot
  {
  }
}