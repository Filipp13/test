using System;
using System.Threading;
using System.Threading.Tasks;

namespace SP.Core.Domain.Seedwork
{
  /// <summary>
  ///   Представляет единицу работы.
  /// </summary>
  public interface IUnitOfWork : IDisposable
  {
    /// <summary>
    ///   Сохраняет изменения в БД, предварительно опубликовав события.
    /// </summary>
    /// <remarks>
    ///   Изменения внесённые обработчиками событий будут зафиксированны, в одной транзакии,
    ///   вместе с изменениями внесёнными в сущности агрегата.
    /// </remarks>
    /// <param name="cancellationToken">Ссылка на объект <see cref="CancellationToken" />.</param>
    /// <returns>Значение ИСТИНА если события успешно опубликованы и все изменения сохранены, иначе ЛОЖЬ.</returns>
    Task<bool> PublishAndSaveAsync(CancellationToken cancellationToken = default);

    /// <summary>
    ///   Сохраняет изменения в БД после чего публикует события.
    /// </summary>
    /// <remarks>
    ///   Изменения внесённые обработчиками событий будут зафиксированны, в отдельных транзакциях,
    ///   независимо от изменений внесённых в сущности агрегата.
    /// </remarks>
    /// <param name="cancellationToken">Ссылка на объект <see cref="CancellationToken" />.</param>
    /// <returns>Значение ИСТИНА если события успешно опубликованы и все изменения сохранены, иначе ЛОЖЬ.</returns>
    Task<bool> SaveAndPublishAsync(CancellationToken cancellationToken = default);
  }
}