﻿using System;
using System.Threading.Tasks;

namespace SP.Core.Validation.Rules.FluentRule.RuleValidators
{
  internal class LengthValidatorAsync<T> : PropertyRuleValidatorAsync<Task<T>>
  {
    public LengthValidatorAsync(int min, int max)
    {
      if (max < min)
      {
        throw new ArgumentOutOfRangeException(nameof(max));
      }

      Max = max;
      Min = min;
    }

    private int Min { get; }

    private int Max { get; }

    protected override async Task<bool> IsValidAsync(Task<T> instance, ValidationContext context)
    {
      var length = (await instance)?.ToString()?.Length;

      return length >= Min && length <= Max;
    }
  }
}