﻿using System;
using System.Collections.Generic;
using SP.Core.Validation.Rules.ValidationResults.RuleMessages;

namespace SP.Core.Validation.Rules.FluentRule.RuleValidators
{
  internal class UseIRulePropertyValidator<T> : IRuleValidator<T>
  {
    private readonly IRule<T> _rule;

    public UseIRulePropertyValidator(IRule<T> rule)
    {
      _rule = rule;
    }

    public void AddArguments(IEnumerable<Func<object, object>> func)
    {
    }

    public void SetMessageSource(Func<IRuleMessage> message)
    {
    }

    public void SetState(Func<object, object> state)
    {
    }

    public IList<IRuleMessage> Validate<TEntity>(T instance, TEntity entity, ValidationContext context)
    {
      return _rule.Validate(instance, context).Messages;
    }
  }
}