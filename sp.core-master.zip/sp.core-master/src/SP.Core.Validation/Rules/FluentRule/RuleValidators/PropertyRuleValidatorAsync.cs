﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SP.Core.Validation.Rules.ValidationResults.RuleMessages;

namespace SP.Core.Validation.Rules.FluentRule.RuleValidators
{
  /// <summary>
  ///   Позволяет проверять заданное правило на основе публичного интерфейса
  ///   проверяемого объекта и вернуть сформированное сообщение
  /// </summary>
  public abstract class PropertyRuleValidatorAsync<T> : IRuleValidatorAsync<T>
  {
    private readonly List<Func<object, object>> _customFormatArgs = new();
    private Func<IRuleMessage>? _source;
    private Func<object, object>? _state;

    /// <summary>
    ///   Функции для расчета валидационных аргументов
    /// </summary>
    public ICollection<Func<object, object>> Arguments => _customFormatArgs;

    /// <inheritdoc />
    public void AddArguments(IEnumerable<Func<object, object>> func)
    {
      _customFormatArgs.AddRange(func);
    }

    /// <inheritdoc />
    public void SetMessageSource(Func<IRuleMessage> message)
    {
      _source = message ?? throw new ArgumentNullException(nameof(message));
    }

    /// <inheritdoc />
    public void SetState(Func<object, object> state)
    {
      _state = state;
    }

    /// <inheritdoc />
    public async Task<IList<IRuleMessage>> ValidateAsync<TEntity>(T instance, TEntity entity, ValidationContext context)
    {
      if (Equals(entity, null))
      {
        throw new ArgumentNullException(nameof(entity));
      }

      if (await IsValidAsync(instance, context))
      {
        return new List<IRuleMessage>();
      }

      if (_source is null)
      {
        throw new InvalidOperationException($"Field {nameof(_source)} must not be null.");
      }

      var source = _source.Invoke();
      source.SetArgs(_customFormatArgs.Select(func => func(entity)).ToArray());
      if (_state != null)
      {
        source.State = _state.Invoke(entity);
      }

      return new[] {source};
    }

    /// <summary>
    ///   Применяет правило к заданному <paramref name="instance" /> и возвращает результат проверки.
    /// </summary>
    /// <param name="instance">Ссылка на объект <see cref="T" />.</param>
    /// <param name="context">Ссылка на объект <see cref="ValidationContext" />.</param>
    /// <returns></returns>
    protected abstract Task<bool> IsValidAsync(T instance, ValidationContext context);
  }
}