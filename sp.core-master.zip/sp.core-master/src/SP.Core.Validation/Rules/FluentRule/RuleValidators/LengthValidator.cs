﻿using System;

namespace SP.Core.Validation.Rules.FluentRule.RuleValidators
{
  internal class LengthValidator<T> : PropertyRuleValidator<T>
  {
    public LengthValidator(int min, int max)
    {
      if (max < min)
      {
        throw new ArgumentOutOfRangeException(nameof(max));
      }

      Max = max;
      Min = min;
    }

    private int Min { get; }

    private int Max { get; }

    protected override bool IsValid(T instance, ValidationContext context)
    {
      var length = instance?.ToString()?.Length;

      return length >= Min && length <= Max;
    }
  }
}