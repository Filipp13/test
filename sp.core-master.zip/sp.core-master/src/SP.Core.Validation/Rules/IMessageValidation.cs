﻿using SP.Core.Validation.Validators;

namespace SP.Core.Validation.Rules
{
  public interface IMessageValidation
  {
    ValidationResult Validate(object message);
  }
}