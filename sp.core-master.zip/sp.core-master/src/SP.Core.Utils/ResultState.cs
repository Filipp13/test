﻿namespace SP.Core.Utils
{
  public enum ResultState
  {
    Success,
    Empty,
    Invalid
  }
}