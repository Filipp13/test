﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

namespace SP.Core.Utils
{
  /// <summary>
  ///   Представляет набор вспомогательных программ (утилит).
  /// </summary>
  public static class GenericUtilities
  {
    /// <summary>
    ///   Применяет метод <paramref name="predicate" /> к аргументу <paramref name="obj" />.
    ///   Если аргумент удовлетворяет критериям вызывает исключение <paramref name="exception" />, иначе возвращает
    ///   <paramref name="obj" />.
    /// </summary>
    /// <typeparam name="T">Тип объекта.</typeparam>
    /// <typeparam name="TException">Тип исключения.</typeparam>
    /// <param name="obj">Ссылка на объект <see cref="T" />.</param>
    /// <param name="predicate">Ссылка на метод <see cref="Predicate{T}" />.</param>
    /// <param name="exception">Ссылка на объект <see cref="TException" />.</param>
    /// <returns>Ссылка на объект <see cref="T" />.</returns>
    public static T ThrowIf<T, TException>(this T obj, Predicate<T> predicate, TException exception)
      where T : class?
      where TException : Exception
    {
      if (obj == null)
      {
        return obj;
      }

      if (predicate(obj))
      {
        throw exception;
      }

      return obj;
    }

    /// <summary>
    ///   Применяет метод <paramref name="predicate" /> к аргументу <paramref name="value" />.
    ///   Если аргумент удовлетворяет критериям вызывает исключение <paramref name="exception" />, иначе возвращает
    ///   <paramref name="value" />.
    /// </summary>
    /// <typeparam name="T">Тип значения.</typeparam>
    /// <typeparam name="TException">Тип исключения.</typeparam>
    /// <param name="value">Значение <see cref="T" />.</param>
    /// <param name="predicate">Ссылка на метод <see cref="Predicate{T}" />.</param>
    /// <param name="exception">Ссылка на объект <see cref="TException" />.</param>
    /// <returns>Значение <see cref="T" />.</returns>
    public static T? ThrowIf<T, TException>(this T? value, Predicate<T?> predicate, TException exception)
      where T : struct
      where TException : Exception
    {
      if (value == null)
      {
        return value;
      }

      if (predicate(value))
      {
        throw exception;
      }

      return value;
    }

    /// <summary>
    ///   Применяет метод <paramref name="predicate" /> к аргументу <paramref name="obj" />.
    ///   Если аргумент удовлетворяет критериям вызывает метод <paramref name="callback" />, иначе возвращает
    ///   <paramref name="obj" />.
    /// </summary>
    /// <typeparam name="T">Тип объекта.</typeparam>
    /// <typeparam name="TException">Тип исключения.</typeparam>
    /// <param name="obj">Ссылка на объект <see cref="T" />.</param>
    /// <param name="predicate">Ссылка на объект <see cref="Predicate{T}" />.</param>
    /// <param name="callback">Ссылка на метод вызывающий исключения <see cref="Func{T, TException}" />.</param>
    /// <returns>Ссылка на объект <see cref="T" />.</returns>
    public static T ThrowIf<T, TException>(this T obj, Predicate<T> predicate, Func<T, TException> callback)
      where T : class?
      where TException : Exception
    {
      if (obj == null)
      {
        return obj;
      }

      if (predicate(obj))
      {
        throw callback(obj);
      }

      return obj;
    }

    /// <summary>
    ///   Применяет метод <paramref name="predicate" /> к аргументу <paramref name="value" />.
    ///   Если аргумент удовлетворяет критериям вызывает метод <paramref name="callback" />, иначе возвращает
    ///   <paramref name="value" />.
    /// </summary>
    /// <typeparam name="T">Тип значения.</typeparam>
    /// <typeparam name="TException">Тип исключения.</typeparam>
    /// <param name="value">Значение <see cref="T" />.</param>
    /// <param name="predicate">Ссылка на объект <see cref="Predicate{T}" />.</param>
    /// <param name="callback">Ссылка на метод вызывающий исключения <see cref="Func{T, TException}" />.</param>
    /// <returns>Значение <see cref="T" />.</returns>
    public static T? ThrowIf<T, TException>(this T? value, Predicate<T?> predicate, Func<T?, TException> callback)
      where T : struct
      where TException : Exception
    {
      if (value == null)
      {
        return value;
      }

      if (predicate(value))
      {
        throw callback(value);
      }

      return value;
    }

    /// <summary>
    ///   Применяет метод <paramref name="predicate" /> к аргументу <paramref name="obj" />.
    ///   Если аргумент не удовлетворяет критериям вызывает исключение <paramref name="exception" />, иначе возвращает
    ///   <paramref name="obj" />.
    /// </summary>
    /// <typeparam name="T">Тип объекта.</typeparam>
    /// <typeparam name="TException">Тип исключения.</typeparam>
    /// <param name="obj">Ссылка на объект <see cref="T" />.</param>
    /// <param name="predicate">Ссылка на метод <see cref="Predicate{T}" />.</param>
    /// <param name="exception">Ссылка на объект <see cref="TException" />.</param>
    /// <returns>Ссылка на объект <see cref="T" />.</returns>
    public static T ThrowIfNot<T, TException>(this T obj, Predicate<T> predicate, TException exception)
      where T : class?
      where TException : Exception
    {
      if (obj == null)
      {
        return obj;
      }

      if (!predicate(obj))
      {
        throw exception;
      }

      return obj;
    }

    /// <summary>
    ///   Применяет метод <paramref name="predicate" /> к аргументу <paramref name="value" />.
    ///   Если аргумент не удовлетворяет критериям вызывает исключение <paramref name="exception" />, иначе возвращает
    ///   <paramref name="value" />.
    /// </summary>
    /// <typeparam name="T">Тип значения.</typeparam>
    /// <typeparam name="TException">Тип исключения.</typeparam>
    /// <param name="value">Значение <see cref="T" />.</param>
    /// <param name="predicate">Ссылка на метод <see cref="Predicate{T}" />.</param>
    /// <param name="exception">Ссылка на объект <see cref="TException" />.</param>
    /// <returns>Значение <see cref="T" />.</returns>
    public static T? ThrowIfNot<T, TException>(this T? value, Predicate<T?> predicate, TException exception)
      where T : struct
      where TException : Exception
    {
      if (value == null)
      {
        return value;
      }

      if (!predicate(value))
      {
        throw exception;
      }

      return value;
    }

    /// <summary>
    ///   Применяет метод <paramref name="predicate" /> к аргументу <paramref name="obj" />.
    ///   Если аргумент не удовлетворяет критериям вызывает метод <paramref name="callback" />, иначе возвращает
    ///   <paramref name="obj" />.
    /// </summary>
    /// <typeparam name="T">Тип объекта.</typeparam>
    /// <typeparam name="TException">Тип исключения.</typeparam>
    /// <param name="obj">Ссылка на объект <see cref="T" />.</param>
    /// <param name="predicate">Ссылка на объект <see cref="Predicate{T}" />.</param>
    /// <param name="callback">Ссылка на метод вызывающий исключения <see cref="Func{T, TException}" />.</param>
    /// <returns>Ссылка на объект <see cref="T" />.</returns>
    public static T ThrowIfNot<T, TException>(this T obj, Predicate<T> predicate, Func<T, TException> callback)
      where T : class?
      where TException : Exception
    {
      if (obj == null)
      {
        return obj;
      }

      if (!predicate(obj))
      {
        throw callback(obj);
      }

      return obj;
    }

    /// <summary>
    ///   Применяет метод <paramref name="predicate" /> к аргументу <paramref name="value" />.
    ///   Если аргумент не удовлетворяет критериям вызывает метод <paramref name="callback" />, иначе возвращает
    ///   <paramref name="value" />.
    /// </summary>
    /// <typeparam name="T">Тип значения.</typeparam>
    /// <typeparam name="TException">Тип исключения.</typeparam>
    /// <param name="value">Значение <see cref="T" />.</param>
    /// <param name="predicate">Ссылка на объект <see cref="Predicate{T}" />.</param>
    /// <param name="callback">Ссылка на метод вызывающий исключения <see cref="Func{T, TException}" />.</param>
    /// <returns>Значение <see cref="T" />.</returns>
    public static T? ThrowIfNot<T, TException>(this T? value, Predicate<T?> predicate, Func<T?, TException> callback)
      where T : struct
      where TException : Exception
    {
      if (value == null)
      {
        return value;
      }

      if (!predicate(value))
      {
        throw callback(value);
      }

      return value;
    }

    /// <summary>
    ///   Применяет метод <paramref name="evaluator" /> к элементу коллекции <paramref name="enumerable" /> c указанным
    ///   <paramref name="index" />.
    ///   <para>
    ///     Возвращает значение <paramref name="default" /> если:
    ///     <paramref name="enumerable" /> равен <see langword="null" />,
    ///     элемент с указанным <paramref name="index" /> равен <see langword="null" />
    ///     или элемент с указанным <paramref name="index" /> не существует.
    ///   </para>
    /// </summary>
    /// <typeparam name="T">Тип элемента.</typeparam>
    /// <typeparam name="TResult">Тип результата.</typeparam>
    /// <param name="enumerable">Ссылка на объект <see cref="IEnumerable{T}" />.</param>
    /// <param name="index">Индекс элемента.</param>
    /// <param name="evaluator">Ссылка на метод <see cref="Func{T, TResult}" />.</param>
    /// <param name="default">
    ///   Ссылка на объект <see cref="TResult" />, возвращаемый в качестве значения по умолчанию.
    /// </param>
    /// <returns>Ссылка на объект <see cref="TResult" />.</returns>
    public static TResult At<T, TResult>(
      this IEnumerable<T>? enumerable, int index, Func<T, TResult> evaluator, TResult @default)
    {
      var element = (enumerable ?? Array.Empty<T>()).ElementAtOrDefault(index);

      return element is null ? @default : evaluator(element);
    }

    /// <summary>
    ///   Применяет метод <paramref name="action" /> к аргументу <paramref name="obj" />
    ///   если <paramref name="obj" /> не равен <see langword="null" /> иначе возвращает <paramref name="obj" />.
    /// </summary>
    /// <typeparam name="T">Тип параметра <paramref name="obj" />.</typeparam>
    /// <param name="obj">Ссылка на объект <see cref="T" />.</param>
    /// <param name="action">Ссылка на метод <see cref="Action{T}" />.</param>
    /// <returns>Ссылка на объект <see cref="T" />.</returns>
    public static T Do<T>(this T obj, Action<T> action) where T : class?
    {
      if (obj == null)
      {
        return obj;
      }

      action(obj);
      return obj;
    }

    /// <summary>
    ///   Применяет метод <paramref name="action" /> к аргументу <paramref name="value" />
    ///   если <paramref name="value" /> не равен <see langword="null" /> иначе возвращает <paramref name="value" />.
    /// </summary>
    /// <typeparam name="T">Тип параметра <paramref name="value" />.</typeparam>
    /// <param name="value">Значение.</param>
    /// <param name="action">Ссылка на метод <see cref="Action{T}" />.</param>
    /// <returns>Значение <see cref="T" />.</returns>
    public static T? Do<T>(this T? value, Action<T?> action) where T : struct
    {
      if (value == null)
      {
        return null;
      }

      action(value);
      return value;
    }

    /// <summary>
    ///   Возвращает объект, если результат выполнения функции true
    /// </summary>
    /// <typeparam name="T">Тип объекта</typeparam>
    /// <param name="obj">Ссылка на объект</param>
    /// <param name="evaluator">Ссылка на функцию для расчета</param>
    /// <returns>Ссылка на объект</returns>
    public static T? If<T>(this T obj, Predicate<T> evaluator) where T : class?
    {
      return obj != null && evaluator(obj)
        ? obj
        : null;
    }

    /// <summary>
    ///   Возвращает объект, если результат выполнения функции false
    /// </summary>
    /// <typeparam name="TInput">Тип объекта</typeparam>
    /// <param name="obj">Ссылка на объект</param>
    /// <param name="evaluator">Ссылка на функцию для расчета</param>
    /// <returns>Ссылка на объект</returns>
    public static TInput? IfNot<TInput>(this TInput obj, Func<TInput, bool> evaluator) where TInput : class?
    {
      return obj != null && !evaluator(obj)
        ? obj
        : null;
    }

    /// <summary>
    ///   Возвращает структуру, если результат выполнения функции true
    /// </summary>
    /// <typeparam name="TInput">Тип объекта</typeparam>
    /// <param name="obj">Nullable-структура</param>
    /// <param name="evaluator">Ссылка на функцию для расчета</param>
    /// <returns>Nullable-структура</returns>
    public static TInput? If<TInput>(this TInput? obj, Func<TInput?, bool> evaluator) where TInput : struct
    {
      return obj != null && evaluator(obj)
        ? obj
        : null;
    }

    /// <summary>
    ///   Возвращает структуру, если результат выполнения функции false
    /// </summary>
    /// <typeparam name="TInput">Тип объекта</typeparam>
    /// <param name="obj">Nullable-структура</param>
    /// <param name="evaluator">Ссылка на функцию для расчета</param>
    /// <returns>Nullable-структура</returns>
    public static TInput? IfNot<TInput>(this TInput? obj, Func<TInput?, bool> evaluator) where TInput : struct
    {
      return obj != null && !evaluator(obj)
        ? obj
        : null;
    }

    /// <summary>
    ///   Возвращает результат функции, если ссылка на объект не null
    /// </summary>
    /// <typeparam name="TInput">Тип объекта</typeparam>
    /// <typeparam name="TResult">Тип результата</typeparam>
    /// <param name="obj">Ссылка на объект</param>
    /// <param name="evaluator">Ссылка на выполняемую функцию</param>
    /// <param name="failureValue">Результат в случае ссылка на объект равна null</param>
    /// <returns>Результат выполнения функции</returns>
    public static TResult Evaluate<TInput, TResult>(
      this TInput obj, Func<TInput, TResult> evaluator, TResult failureValue = default) where TInput : class?
    {
      return obj == null
        ? failureValue
        : evaluator(obj);
    }

    /// <summary>
    ///   Возвращает результат функции, если nullable-структура не имеет значения
    /// </summary>
    /// <typeparam name="T">Тип объекта</typeparam>
    /// <typeparam name="TResult">Тип результата</typeparam>
    /// <param name="obj">Nullable-структура</param>
    /// <param name="evaluator">Ссылка на выполняемую функцию</param>
    /// <param name="default">Результат в случае если nullable-структура не имеет значения </param>
    /// <returns>Результат выполнения функции</returns>
    public static TResult Evaluate<T, TResult>(this T? obj, Func<T?, TResult> evaluator, TResult @default = default)
      where T : struct
    {
      return obj.HasValue
        ? evaluator(obj)
        : @default;
    }

    /// <summary>
    ///   Проверяет, что ссылка на объект не null
    /// </summary>
    /// <typeparam name="T">Тип объекта</typeparam>
    /// <param name="obj">Ссылка на объект</param>
    /// <returns>true если не null, иначе false</returns>
    public static bool IsNotNull<T>(this T obj) where T : class?
    {
      return obj != null;
    }

    /// <summary>
    ///   Проверяет, что ссылка на объект не null
    /// </summary>
    /// <typeparam name="T">Тип объекта</typeparam>
    /// <param name="obj">Ссылка на объект</param>
    /// <returns>true если не null, иначе false</returns>
    public static bool IsNotNull<T>(this T? obj) where T : struct
    {
      return obj != null;
    }

    /// <summary>
    ///   Выполняет действие, если объект null
    /// </summary>
    /// <typeparam name="T">Тип объекта</typeparam>
    /// <param name="obj">Ссылка на объект</param>
    /// <param name="action">Функция для выполнения</param>
    /// <returns>Ссылка на объект</returns>
    public static T IfNull<T>(this T obj, Action action) where T : class?
    {
      if (obj == null)
      {
        action();
      }

      return obj;
    }

    /// <summary>
    ///   Генерирует <see cref="ArgumentNullException" /> в случае если ссылка на объект равна null
    /// </summary>
    /// <typeparam name="TInput">Тип объекта</typeparam>
    /// <param name="param">Ссылка на объект</param>
    /// <param name="paramName">Имя параметра</param>
    /// <returns>Ссылка на объект</returns>
    public static TInput ThrowIfNull<TInput>(
      this TInput param, [CallerMemberName] string paramName = "")
      where TInput : class
    {
      if (param == null)
      {
        throw new ArgumentNullException(paramName ?? "param");
      }

      return param;
    }

    /// <summary>
    ///   Генерирует <see cref="ArgumentNullException" /> в случае
    ///   если строка пуста, или ссылка на нее равна null
    /// </summary>
    /// <param name="param">Ссылка на строку</param>
    /// <param name="paramName">Имя параметра</param>
    /// <returns>Ссылка на строку</returns>
    public static string ThrowIfNullOrEmpty(
      this string param, [CallerMemberName] string paramName = "")
    {
      if (string.IsNullOrEmpty(param))
      {
        throw new ArgumentNullException(paramName ?? "param");
      }

      return param;
    }

    /// <summary>
    ///   Генерирует исключение в случае строка не пуста, и ссылка на нее не равна null
    /// </summary>
    /// <param name="param">Ссылка на строку</param>
    /// <param name="exception">Ссылка на исключение</param>
    /// <returns>Ссылка на строку</returns>
    public static string ThrowIfNullOrEmpty(this string param, Exception exception)
    {
      if (string.IsNullOrEmpty(param))
      {
        throw exception;
      }

      return param;
    }

    /// <summary>
    ///   Генерирует <see cref="ArgumentNullException" /> в случае если строка не
    ///   пуста и не содержит только пробелы, и ссылка на нее не равна null
    /// </summary>
    /// <param name="param">Ссылка на строку</param>
    /// <param name="paramName">Имя параметра</param>
    /// <returns>Ссылка на строку</returns>
    public static string ThrowIfNullOrWhiteSpace(
      this string param, [CallerMemberName] string paramName = "")
    {
      if (string.IsNullOrWhiteSpace(param))
      {
        throw new ArgumentNullException(paramName ?? "param");
      }

      return param;
    }

    /// <summary>
    ///   Генерирует исключение в случае если строка не
    ///   пуста и не содержит только пробелы, и ссылка на нее не равна null
    /// </summary>
    /// <param name="param">Ссылка на строку</param>
    /// <param name="exception">Ссылка на исключение</param>
    /// <returns>Ссылка на строку</returns>
    public static string ThrowIfNullOrWhiteSpace(this string param, Exception exception)
    {
      if (string.IsNullOrWhiteSpace(param))
      {
        throw exception;
      }

      return param;
    }

    /// <summary>
    ///   Генерирует <see cref="ArgumentNullException" /> в случае если ссылка на объект равна null
    /// </summary>
    /// <typeparam name="TInput">Тип объекта</typeparam>
    /// <param name="param">Ссылка на объект</param>
    /// <param name="exception">Ссылка на исключение</param>
    /// <returns>Ссылка на объект</returns>
    public static TInput ThrowIfNull<TInput>(this TInput param, Exception exception) where TInput : class
    {
      if (param == null)
      {
        throw exception;
      }

      return param;
    }
  }
}