using NUnit.Framework;

namespace SP.Core.Queues.RabbitMQ.Tests
{
  public class Tests
  {
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void Test1()
    {
      Assert.Pass();
    }
  }
}