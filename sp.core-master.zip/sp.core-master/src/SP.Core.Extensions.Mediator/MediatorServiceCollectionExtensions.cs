﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using SP.Core.Mediator;
using SP.Core.Mediator.Mediators;

namespace SP.Core.Extensions.Mediator
{
  /// <summary>
  ///   Предоставляет методы расширения DI для регистрации посредника и обработчиков.
  /// </summary>
  public static class MediatorServiceCollectionExtensions
  {
    /// <summary>
    ///   Добавляет службу <see cref="IMediator" /> в DI.
    /// </summary>
    /// <param name="services">The <see cref="IServiceCollection" />.</param>
    /// <returns>The <see cref="IServiceCollection" />.</returns>
    public static IServiceCollection AddDefaultMediator(this IServiceCollection services)
    {
      return services.AddMediator<DefaultMediator>();
      ;
    }

    /// <summary>
    ///   Добавляет службу <see cref="IMediator" /> в DI.
    /// </summary>
    /// <param name="services">The <see cref="IServiceCollection" />.</param>
    /// <returns>The <see cref="IServiceCollection" />.</returns>
    public static IServiceCollection AddMediator<T>(this IServiceCollection services)
      where T : class, IMediator
    {
      services.TryAddSingleton<IMediator, T>();

      return services;
    }

    /// <summary>
    ///   Добавляет в DI обработчик команды.
    /// </summary>
    /// <param name="services">Ссылка на объект <see cref="IServiceCollection" />.</param>
    /// <typeparam name="TCommandReceiver">Тип обработчика.</typeparam>
    /// <returns>Ссылка на объект <see cref="IServiceCollection" />.</returns>
    public static IServiceCollection AddCommandReceiver<TCommandReceiver>(this IServiceCollection services)
      where TCommandReceiver : class, IMessageHandler
    {
      return services.AddSingleton<IMessageHandler, TCommandReceiver>();
    }

    /// <summary>
    ///   Добавляет в DI обработчик события.
    /// </summary>
    /// <param name="services">Ссылка на объект <see cref="IServiceCollection" />.</param>
    /// <typeparam name="TEventListener">Тип обработчика.</typeparam>
    /// <returns>Ссылка на объект <see cref="IServiceCollection" />.</returns>
    public static IServiceCollection AddEventListener<TEventListener>(this IServiceCollection services)
      where TEventListener : class, IMessageHandler
    {
      return services.AddSingleton<IMessageHandler, TEventListener>();
    }


    /// <summary>
    ///   Добавляет в DI обработчик запроса.
    /// </summary>
    /// <param name="services">Ссылка на объект <see cref="IServiceCollection" />.</param>
    /// <typeparam name="TRequestHandler">Тип обработчика запроса.</typeparam>
    /// <returns>Ссылка на объект <see cref="IServiceCollection" />.</returns>
    public static IServiceCollection AddRequestHandler<TRequestHandler>(this IServiceCollection services)
      where TRequestHandler : class, IMessageHandler
    {
      return services.AddSingleton<IMessageHandler, TRequestHandler>();
    }
  }
}