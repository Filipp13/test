﻿using System;

namespace SP.Core.Queues.IBMMQ
{
  /// <summary>
  /// Опции подключения к IBM MQ.
  /// </summary>
  public sealed class IBMOptions
  {
    /// <summary>
    /// Секция, в которой находятся опции.
    /// </summary>
    public static readonly string SectionName = "Endpoints:IBMMQ";

    /// <summary>
    /// Базовый адрес.
    /// </summary>
    public string BaseAddress { get; set; } = string.Empty;

    /// <summary>
    /// Порт.
    /// </summary>
    public int Port { get; set; }

    /// <summary>
    /// Канал.
    /// </summary>
    public string Channel { get; set; } = string.Empty;

    /// <summary>
    /// Менеджер.
    /// </summary>
    public string QueueManager { get; set; } = string.Empty;

    /// <summary>
    /// Имена очередей.
    /// </summary>
    public string[] QueueNames { get; set; } = Array.Empty<string>();

    /// <summary>
    ///  Таймаут.
    /// </summary>
    public long WaitTimeoutMilliseconds { get; set; }


    /// <summary>
    ///   Получает или задаёт общее время ожидания для всех попыток в секундах.
    /// </summary>
    public int OverallTimeout { get; set; } = 60;

    /// <summary>
    ///   Получает или задаёт время ожидания для каждой отдельной попыти в секундах.
    /// </summary>
    /// <remarks>
    ///   Общее время выполнения запроса ограничено значением <see cref="OverallTimeout" />.
    ///   Независимо от количества повторных попыток.
    /// </remarks>
    public int TryTimeout { get; set; } = 3;

    /// <summary>
    ///   Получает или задаёт время задержки первой повторной попытки в секундах.
    /// </summary>
    /// <remarks>
    ///   Последующие попытки будут выполняться с экспоненциальной задержкой.
    /// </remarks>
    public int RetryDelay { get; set; } = 3;

    /// <summary>
    ///   Задаёт максимальное количество повторных попыток.
    /// </summary>
    public int RetryCount { get; set; } = 10;

    /// <summary>
    /// Опции поллинга. 
    /// </summary>
    public HostedServiceOptions HostedServiceOptions { get; set; } = new HostedServiceOptions();
  }
}