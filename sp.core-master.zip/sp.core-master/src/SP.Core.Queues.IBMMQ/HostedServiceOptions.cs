using System;

namespace SP.Core.Queues.IBMMQ
{
  /// <summary>
  /// Опции поллинга.
  /// </summary>
  public sealed class HostedServiceOptions
  {

    /// <summary>
    /// Количество потоков.
    /// </summary>
    public int ConcurrencyLevel { get; set; }

    /// <summary>
    /// Задержка опроса IBM MQ.
    /// </summary>
    public TimeSpan WorkRepeatDelay { get; set; }
  }
}