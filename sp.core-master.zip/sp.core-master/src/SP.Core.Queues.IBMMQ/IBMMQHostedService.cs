using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using IBM.XMS;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace SP.Core.Queues.IBMMQ
{
  /// <summary>
  /// Сервис polling сообщений.
  /// </summary>
  public class IBMMQHostedService : IHostedService
  {
    private readonly IConnection _connection;
    private readonly ILogger<IBMMQHostedService> _logger;
    private readonly IOptions<IBMOptions> _options;
    private readonly ILookup<string, IBMIntegrationEventConsumer> _consumers;

    private readonly int _concurrencyLevel;
    private readonly TimeSpan _workRepeatDelay;

    private ISession? _session;

    private readonly Dictionary<string, IMessageConsumer> _messageConsumers = 
      new Dictionary<string, IMessageConsumer>();
    
    /// <summary>
    /// 
    /// </summary>
    /// <param name="logger"></param>
    /// <param name="options"></param>
    /// <param name="consumers"></param>
    /// <param name="connection"></param>
    public IBMMQHostedService(
      ILogger<IBMMQHostedService> logger,
      IOptions<IBMOptions> options,
      IEnumerable<IBMIntegrationEventConsumer> consumers, 
      IConnection connection)
    {
      _logger = logger ?? throw new ArgumentNullException(nameof(logger));
      _options = options ?? throw new ArgumentNullException(nameof(options));
      _consumers = consumers?.ToLookup(consumer => consumer.QueueName) ?? 
        throw new ArgumentNullException(nameof(consumers));
      var hostedServiceOpts = options.Value.HostedServiceOptions ?? 
        throw new ArgumentNullException(nameof(options.Value.HostedServiceOptions));
      _connection = connection ?? throw new ArgumentNullException(nameof(connection));
      _concurrencyLevel = hostedServiceOpts.ConcurrencyLevel;
      _workRepeatDelay = hostedServiceOpts.WorkRepeatDelay;
    }

    /// <summary>
    /// Срабатывает, когда хост приложения готов запустить службу. Запускает соединение и создает сессию.
    /// </summary>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    public Task StartAsync(CancellationToken cancellationToken)
    {
      _logger.LogInformation("Starting IBM MQ connection");

      _connection.Start();

      _logger.LogInformation("IBM MQ connection started");

      _logger.LogInformation("Starting IBM MQ session");

      _session = _connection.CreateSession(false, AcknowledgeMode.ClientAcknowledge);

      _logger.LogInformation("IBM MQ session started");

      _ = ExecuteAsync(cancellationToken);

      return Task.CompletedTask;
    }

    /// <summary>
    /// Срабатывает, когда хост приложения выполняет плавное завершение работы. Закрывает соединение и сессию.
    /// </summary>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    public Task StopAsync(CancellationToken cancellationToken)
    {

      _logger.LogInformation("IBM MQ service is stopping");

      (_session ?? throw new InvalidOperationException("session is null")).Close();
      _session.Dispose();

      _connection.Close();
      _connection.Dispose();

      return Task.CompletedTask;
    }

    private async Task RepeatWorkAsync(int concurrencyFlow, CancellationToken cancellationToken)
    {
      while (true)
      {

        _logger.LogInformation($"Concurrency flow {concurrencyFlow} is started");

        if (IsCancellationRequested(cancellationToken))
        {
          return;
        }

        var queues = _options.Value.QueueNames;

        foreach (var queue in queues)
        {
          if (IsCancellationRequested(cancellationToken))
          {
            return;
          }

          var consumer = GetMessageConsumer(queue);

          await Task.Yield();

          var msg = (_options.Value.WaitTimeoutMilliseconds > 0) switch
          {
            true => consumer.Receive(_options.Value.WaitTimeoutMilliseconds),
            _ => consumer.ReceiveNoWait()
          };

          var eventHandlers = _consumers[queue];

          foreach (var handler in eventHandlers)
          {
            if (msg != null)
            {
              await handler.HandleAsync(msg, cancellationToken);
            }
          }
        }

        await Task.Delay(_workRepeatDelay, cancellationToken).ConfigureAwait(false);

        _logger.LogInformation($"Concurrency flow {concurrencyFlow} is finished");
      }
    }

    private IMessageConsumer GetMessageConsumer(string queue)
    {
      if (_messageConsumers.TryGetValue(queue, out var messageConsumer))
      {
        return messageConsumer;
      }
      else
      {
        var destination = (_session ?? throw new InvalidOperationException("session is null")).CreateQueue(queue);
        messageConsumer = _session.CreateConsumer(destination);
        _messageConsumers.Add(queue, messageConsumer);
        return messageConsumer;
      }
    }

    private bool IsCancellationRequested(CancellationToken cancellationToken)
    {
      if (cancellationToken.IsCancellationRequested)
      {
        _logger.LogInformation("CancellationToken requested");
        return true;
      }

      return false;
    }

    private async Task ExecuteAsync(CancellationToken cancellationToken)
    {
      try
      {
        if (IsCancellationRequested(cancellationToken))
        {
          return;
        }

        var tasks = Enumerable.Range(0, _concurrencyLevel).Select(
            concurrencyFlow => Task.Run(
              () => RepeatWorkAsync(concurrencyFlow, cancellationToken), cancellationToken))
            .ToArray();

        await Task.WhenAll(tasks).ConfigureAwait(false);
      }
      catch (Exception ex)
      {
        _logger.LogError(ex, "Unexpected exception ExecuteAsync");
      }
    }

  }
}