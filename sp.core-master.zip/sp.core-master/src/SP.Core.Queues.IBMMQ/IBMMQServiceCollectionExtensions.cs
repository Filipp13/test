using System;
using IBM.XMS;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace SP.Core.Queues.IBMMQ
{
  /// <summary>
  /// Методы расширения IBM MQ для IServiceCollection.
  /// </summary>
  public static class IBMMQServiceCollectionExtensions
  {
    /// <summary>
    /// Создает соединение (интерфейс IConnection).
    /// </summary>
    /// <param name="services"></param>
    /// <param name="connectionFactory">конфиг</param>
    /// <param name="ibmOptions">конфиг</param>
    /// <returns></returns>
    public static IServiceCollection AddIbmMqConnection(
      this IServiceCollection services,
      IConnectionFactory connectionFactory,
      IBMOptions ibmOptions)
    {
      var ibmOpts = ibmOptions ?? throw new ArgumentNullException(nameof(ibmOptions));

      connectionFactory.SetStringProperty(XMSC.WMQ_HOST_NAME, ibmOpts.BaseAddress);
      connectionFactory.SetIntProperty(XMSC.WMQ_PORT, ibmOpts.Port);
      connectionFactory.SetStringProperty(XMSC.WMQ_CHANNEL, ibmOpts.Channel);
      connectionFactory.SetIntProperty(XMSC.WMQ_CONNECTION_MODE, XMSC.WMQ_CM_CLIENT);
      connectionFactory.SetStringProperty(XMSC.WMQ_QUEUE_MANAGER, ibmOpts.QueueManager);

      var connection = connectionFactory.CreateConnection();

      services.TryAddSingleton(provider => connection);

      return services;
    }

    /// <summary>
    /// Добавляет IBM MQ с поллингом сообщений.
    /// </summary>
    /// <param name="services"></param>
    /// <param name="configuration">конфиг</param>
    /// <returns></returns>
    public static IServiceCollection AddIbmMq(
      this IServiceCollection services,
      IConfiguration configuration)
    {
      var config = configuration ?? 
                   throw new ArgumentNullException(nameof(configuration));
      var ibmOptions = config.GetSection(IBMOptions.SectionName) ?? 
                       throw new ArgumentNullException(IBMOptions.SectionName);

      services.AddOptions<IBMOptions>().Bind(ibmOptions);
      services.AddHostedService<IBMMQHostedService>();

      return services;
    }

  }
}