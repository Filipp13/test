﻿using NUnit.Framework;
using SP.Core.Mediator;

namespace SP.Core.Extensions.Mediator.Tests.Fake
{
  public class CommandReceiver : IMessageHandler<Command>
  {
    public void Handle(Command message)
    {
      TestContext.WriteLine($"The {nameof(CommandReceiver)} received {message.GetType().FullName}");
    }
  }
}