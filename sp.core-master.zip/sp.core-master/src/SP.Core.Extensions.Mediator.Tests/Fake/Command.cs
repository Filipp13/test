﻿using SP.Core.Mediator;

namespace SP.Core.Extensions.Mediator.Tests.Fake
{
  public class Command : ICommand
  {
    public int Minimum => int.MinValue;
  }
}