﻿using NUnit.Framework;
using SP.Core.Mediator;

namespace SP.Core.Extensions.Mediator.Tests.Fake
{
  public class RequestHandler : IMessageHandler<Request, int>
  {
    public const int Result = 10;

    public int Handle(Request message)
    {
      TestContext.WriteLine($"The {nameof(RequestHandler)} handled {message.GetType().FullName}");
      return Result;
    }
  }
}