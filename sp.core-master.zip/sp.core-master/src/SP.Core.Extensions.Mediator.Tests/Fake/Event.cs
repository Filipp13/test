﻿using System;
using SP.Core.Mediator.Seedwork;

namespace SP.Core.Extensions.Mediator.Tests.Fake
{
  public class Event : IEvent
  {
    public Guid Id { get; set; } = Guid.NewGuid();
  }
}