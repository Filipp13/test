﻿using NUnit.Framework;
using SP.Core.Mediator;

namespace SP.Core.Extensions.Mediator.Tests.Fake
{
  public class EventListener : IMessageHandler<Event>
  {
    public void Handle(Event message)
    {
      TestContext.WriteLine($"The {nameof(EventListener)} listened {message.GetType().FullName}");
    }
  }
}