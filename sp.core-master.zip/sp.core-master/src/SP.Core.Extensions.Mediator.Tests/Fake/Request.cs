﻿using SP.Core.Mediator;

namespace SP.Core.Extensions.Mediator.Tests.Fake
{
  public class Request : IRequest
  {
  }
}