using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;
using SP.Core.Extensions.Mediator.Tests.Fake;
using SP.Core.Mediator;

namespace SP.Core.Extensions.Mediator.Tests
{
  [TestFixture(Category = "Integration")]
  public class MediatorServiceCollectionExtensionsTests
  {
    [SetUp]
    public void Setup()
    {
      _services = new ServiceCollection();
    }

    private IServiceCollection _services;

    [Test]
    public void AddMediator()
    {
      _services.AddDefaultMediator();

      var provider = _services.BuildServiceProvider();

      Assert.IsNotNull(provider.GetRequiredService<IMediator>());
    }

    [Test]
    public void ResolveMediatorWithDependencies()
    {
      _services.AddDefaultMediator()
        .AddRequestHandler<RequestHandler>()
        .AddEventListener<EventListener>()
        .AddCommandReceiver<CommandReceiver>();

      var provider = _services.BuildServiceProvider();

      Assert.Multiple(() =>
      {
        var mediator = provider.GetRequiredService<IMediator>();

        Assert.AreEqual(RequestHandler.Result, mediator.SendMessage<Request, int>(new Request()));
        Assert.DoesNotThrow(() => mediator.SendMessage(new Command()));
        Assert.DoesNotThrow(() => mediator.SendMessage(new Event()));
      });
    }
  }
}