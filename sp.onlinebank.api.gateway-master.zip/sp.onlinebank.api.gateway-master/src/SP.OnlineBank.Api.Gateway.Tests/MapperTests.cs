﻿using DeepEqual.Syntax;
using Microsoft.Extensions.Options;
using NUnit.Framework;
using SP.OnlineBank.Api.Gateway.Configuration;
using SP.OnlineBank.Api.Gateway.Map;
using System.Collections.Generic;
using System.Linq;
using SP.OnlineBank.Api.Gateway.Models.Offers;


namespace SP.OnlineBank.Api.Gateway.Tests
{
    public class MapperTests
    {
        [Test]
        public void MapProductsAndResourcesToOfferDto()
        {
            var mapper = new Mapper();
            var offers = mapper.Map(DataGenerator.GenerateCultures());

            var expected = new List<Offer> { new Offer("gpc", "lpc", null,null, null, null, null,  new ProductName("name", "type") ) };

            offers.ShouldDeepEqual(expected);
        }

        [Test]
        public void MapProductAndResourcesToOfferDto()
        {
            var mapper = new Mapper();
            var offers = mapper.Map(DataGenerator.GenerateCultures().First());

            var expected = new Offer("gpc", "lpc", null, null, null, null, null,  new ProductName("name", "type"));

            offers.ShouldDeepEqual(expected);
        }
    }
  
}
