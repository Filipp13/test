﻿using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;
using SP.OnlineBank.Api.Gateway.Configuration;
using SP.OnlineBank.Api.Gateway.Controllers;
using SP.OnlineBank.Api.Gateway.Map;
using SP.Resources.Api.HttpClient;
using SP.Resources.Api.HttpClient.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SP.OnlineBank.Api.Gateway.Tests
{
    public class OffersControllerTests
    {
        [Test]
        public async Task GetAsyncExpectedOk()
        {
            
            var resourcesServiceMock = new Mock<IResourcesService>();
            resourcesServiceMock.Setup(a => a.GetAsync()).Returns(() => Task.FromResult(DataGenerator.GenerateCultures()));

            var mapper = new Mock<IMapper>();

            var offersController = new OffersController(resourcesServiceMock.Object, mapper.Object);

            var offers = await offersController.GetAsync();

            resourcesServiceMock.Verify(service => service.GetAsync(), Times.Once);
        }

        [Test]
        public async Task GetAsyncWithLPC_GPCExpectedOk()
        {
           
            var resourcesServiceMock = new Mock<IResourcesService>();
            resourcesServiceMock.Setup(a => a.GetAsync(It.IsAny<string>(), It.IsAny<string>())).Returns(() => Task.FromResult(DataGenerator.GenerateCultures().FirstOrDefault()));
            var mapper = new Mock<IMapper>();
            var offersController = new OffersController(resourcesServiceMock.Object, mapper.Object);

            var offers = await offersController.GetAsync("test","test");

            resourcesServiceMock.Verify(service => service.GetAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }

    }
}
