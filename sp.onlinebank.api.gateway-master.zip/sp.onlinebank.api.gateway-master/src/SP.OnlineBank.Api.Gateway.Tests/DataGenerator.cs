﻿
using SP.Resources.Api.HttpClient.Models;
using System.Collections.Generic;
using System.Linq;

namespace SP.OnlineBank.Api.Gateway.Tests
{
    public static class DataGenerator
    {


        public static IEnumerable<Resource> GenerateResources()
        {
            return new List<Resource> {
                new Resource {
                    /*OfferId = Guid.Parse("47f4dc7a-acdf-4d4c-8c91-869098cdd023"),
                    CultureName = "en",*/
                    Key ="Tesr",
                    MediaType = "text",
                    Value = "test"
                },
                new Resource
                {
                    Key = "ProductName",
                    MediaType = "application/json",
                    Value = "{ \"name\": \"name\", \"type\": \"type\"}"
                }
            };
        }

        public static IEnumerable<Culture> GenerateCultures()
        {
            return new List<Culture> {
                new Culture {
                     Gpc = "gpc",
                     Lpc = "lpc",
                     Name = "name",
                     Resources = GenerateResources().ToList().AsReadOnly(),
                }
            };
        }
    }
}
