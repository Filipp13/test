﻿using NUnit.Framework;
using System.Linq;
using System.Text.Json;
using SP.OnlineBank.Api.Gateway.Models.Offers;

namespace SP.OnlineBank.Api.Gateway.Tests.JsonResourcesTests
{
    public class InterestRateTests
    {
        private readonly JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };

        [Test]
        public void DeserializeAccrualScheme()
        {
            var json = "{                         \"header\": \"Процентная ставка\",                         \"description\": \"Ставка не зависит от суммы вклада.Выберите срок и зафиксируйте ставку\",                         \"rates\": [                             {                                 \"rate\": \"0,01 % \",                                 \"period\": \"от 31 до 90 дней\"                             },                             {                                 \"rate\": \"3,4 % \",                                 \"period\": \"от 181 до 365 дней\"                             }                         ]}";

            var interestRate = JsonSerializer.Deserialize<InterestRate>(json, jsonSerializerOptions);
            Assert.IsNotNull(interestRate);
            Assert.IsNotNull(interestRate.Header);
            Assert.IsNotNull(interestRate.Description);
            Assert.IsNotNull(interestRate.Rates);
            Assert.AreEqual(2, interestRate.Rates.Count());
            Assert.IsNotNull(interestRate.Rates.FirstOrDefault());
            Assert.IsNotNull(interestRate.Rates.FirstOrDefault().Period);
            Assert.IsNotNull(interestRate.Rates.FirstOrDefault().Rate);
        }
    }
}
