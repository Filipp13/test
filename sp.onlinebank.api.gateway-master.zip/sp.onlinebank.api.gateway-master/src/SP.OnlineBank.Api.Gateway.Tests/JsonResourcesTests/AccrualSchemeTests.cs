﻿using NUnit.Framework;
using System.Text.Json;
using SP.OnlineBank.Api.Gateway.Models.Offers;

namespace SP.OnlineBank.Api.Gateway.Tests.JsonResourcesTests
{
    public class AccrualSchemeTests
    {
        private static readonly JsonSerializerOptions JsonSerializerOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };

        [Test]
        public void DeserializeAccrualScheme()
        {
            var json = "{\"description\": \"Начисляем проценты на остаток ежедневно...\",                         " +
                       "\"example\": { \"header\": \"Например\",\"description\": \"Первого июля на счете 50000Р.Через 7 дней вы добавили к ним еще 50000Р, ...\"," +
                       "\"histogram\": [" +
                       " { \"description\": \"1-7й день\", \"value\": 100000, \"orderPriority\": 0}," +
                       " { \"description\": \"8-17й день\", \"value\": 70000, \"orderPriority\": 1}," +
                       " { \"description\": \"18-31й день\", \"value\": 120000, \"orderPriority\": 2}" +
                       "]}," +
                       "\"exampleExplanation\":{\"header\": \"Начислим проценты\", \"explanation\": [ \"7 дней на остаток 50000Р\",  \"3 дня на остаток 100000Р\", \"7 дней на остаток 70000р\"                             ], " +
                       "\"descriptionTemplate\": \"Первого августа начислится { sum}\", " +
                       "\"descriptionBoldValues\": [" +
                       "{ \"placeholder\": \"sum\", \"value\": \"190.48 Р\" }]," +
                       "\"legalOffert\": \"Этот рачсет носит информационный характер...\"                         }," +
                       " \"isminbalance\": true                            }";

            var scheme = JsonSerializer.Deserialize<AccrualScheme>(json, JsonSerializerOptions);
            
            Assert.IsNotNull(scheme);
            Assert.Multiple(() =>
            {
                Assert.IsNotNull(scheme!.Description);
                Assert.IsNotNull(scheme!.Example);
                Assert.IsNotNull(scheme!.ExampleExplanation);
                Assert.True(scheme!.IsMinBalance);
            });
        }
    }
}
