﻿using NUnit.Framework;
using System.Text.Json;
using SP.OnlineBank.Api.Gateway.Models.Offers;

namespace SP.OnlineBank.Api.Gateway.Tests.JsonResourcesTests
{
    public class ProductNameTests
    {
        private readonly JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };

        [Test]
        public void DeserializeProductNameScheme()
        {
            var json = "{       \"name\": \"На каждый день\",       \"type\": \"Накопительный счет\"   }";
            var product = JsonSerializer.Deserialize<ProductName>(json, jsonSerializerOptions);
            Assert.IsNotNull(product);
            Assert.Multiple(() =>
            {
                Assert.IsNotNull(product!.Name);
                Assert.IsNotNull(product!.Type);
            });
        }
    }
}
