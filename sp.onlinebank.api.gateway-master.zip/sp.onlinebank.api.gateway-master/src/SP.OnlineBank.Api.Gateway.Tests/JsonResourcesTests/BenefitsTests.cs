﻿using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using SP.OnlineBank.Api.Gateway.Models.Offers;

namespace SP.OnlineBank.Api.Gateway.Tests.JsonResourcesTests
{
    public class BenefitsTests
    {
        private readonly JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };

        [Test]
        public void DeserializeAccrualScheme()
        {
            var json = "[ { \"header\": \"Годовая ставка 3%\", \"description\": \"При балансе счёта до 20 000 000 Р, далее 0,01%\" },                         { \"header\": \"Процент на ежедневный остаток\", \"description\": \"Доход на остаток на счёте на каждый день. Выплачиваем проценты первого числа каждого месяца\" },                         { \"header\": \"Снятие и пополнение\", \"description\": \"Пополняйте без комиссии с карт других банков\" }                     ]";

            var benefits = JsonSerializer.Deserialize<IEnumerable<Benefits>>(json, jsonSerializerOptions);
            Assert.IsNotNull(benefits);
            Assert.AreEqual(3, benefits.Count());
            Assert.IsNotNull(benefits.FirstOrDefault());
            Assert.IsNotNull(benefits.FirstOrDefault().Description);
            Assert.IsNotNull(benefits.FirstOrDefault().Header);
        }
    }
}
