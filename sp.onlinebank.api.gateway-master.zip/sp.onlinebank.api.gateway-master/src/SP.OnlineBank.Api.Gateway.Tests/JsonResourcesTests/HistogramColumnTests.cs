using System.Collections.Generic;
using System.Text.Json;
using NUnit.Framework;
using SP.OnlineBank.Api.Gateway.Models.Offers;

namespace SP.OnlineBank.Api.Gateway.Tests.JsonResourcesTests
{
    [TestFixture, TestOf(typeof(HistogramColumn))]
    public class HistogramColumnTests
    {
        private static readonly JsonSerializerOptions JsonSerializerOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        [Test]
        public void Deserialize_Success()
        {
            var json = " { \"description\": \"1-7й день\", \"value\": 100000, \"orderPriority\": 7}";

            var column = JsonSerializer.Deserialize<HistogramColumn>(json, JsonSerializerOptions);
            
            Assert.NotNull(column);
            Assert.Multiple(() =>
            {
                Assert.AreEqual(column!.Description, "1-7й день");
                Assert.AreEqual(column!.Value, 100000);
                Assert.AreEqual(column!.OrderPriority, 7);
            });
        }
    }
}