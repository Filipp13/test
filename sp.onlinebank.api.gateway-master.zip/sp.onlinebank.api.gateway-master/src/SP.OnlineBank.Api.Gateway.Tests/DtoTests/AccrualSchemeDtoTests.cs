﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SP.OnlineBank.Api.Gateway.Models.Offers;

namespace SP.OnlineBank.Api.Gateway.Tests.DtoTests
{
    public class AccrualSchemeDtoTests
    {
        [Test]
        public void AccrualSchemeDtoDescriptionNull()
        {
            var ex = Assert.Throws<ArgumentNullException>(() => new AccrualScheme(null!, new Example("", "", new List<HistogramColumn>()), null!, false));
            Assert.That(ex.ParamName, Is.EqualTo("description"));
        }

        [Test]
        public void AccrualSchemeDtoExampleDtoNull()
        {
            var ex = Assert.Throws<ArgumentNullException>(() => new AccrualScheme("", null!, null!, false));
            Assert.That(ex.ParamName, Is.EqualTo("example"));
        }

        [Test]
        public void AccrualSchemeDtoExampleExplanationNull()
        {
            var ex = Assert.Throws<ArgumentNullException>(() => new AccrualScheme("", new Example("", "", new List<HistogramColumn>()), null!, false));
            Assert.That(ex.ParamName, Is.EqualTo("exampleExplanation"));
        }

        [Test]
        public void AccrualSchemeDtoOk()
        {
            var dto = new AccrualScheme("", new Example("", "", new List<HistogramColumn>()), new ExampleExplanation("", new string[] { }, "", new List<DescriptionTemplateValue>(), ""), true);
            Assert.IsNotNull(dto);
            Assert.IsTrue(dto.IsMinBalance);
            Assert.IsNotNull(dto.Description);
            Assert.IsNotNull(dto.Example);
            Assert.IsNotNull(dto.Example.Description);
            Assert.IsNotNull(dto.Example.Header);
            Assert.IsNotNull(dto.Example.Histogram);
            Assert.IsNotNull(dto.ExampleExplanation);
            Assert.IsNotNull(dto.ExampleExplanation.DescriptionBoldValues);
            Assert.IsNotNull(dto.ExampleExplanation.Explanation);
            Assert.IsNotNull(dto.ExampleExplanation.DescriptionTemplate);
            Assert.IsNotNull(dto.ExampleExplanation.Header);
            Assert.IsNotNull(dto.ExampleExplanation.LegalOffert);
        }
    }
}
