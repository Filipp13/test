﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SP.OnlineBank.Api.Gateway.Models.Offers;

namespace SP.OnlineBank.Api.Gateway.Tests.DtoTests
{
    public class InterestRateDtoTests
    {
        [Test]
        public void InterestRateDtoHeaderNull()
        {
            var ex = Assert.Throws<ArgumentNullException>(() => new InterestRate(null!, "", new RateM[] { }));
            Assert.That(ex.ParamName, Is.EqualTo("header"));
        }

        [Test]
        public void InterestRateDtoDescriptionCanBeNull()
        {
            Assert.DoesNotThrow(() => new InterestRate("", null!, new RateM[] { }));
        }

        [Test]
        public void InterestRateDtoRatesNull()
        {
            var ex = Assert.Throws<ArgumentNullException>(() => new InterestRate("", "", null!));
            Assert.That(ex.ParamName, Is.EqualTo("rates"));
        }


    }
}
