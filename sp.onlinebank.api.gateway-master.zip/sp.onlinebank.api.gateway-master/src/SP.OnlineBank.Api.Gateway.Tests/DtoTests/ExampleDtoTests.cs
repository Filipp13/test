﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SP.OnlineBank.Api.Gateway.Models.Offers;

namespace SP.OnlineBank.Api.Gateway.Tests.DtoTests
{
    public class ExampleDtoTests
    {
        [Test]
        public void ExampleDtoHeaderNull()
        {
            var ex = Assert.Throws<ArgumentNullException>(() => new Example(null!, "", new List<HistogramColumn>()));
            Assert.That(ex.ParamName, Is.EqualTo("header"));
        }

        [Test]
        public void ExampleDtoDescriptionNull()
        {
            var ex = Assert.Throws<ArgumentNullException>(() => new Example("", null!, new List<HistogramColumn>()));
            Assert.That(ex.ParamName, Is.EqualTo("description"));
        }

        [Test]
        public void ExampleDtoHistogramCanBeNull()
        {
            Assert.DoesNotThrow(() => new Example("", "", null!));
        }
    }
}
