﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SP.OnlineBank.Api.Gateway.Models.Offers;

namespace SP.OnlineBank.Api.Gateway.Tests.DtoTests
{
    public class OfferDtoTests
    {
        [Test]
        public void OfferGPCNull()
        {
            var ex = Assert.Throws<ArgumentNullException>(() => new Offer(
                null!,
                "", 
                "",
                "",
                new Benefits[] { }, 
                new InterestRate("", "", new RateM[] { }),
                new AccrualScheme("", new Example("", "", new List<HistogramColumn>()), new ExampleExplanation("", new string[] { }, "", new List<DescriptionTemplateValue>(), ""), false),
                 null));

            Assert.That(ex.ParamName, Is.EqualTo("gpc"));
        }

        [Test]
        public void OfferLPCNull()
        {
            var ex = Assert.Throws<ArgumentNullException>(() => new Offer(
                "",
                null!,
                "",
                "",
                new Benefits[] { },
                new InterestRate("", "", new RateM[] { }),
                new AccrualScheme("", new Example("", "", new List<HistogramColumn>()), new ExampleExplanation("", new string[] { }, "", new List<DescriptionTemplateValue>(), ""), false),
                 null));

            Assert.That(ex.ParamName, Is.EqualTo("lpc"));
        }

    }
}
