﻿using NUnit.Framework;
using System;
using SP.OnlineBank.Api.Gateway.Models.Offers;

namespace SP.OnlineBank.Api.Gateway.Tests.DtoTests
{
    public class RateDtoTests
    {
        [Test]
        public void RateDtoRateNull()
        {
            var ex = Assert.Throws<ArgumentNullException>(() => new RateM(
                null!,
                ""));

            Assert.That(ex.ParamName, Is.EqualTo("rate"));
        }

        [Test]
        public void RateDtoPeriodCanbeNull()
        {
            Assert.DoesNotThrow(() => new RateM(
                "",
                null!));
        }

    }
}
