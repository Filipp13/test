using System;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;

namespace SP.OnlineBank.Api.Gateway.Conventions
{
  public static class OnlineBankConventions
  {
    [ProducesDefaultResponseType]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Prefix)]
    public static void Get(
      [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Suffix)]
      [ApiConventionTypeMatch(ApiConventionTypeMatchBehavior.Any)]
      object id)
    {
    }

    [ProducesDefaultResponseType]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Prefix)]
    public static void Find(
      [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Suffix)]
      [ApiConventionTypeMatch(ApiConventionTypeMatchBehavior.Any)]
      object id)
    {
    }

    [ProducesDefaultResponseType]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Exact)]
    public static void Validate()
    {
    }

    [ProducesDefaultResponseType]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status417ExpectationFailed)]
    [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Prefix)]
    public static void Init(
      [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Any)]
      [ApiConventionTypeMatch(ApiConventionTypeMatchBehavior.Any)]
      object model)
    {
    }

    [ProducesDefaultResponseType]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status417ExpectationFailed)]
    [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Prefix)]
    public static void Post(
      [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Any)]
      [ApiConventionTypeMatch(ApiConventionTypeMatchBehavior.Any)]
      object model)
    {
    }

    [ProducesDefaultResponseType]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status417ExpectationFailed)]
    [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Prefix)]
    public static void Post(
      Guid requestId,
      [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Any)]
      [ApiConventionTypeMatch(ApiConventionTypeMatchBehavior.Any)]
      object model)
    {
    }


    [ProducesDefaultResponseType]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status417ExpectationFailed)]
    [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Prefix)]
    public static void Put(
      [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Suffix)]
      [ApiConventionTypeMatch(ApiConventionTypeMatchBehavior.Any)]
      object id,
      [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Any)]
      [ApiConventionTypeMatch(ApiConventionTypeMatchBehavior.Any)]
      object model)
    {
    }

    [ProducesDefaultResponseType]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status417ExpectationFailed)]
    [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Prefix)]
    public static void Put(
      [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Suffix)]
      [ApiConventionTypeMatch(ApiConventionTypeMatchBehavior.Any)]
      object id,
      [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Suffix)]
      [ApiConventionTypeMatch(ApiConventionTypeMatchBehavior.Any)]
      object signMethod,
      [ApiConventionNameMatch(ApiConventionNameMatchBehavior.Any)]
      [ApiConventionTypeMatch(ApiConventionTypeMatchBehavior.Any)]
      object model)
    {
    }
  }
}