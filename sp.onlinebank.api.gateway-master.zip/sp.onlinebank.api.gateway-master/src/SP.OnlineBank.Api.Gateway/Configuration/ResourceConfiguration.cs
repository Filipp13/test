﻿using System.Collections.Generic;

namespace SP.OnlineBank.Api.Gateway.Configuration
{
  public class ResourceConfiguration
  {
    public IEnumerable<string> Keys { get; set; }
  }
}
