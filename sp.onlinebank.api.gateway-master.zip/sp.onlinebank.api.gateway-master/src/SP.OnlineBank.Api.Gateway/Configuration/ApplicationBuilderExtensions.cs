using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Rewrite;

namespace SP.OnlineBank.Api.Gateway.Configuration
{
  public static class ApplicationBuilderExtensions
  {
    public static IApplicationBuilder UseRewriter(this IApplicationBuilder builder, string stub)
    {
      var options = new RewriteOptions()
                    .AddRewrite(@"[Aa]ccounts/(.*)/sms", "api/v1/accounts/$1/SMSOTP", true)
                    .AddRewrite(@"[Aa]ccounts/(.*)/SMS", "api/v1/accounts/$1/SMSOTP", true)
                    .AddRewrite(@"[Aa]ccounts/(.*)/push", "api/v1/accounts/$1/PUSHOTP", true)
                    .AddRewrite(@"[Aa]ccounts/(.*)/PUSH", "api/v1/accounts/$1/PUSHOTP", true);

      return builder.UseRewriter(options);
    }
  }
}