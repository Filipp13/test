﻿using System.Collections.Generic;
using SP.OnlineBank.Api.Gateway.Models.Offers;
using SP.Resources.Api.HttpClient.Models;

namespace SP.OnlineBank.Api.Gateway.Map
{
  public interface IMapper
  {
    Offer Map(Culture culture);

    IEnumerable<Offer> Map(IEnumerable<Culture> cultures);
  }
}
