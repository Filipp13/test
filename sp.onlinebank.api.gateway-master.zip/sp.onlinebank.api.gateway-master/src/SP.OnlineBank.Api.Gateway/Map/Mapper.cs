﻿using System;
using SP.Resources.Api.HttpClient.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using SP.OnlineBank.Api.Gateway.Models.Offers;

namespace SP.OnlineBank.Api.Gateway.Map
{
    public class Mapper : IMapper
    {
        private static readonly JsonSerializerOptions JsonSerializerOptions =
            new() { PropertyNameCaseInsensitive = true };

        private const string Benefits = "Benefits";
        private const string InterestRate = "InterestRate";
        private const string AccrualScheme = "AccrualScheme";
        private const string TariffLink = "TariffLink";
        private const string ProductName = "ProductName";
        private const string MoneyInsurance = "MoneyInsurance";
        
        private readonly string[] _resourcesKeys = {
            Benefits,
            InterestRate,
            AccrualScheme,
            TariffLink,
            ProductName,
            MoneyInsurance };

        public Offer Map(Culture culture)
        {
            var resources = culture.Resources?.Where(q => _resourcesKeys.Contains(q.Key)).ToList()
                            ?? throw new Exception("Resources are null");
            
            return new Offer(
                culture.Gpc,
                culture.Lpc,
                GetStringValueByKey(resources, TariffLink),
                GetStringValueByKey(resources, MoneyInsurance),
                GetDeserializedByKey<IEnumerable<Benefits>>(resources, Benefits),
                GetDeserializedByKey<InterestRate>(resources, InterestRate),
                GetDeserializedByKey<AccrualScheme>(resources, AccrualScheme),
                GetDeserializedByKey<ProductName>(resources, ProductName));
        }

        public IEnumerable<Offer> Map(IEnumerable<Culture> cultures) => cultures.Select(Map);
        
        private static string? GetStringValueByKey(IEnumerable<Resource> source, string key) 
            => source.FirstOrDefault(q => q.Key == key)?.Value;

        private static T? GetDeserializedByKey<T>(IEnumerable<Resource> resources, string key)
        {
            var json = GetStringValueByKey(resources, key);
            if (string.IsNullOrEmpty(json))
                return default;
            return JsonSerializer.Deserialize<T>(json, JsonSerializerOptions);
        }
    }
}
