namespace SP.OnlineBank.Api.Gateway.Authentication
{
  public class ClientCredentialsOptions
  {
    public string ClientId { get; set; }
    public string ClientSecret { get; set; }
  }
}