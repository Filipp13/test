namespace SP.OnlineBank.Api.Gateway.Authentication
{
  public static class OnlineBankDefault
  {
    public const string AuthenticationScheme = "OnlineBank";
    public const string MFAAuthenticationScheme = "OneTimePassword";
    public const string Role = "OnlineBankUser";
  }
}