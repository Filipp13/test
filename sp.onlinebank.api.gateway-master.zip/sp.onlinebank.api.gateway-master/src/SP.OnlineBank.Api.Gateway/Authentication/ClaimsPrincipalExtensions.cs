using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using SP.OnlineBank.Api.Gateway.Authorization;
using SP.OnlineBank.Api.Gateway.Models.Accounts;

namespace SP.OnlineBank.Api.Gateway.Authentication
{
  public static class ClaimsPrincipalExtensions
  {
    public static Claim? GetAccessToken(this ClaimsPrincipal user)
    {
      return user.Claims.SingleOrDefault(claim => claim.Type == "access_token");
    }

    public static IEnumerable<ConfirmationMethod> GetConfirmationMethods(this ClaimsPrincipal user)
    {
      return user.Claims
                 .Where(type =>
                   type.Type == OnlineBankJwtClaimTypes.ConfirmationMethods &&
                   !string.Equals(type.Value, ConfirmationMethods.STUBOTP.ToString(),
                     StringComparison.CurrentCultureIgnoreCase))
                 .Select(s => new ConfirmationMethod
                 {
                   Method = s.Value.ToLower() == ConfirmationMethods.SMSOTP.ToString().ToLower()
                     ? ConfirmationMethods.SMSOTP
                     : ConfirmationMethods.PUSHOTP
                 }).ToList();
    }

    public static long GetRcasId(this ClaimsPrincipal user)
    {
      Claim? rcasIdClaim = user.Claims.FirstOrDefault(claim => claim.Type == OnlineBankJwtClaimTypes.RcasIdClaimType);
      var parsed = long.TryParse(rcasIdClaim?.Value, out var rcasId);

      return parsed ? rcasId : long.MinValue;
    }
    
    public static string? GetAppId(this ClaimsPrincipal user)
    {
      Claim? rcasAppIdClaim = user.Claims.FirstOrDefault(
        claim => claim.Type == OnlineBankJwtClaimTypes.RcasAppIdClaimType);

      return rcasAppIdClaim?.Value;
    }

    public static string GetRcasSignedDocument(this ClaimsPrincipal user)
    {
      Claim? rcasSignedDocumentClaim =
        user.Claims.FirstOrDefault(claim => claim.Type == OnlineBankJwtClaimTypes.RcasSignedDocumentClaimType);

      return rcasSignedDocumentClaim != null ? rcasSignedDocumentClaim.Value : string.Empty;
    }

    public static DateTime GetRcasDocumentSignOn(this ClaimsPrincipal user)
    {
      Claim? rcasSignOnClaim =
        user.Claims.FirstOrDefault(claim => claim.Type == OnlineBankJwtClaimTypes.RcasDocumentSignOnClaimType);
      var parsed = DateTime.TryParse(rcasSignOnClaim?.Value, out DateTime signOn);

      return parsed ? signOn : DateTime.Now;
    }

    public static int? GetRepeatOtpWaitInterval(this ClaimsPrincipal user)
    {
      Claim? waitIntervalClaim =
        user.Claims.FirstOrDefault(claim => claim.Type == OnlineBankJwtClaimTypes.RepeatOtpWaitIntervalClaimType);
      var parsed = int.TryParse(waitIntervalClaim?.Value, out var interval);

      return 120000;
    }
  }
}