using System;
using IdentityModel.AspNetCore.OAuth2Introspection;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SP.OnlineBank.Api.Gateway.Authentication;

namespace SP.OnlineBank.Api.Gateway.DependencyInjection
{
  public static class OAuth2IntrospectionAuthenticationBuilderExtensions
  {
    private const string ConfigurationSection = "Authentication:OnlineBank";

    public static AuthenticationBuilder AddOAuth2Introspection(
      this AuthenticationBuilder builder,
      IConfiguration configuration,
      IWebHostEnvironment hostEnvironment)
    {
      if (builder == null)
      {
        throw new ArgumentNullException(nameof(builder));
      }

      if (configuration == null)
      {
        throw new ArgumentNullException(nameof(configuration));
      }

      if (hostEnvironment == null)
      {
        throw new ArgumentNullException(nameof(hostEnvironment));
      }

      builder.AddOAuth2Introspection(OnlineBankDefault.AuthenticationScheme);

      ClientCredentialsOptions? clientCredentialsOptions =
        configuration.GetSection("Authentication").Get<ClientCredentialsOptions>();

      builder.Services.Configure<OAuth2IntrospectionOptions>(OnlineBankDefault.AuthenticationScheme,
        configuration.GetSection(ConfigurationSection));

      builder.Services.Configure<OAuth2IntrospectionOptions>(
        OnlineBankDefault.AuthenticationScheme,
        options =>
        {
          options.ClientId = clientCredentialsOptions.ClientId;
          options.ClientSecret = clientCredentialsOptions.ClientSecret;
        });

      return builder;
    }
  }
}