using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Extensions.DependencyInjection;

namespace SP.OnlineBank.Api.Gateway.DependencyInjection
{
  public static class MvcServiceCollectionExtensions
  {
    public static IServiceCollection AddConfiguredControllers(this IServiceCollection services)
    {
      services.AddControllers()
              .AddMvcOptions(options => options.AllowEmptyInputInBodyModelBinding = true)
              .AddJsonOptions(options =>
              {
                options.JsonSerializerOptions.IgnoreNullValues = true;
                options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
              });

      return services;
    }
  }
}