using System;
using System.IO;
using System.Reflection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace SP.OnlineBank.Api.Gateway.DependencyInjection
{
  public static class SwaggerServiceCollectionExtensions
  {
    private const string ConfigurationSection = "SwaggerGenerator";

    public static IServiceCollection AddSwagger(
      this IServiceCollection services,
      IConfiguration configuration,
      IWebHostEnvironment hostEnvironment)
    {
      if (services == null)
      {
        throw new ArgumentNullException(nameof(services));
      }

      if (configuration == null)
      {
        throw new ArgumentNullException(nameof(configuration));
      }

      if (hostEnvironment == null)
      {
        throw new ArgumentNullException(nameof(hostEnvironment));
      }

      return services.AddSwaggerGen(options =>
                     {
                       var schema = new OpenApiSecurityScheme
                       {
                         In = ParameterLocation.Header,
                         Description = "Please insert JWT with Bearer into field",
                         Name = "Authorization",
                         Scheme = "Bearer",
                         Type = SecuritySchemeType.Http,
                         Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
                       };
                       
                       options.AddSecurityDefinition("Bearer", schema);
                       options.AddSecurityRequirement(new OpenApiSecurityRequirement
                       {
                         {
                           schema,
                           Array.Empty<string>()
                         }
                       });

                       GetXmlDocFilePhysicalPath(options, hostEnvironment);
                     })
                     .Configure<SwaggerGeneratorOptions>(configuration.GetSection(ConfigurationSection))
                     .Configure<SwaggerGeneratorOptions>(options =>
                     {
                       if (options.SwaggerDocs.TryGetValue(hostEnvironment.ApplicationName, out var info))
                       {
                         info.Version = Assembly.GetEntryAssembly()?.GetName().Version?.ToString() ?? "1.0.0";
                       }
                     });
    }

    private static void GetXmlDocFilePhysicalPath(SwaggerGenOptions options, IWebHostEnvironment env)
    {
      string[]? xmlFiles = Directory.GetFiles(env.ContentRootPath, "*.xml", SearchOption.AllDirectories);

      foreach (var xmlFile in xmlFiles)
      {
        options.IncludeXmlComments(xmlFile);
      }
    }
  }
}