using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace SP.OnlineBank.Api.Gateway.DependencyInjection
{
  public static class ServiceCollectionDistributedCacheExtensions
  {
    public static IServiceCollection AddDistributedSqlServerCache(this IServiceCollection services,
      IConfiguration config)
    {
      return services.AddDistributedSqlServerCache(options =>
      {
        options.ConnectionString = config.GetConnectionString("Cache");
        options.SchemaName = "SP";
        options.TableName = "ApiGateway";
      });
    }
  }
}