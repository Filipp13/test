using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SP.OnlineBank.Api.Gateway.Authentication;
using SP.OnlineBank.Api.Gateway.Authorization;
using SP.OnlineBank.Api.Gateway.Models.Accounts;

namespace SP.OnlineBank.Api.Gateway.DependencyInjection
{
  public static class PolicyServiceCollectionExtensions
  {
    public static IServiceCollection AddAuthorization(
      this IServiceCollection services,
      IConfiguration configuration,
      IWebHostEnvironment hostEnvironment)
    {
      return services.AddAuthorization(options =>
      {
        options.AddPolicy(OnlineBankDefault.AuthenticationScheme, builder =>
        {
          builder
            .RequireAuthenticatedUser()
            .RequireRole(OnlineBankDefault.Role)
            .RequireClaim(
              OnlineBankJwtClaimTypes.ConfirmationMethods,
              ConfirmationMethods.SMSOTP.ToString(),
              ConfirmationMethods.PUSHOTP.ToString());
        });

        options.AddPolicy(OnlineBankDefault.MFAAuthenticationScheme, builder =>
        {
          builder.Combine(options.GetPolicy(OnlineBankDefault.AuthenticationScheme));
          builder.Requirements.Add(new OneTimePasswordRequirement());
        });
      });
    }
  }
}