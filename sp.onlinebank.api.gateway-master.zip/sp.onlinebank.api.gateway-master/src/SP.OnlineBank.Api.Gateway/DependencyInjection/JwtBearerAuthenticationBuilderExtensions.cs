using System;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Primitives;
using SP.OnlineBank.Api.Gateway.Authentication;

namespace SP.OnlineBank.Api.Gateway.DependencyInjection
{
  public static class JwtBearerAuthenticationBuilderExtensions
  {
    private const string ConfigurationSection = "Authentication:Bearer";

    public static AuthenticationBuilder AddJwtBearer(
      this AuthenticationBuilder builder,
      IConfiguration configuration,
      IWebHostEnvironment hostEnvironment)
    {
      if (builder == null)
      {
        throw new ArgumentNullException(nameof(builder));
      }

      if (configuration == null)
      {
        throw new ArgumentNullException(nameof(configuration));
      }

      if (hostEnvironment == null)
      {
        throw new ArgumentNullException(nameof(hostEnvironment));
      }

      builder.AddJwtBearer();
      builder.Services.Configure<JwtBearerOptions>(JwtBearerDefaults.AuthenticationScheme,
        configuration.GetSection(ConfigurationSection));
      
      
      builder.Services.PostConfigure<JwtBearerOptions>(JwtBearerDefaults.AuthenticationScheme, options =>
      {
        options.ForwardDefaultSelector =
          context => context.Request.Headers.TryGetValue("Authorization", out StringValues value)
            && value.ToString().StartsWith("Bearer")
            && value.ToString().Contains('.')
              ? default
              : OnlineBankDefault.AuthenticationScheme;
      });

      return builder;
    }
  }
}