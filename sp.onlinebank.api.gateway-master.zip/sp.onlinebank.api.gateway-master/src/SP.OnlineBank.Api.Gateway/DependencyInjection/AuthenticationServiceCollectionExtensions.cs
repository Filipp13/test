using System;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SP.OnlineBank.Api.Gateway.Authentication;

namespace SP.OnlineBank.Api.Gateway.DependencyInjection
{
  public static class AuthenticationServiceCollectionExtensions
  {
    private const string ConfigurationSection = "Authentication";

    public static IServiceCollection AddAuthentication(
      this IServiceCollection services,
      IConfiguration configuration,
      IWebHostEnvironment hostEnvironment)
    {
      if (services == null)
      {
        throw new ArgumentNullException(nameof(services));
      }

      if (configuration == null)
      {
        throw new ArgumentNullException(nameof(configuration));
      }

      if (hostEnvironment == null)
      {
        throw new ArgumentNullException(nameof(hostEnvironment));
      }

      services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
              .AddJwtBearer(configuration, hostEnvironment)
              .AddOAuth2Introspection(configuration, hostEnvironment);

      IConfigurationSection? section = configuration.GetSection(ConfigurationSection);

      services.Configure<AuthenticationOptions>(section);
      services.Configure<ClientCredentialsOptions>(section);

      return services;
    }
  }
}