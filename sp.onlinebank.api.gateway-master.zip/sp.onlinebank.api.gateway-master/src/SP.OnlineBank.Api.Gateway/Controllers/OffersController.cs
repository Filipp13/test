﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SP.OnlineBank.Api.Gateway.Authentication;
using SP.OnlineBank.Api.Gateway.Map;
using SP.Resources.Api.HttpClient;
using System.Collections.Generic;
using System.Threading.Tasks;
using SP.OnlineBank.Api.Gateway.Models.Offers;

namespace SP.OnlineBank.Api.Gateway.Controllers
{
    /// <summary>
    ///   Предоставляет API для получения предложений
    /// </summary>
    [ApiController]
    [Route("api/v1/[controller]")]
    [Authorize(OnlineBankDefault.AuthenticationScheme)]
    [Produces("application/json")]
    public class OffersController : ControllerBase
    {
        private readonly IResourcesService _resourcesService;
        private readonly IMapper _mapper;

        public OffersController(
          IResourcesService resourcesService,
          IMapper mapper)
        {
            _resourcesService = resourcesService;
            _mapper = mapper;
        }

        /// <summary>
        /// Возвращает экземпляры <see cref="Offer"/> по всем доступным сберегательным продуктам
        /// </summary>
        /// <returns>
        /// Коллекция <see cref="Offer"/>.
        /// </returns>
        [HttpGet]
        public async Task<IEnumerable<Offer>> GetAsync()
        {
            var cultures = await _resourcesService.GetAsync();
            return _mapper.Map(cultures);
        }

        /// <summary>
        /// Возвращает экземпляр <see cref="Offer"/> по указанному сберегательному продукту для локали,
        /// переданной в заголовке Accept-Language.
        /// </summary>
        /// <param name="gpc">Уникальный идентификатор группы продуктов в продуктовом каталоге.</param>
        /// <param name="lpc">Уникальный идентификатор в продуктовом каталоге.</param>
        /// <returns>Экземпляр <see cref="Offer"/>.</returns>
        [HttpGet("{gpc}/{lpc}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesDefaultResponseType]
        public async Task<ActionResult<Offer>> GetAsync(string gpc, string lpc)
        {
            var culture = await _resourcesService.GetAsync(gpc, lpc);
            if (culture is null)
                return NotFound($"Resources with gpc {gpc} and lpc {lpc} not found");
            return Ok(_mapper.Map(culture));
        }

    }
}