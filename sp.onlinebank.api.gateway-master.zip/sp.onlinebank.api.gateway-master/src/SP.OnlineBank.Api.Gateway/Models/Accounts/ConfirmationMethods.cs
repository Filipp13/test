namespace SP.OnlineBank.Api.Gateway.Models.Accounts
{
  /// <summary>
  ///   Перечисление методов подтверждения операций.
  ///   <para>
  ///     Допустимо передавать и PUSHOTP и "0" в JSON или в строке запроса.
  ///     Служба понимает оа формата.
  ///   </para>
  ///   <para>
  ///     PUSHOTP = 0
  ///   </para>
  ///   <para>
  ///     SMSOTP = 0
  ///   </para>
  ///   <para>
  ///     STUBOTP = 0
  ///   </para>
  /// </summary>
  /// <remarks>
  ///   <list type="bullet">
  ///     <item>
  ///       <term>PUSHOTP = 0</term>
  ///       <description>Метод подверждения с использованием One Time Password, доставляемого в PUSH сообщении.</description>
  ///     </item>
  ///     <item>
  ///       <term>SMSOTP = 1</term>
  ///       <description>Метод подверждения с использованием One Time Password, доставляемого в SMS сообщении.</description>
  ///     </item>
  ///     <item>
  ///       <term>STUBOTP = 2</term>
  ///       <description>Метод подверждения без использования One Time Password.</description>
  ///     </item>
  ///   </list>
  /// </remarks>
  public enum ConfirmationMethods
  {
    PUSHOTP = 0,
    SMSOTP = 1,
    STUBOTP = 2
  }
}