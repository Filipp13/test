namespace SP.OnlineBank.Api.Gateway.Models.Accounts
{
  /// <summary>
  ///   Представляет метод подтверждения операции.
  /// </summary>
  public class ConfirmationMethod
  {
    /// <summary>
    ///   Получает значение перечисления <see cref="ConfirmationMethods" />.
    /// </summary>
    /// <remarks>
    ///   Может принимать одно из значений:
    ///   <list type="bullet">
    ///     <item>
    ///       <term>PUSHOTP = 0</term>
    ///       <description>Метод подверждения с использованием One Time Password, доставляемого средствами PUSH сообщения.</description>
    ///     </item>
    ///     <item>
    ///       <term>SMSOTP = 1</term>
    ///       <description>Метод подверждения с использованием One Time Password, доставляемого средствами SMS сообщения.</description>
    ///     </item>
    ///   </list>
    /// </remarks>
    public ConfirmationMethods Method { get; set; }
  }
}