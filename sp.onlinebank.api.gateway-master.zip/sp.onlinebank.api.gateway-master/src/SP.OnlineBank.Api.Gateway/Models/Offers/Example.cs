﻿using System;
using System.Collections.Generic;

namespace SP.OnlineBank.Api.Gateway.Models.Offers
{
  public class Example
  {
    public Example(
      string? header, 
      string? description, 
      IReadOnlyList<HistogramColumn>? histogram)
    {
      Header = header ?? throw new ArgumentNullException(nameof(header));
      Description = description ?? throw new ArgumentNullException(nameof(description));
      Histogram = histogram;
    }

    /// <summary>
    /// Заголовок примера
    /// </summary>
    public string Header { get; }

    /// <summary>
    /// Текст примера
    /// </summary>
    public string Description { get; }

    /// <summary>
    ///   Массив колонок гистограммы, иллюстрирующей схему начисления
    /// </summary>
    public IReadOnlyList<HistogramColumn>? Histogram { get; }
  }
}