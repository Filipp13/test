using System;

namespace SP.OnlineBank.Api.Gateway.Models.Offers
{
    public class HistogramColumn
    {
        public HistogramColumn(string description, int value, int orderPriority)
        {
            Description = description ?? throw new ArgumentNullException(nameof(description));
            Value = value;
            OrderPriority = orderPriority;
        }
        
        public string Description { get; }
        public int Value { get; }
        public int OrderPriority { get; }
    }
}