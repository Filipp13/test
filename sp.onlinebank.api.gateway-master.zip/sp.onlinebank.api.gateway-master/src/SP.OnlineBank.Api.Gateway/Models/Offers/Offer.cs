﻿using System;
using System.Collections.Generic;

namespace SP.OnlineBank.Api.Gateway.Models.Offers
{
    /// <summary>
    /// Предложение, описывающее потребительские свойства сберегательного продукта
    /// </summary>
    public class Offer
    {
        public Offer(
          string? gpc,
          string? lpc,
          string? tariffLink,
          string? moneyInsurance,
          IEnumerable<Benefits>? benefits,
          InterestRate? interestRate,
          AccrualScheme? accrualScheme,
          ProductName? productName)
        {
            GPC = gpc ?? throw new ArgumentNullException(nameof(gpc));
            LPC = lpc ?? throw new ArgumentNullException(nameof(lpc));
            TariffLink = tariffLink;
            MoneyInsurance = moneyInsurance;
            Benefits = benefits;
            InterestRate = interestRate;
            AccrualScheme = accrualScheme;
            Name = productName?.Name ?? throw new ArgumentNullException(nameof(productName.Name));
            Type = productName.Type ?? throw new ArgumentNullException(nameof(productName.Type));
        }

        /// <summary>
        /// Уникальный идентификатор группы продуктов в продуктовом каталоге.
        /// </summary>
        public string GPC { get; }

        /// <summary>
        /// Уникальный идентификатор в продуктовом каталоге.
        /// </summary>
        public string LPC { get; }

        /// <summary>
        /// Список условий по продукту
        /// </summary>
        public IEnumerable<Benefits>? Benefits { get; }

        /// <summary>
        /// Схема начисления процентной ставки. Применимо для вкладов
        /// </summary>
        public InterestRate? InterestRate { get; }

        /// <summary>
        /// Схема начисления процентной ставки. Применимо для накопительных счетов
        /// </summary>
        public AccrualScheme? AccrualScheme { get; }

        /// <summary>
        /// Ссылка на тарифы
        /// </summary>
        public string? TariffLink { get; }
        
        /// <summary>
        /// Текст про страхование средств Агентством по страхованию вкладов
        /// </summary>
        public string? MoneyInsurance { get; }

        /// <summary>
        /// Имя продукта
        /// </summary>
        public string Name { get; }

        /// <summary>
        /// Тип продукта
        /// </summary>
        public string Type { get; }
    }
}
