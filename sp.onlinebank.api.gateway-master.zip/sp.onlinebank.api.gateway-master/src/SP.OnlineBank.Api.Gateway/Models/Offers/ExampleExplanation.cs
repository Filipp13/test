﻿using System;
using System.Collections.Generic;

namespace SP.OnlineBank.Api.Gateway.Models.Offers
{
  /// <summary>
  /// Пояснение примера схемы начисления
  /// </summary>
  public class ExampleExplanation
  {
    public ExampleExplanation(
      string? header, 
      IEnumerable<string>? explanation, 
      string? descriptionTemplate, 
      IEnumerable<DescriptionTemplateValue>? descriptionBoldValues, 
      string? legalOffert)
    {
      Header = header;
      Explanation = explanation;
      LegalOffert = legalOffert;
      DescriptionBoldValues = descriptionBoldValues;
      DescriptionTemplate = descriptionTemplate;
    }

    /// <summary>
    /// Заголовок пояснения
    /// </summary>
    public string? Header { get; }

    /// <summary>
    /// Массив пунктов, поясняющих гистограмму
    /// </summary>
    public IEnumerable<string>? Explanation { get; }

    /// <summary>
    /// Шаблон подробного описания схемы начисления. Может содержать placeholder'ы,
    /// которые нужно заменить правильно отформатированным текстом
    /// </summary>
    public string? DescriptionTemplate { get; }

    /// <summary>
    /// Массив значений на замену placeholder'ов в шаблоне описания, форматированный <b>жирным</b>
    /// </summary>
    public IEnumerable<DescriptionTemplateValue>? DescriptionBoldValues { get; }

    /// <summary>
    /// Текст отказа от ответственности
    /// </summary>
    public string? LegalOffert { get; }
  }
}