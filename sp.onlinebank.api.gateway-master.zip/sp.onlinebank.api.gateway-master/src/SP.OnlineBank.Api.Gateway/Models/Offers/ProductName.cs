using System;

namespace SP.OnlineBank.Api.Gateway.Models.Offers
{
    public class ProductName
    {
        public ProductName(string name, string type)
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Type = type ?? throw new ArgumentNullException(nameof(type));
        }

        /// <summary>
        /// Имя сберегательного продукта
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// Тип сберегательного продукта
        /// </summary>
        public string Type { get; set; }
    }
}