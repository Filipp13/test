﻿using System;

namespace SP.OnlineBank.Api.Gateway.Models.Offers
{
    public class RateM
    {
        /// <summary>
        /// Ставки
        /// </summary>
        /// <param name="rate"></param>
        /// <param name="period"></param>
        public RateM(
            string? rate,
            string? period)
        {
            Rate = rate ?? throw new ArgumentNullException(nameof(rate));
            Period = period;
        }

        /// <summary>
        /// Ставка
        /// </summary>
        public string Rate { get; }

        /// <summary>
        /// Период
        /// </summary>
        public string? Period { get; }
    }
}