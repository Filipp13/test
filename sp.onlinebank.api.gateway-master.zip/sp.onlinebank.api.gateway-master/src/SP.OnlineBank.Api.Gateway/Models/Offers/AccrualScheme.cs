﻿using System;

namespace SP.OnlineBank.Api.Gateway.Models.Offers
{
    /// <summary>
    /// Схема начисления процентной ставки. Применимо для накопительных счетов
    /// </summary>
    public class AccrualScheme
    {
        public AccrualScheme(
          string? description,
          Example? example,
          ExampleExplanation? exampleExplanation,
          bool isMinBalance)
        {
            Description = description ?? throw new ArgumentNullException(nameof(description));
            Example = example ?? throw new ArgumentNullException(nameof(example));
            ExampleExplanation = exampleExplanation ?? throw new ArgumentNullException(nameof(exampleExplanation));
            IsMinBalance = isMinBalance;
        }

        /// <summary>
        /// Описание схемы начисления
        /// </summary>
        public string Description { get; }

        /// <summary>
        /// Пример, иллюстрирующий схему начисления
        /// </summary>
        public Example? Example { get; }

        /// <summary>
        /// Пояснение примера схемы начисления
        /// </summary>
        public ExampleExplanation? ExampleExplanation { get; }

        /// <summary>
        /// Флаг схемы начисления на минимальный остаток
        /// </summary>
        public bool IsMinBalance { get; }
    }
}