using System;

namespace SP.OnlineBank.Api.Gateway.Models.Offers
{
    public class DescriptionTemplateValue
    {
        public DescriptionTemplateValue(string placeholder, string value)
        {
            Placeholder = placeholder ?? throw new ArgumentNullException(nameof(placeholder));
            Value = value ?? throw new ArgumentNullException(nameof(value));
        }
        public string Placeholder { get; }
        public string Value { get; }
    }
}