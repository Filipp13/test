﻿using System;
using System.Collections.Generic;

namespace SP.OnlineBank.Api.Gateway.Models.Offers
{
  /// <summary>
  /// Схема начисления процентной ставки. Применимо для вкладов
  /// </summary>
  public class InterestRate
  {
    public InterestRate(
        string? header, 
        string? description, 
        IEnumerable<RateM>? rates)
    {
      Header = header ?? throw new ArgumentNullException(nameof(header));
      Description = description;
      Rates = rates ?? throw new ArgumentNullException(nameof(rates));
    }

    /// <summary>
    /// Заголовок текста, описывающего схему начисления
    /// </summary>
    public string Header { get; }

    /// <summary>
    /// Текст, описывающий схему начисления
    /// </summary>
    public string? Description { get; }

    /// <summary>
    /// Массив ставок и периодов, к которым они применимы
    /// </summary>
    public IEnumerable<RateM>? Rates { get; }
  }
}