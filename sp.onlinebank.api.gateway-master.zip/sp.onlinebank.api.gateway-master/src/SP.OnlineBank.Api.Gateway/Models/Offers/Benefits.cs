﻿using System;

namespace SP.OnlineBank.Api.Gateway.Models.Offers
{
    /// <summary>
    /// Преимущества
    /// </summary>
    public class Benefits
    {
        public Benefits(
          string? header,
          string? description)
        {
            Header = header;
            Description = description;
        }

        /// <summary>
        /// заголовок
        /// </summary>
        public string? Header { get; }

        /// <summary>
        /// описание
        /// </summary>
        public string? Description { get; }
    }
}