using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using IdentityModel.Client;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace SP.OnlineBank.Api.Gateway.Utils
{
  /// <summary>
  ///   Обработчик осущсетвляющий запись тела сообщения в системе ведения журнала.
  /// </summary>
  /// <remarks>
  ///   Запись тела сообщения включена только на уровне <see cref="LogLevel.Trace" />.
  /// </remarks>
  internal class SetTokenHandler : DelegatingHandler
  {
    private readonly IHttpContextAccessor _httpContextAccessor;

    /// <inheritdoc />
    public SetTokenHandler(IHttpContextAccessor httpContextAccessor)
    {
      _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
    }

    /// <inheritdoc />
    public SetTokenHandler(HttpMessageHandler innerHandler, IHttpContextAccessor httpContextAccessor) :
      base(innerHandler)
    {
      _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
    }

    /// <inheritdoc />
    protected override HttpResponseMessage Send(HttpRequestMessage request, CancellationToken cancellationToken)
    {
      if (_httpContextAccessor.HttpContext != null)
      {
        var token = _httpContextAccessor.HttpContext.GetTokenAsync("access_token");
        request.SetBearerToken(token.Result);
      }

      return base.Send(request, cancellationToken);
    }

    /// <inheritdoc />
    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
      CancellationToken cancellationToken)
    {
      if (_httpContextAccessor.HttpContext != null)
      {
        var token = await _httpContextAccessor.HttpContext.GetTokenAsync("access_token");
        
        request.SetBearerToken(token);
      }

      return await base.SendAsync(request, cancellationToken);
    }
  }
}