using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Logging;
using SP.OnlineBank.Api.Gateway.Authorization;
using SP.OnlineBank.Api.Gateway.Configuration;
using SP.OnlineBank.Api.Gateway.Conventions;
using SP.OnlineBank.Api.Gateway.DependencyInjection;
using SP.OnlineBank.Api.Gateway.Map;
using SP.OnlineBank.Api.Gateway.Utils;
using SP.Resources.Api.HttpClient.DependencyInjection;
using ViennaNET.Metrics;

[assembly: ApiConventionType(typeof(OnlineBankConventions))]

namespace SP.OnlineBank.Api.Gateway
{
    [ExcludeFromCodeCoverage]
    public class Startup
    {
        public Startup(IConfiguration configuration, IWebHostEnvironment hostEnvironment)
        {
            Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            HostEnvironment = hostEnvironment ?? throw new ArgumentNullException(nameof(hostEnvironment));
        }

        public IConfiguration Configuration { get; }
        public IWebHostEnvironment HostEnvironment { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddPrometheusMetrics(Configuration);
            services.AddConfiguredControllers()
              .AddLocalization(options => options.ResourcesPath = "Resources")
              .AddSwagger(Configuration, HostEnvironment)
              .AddAuthentication(Configuration, HostEnvironment)
              .AddAuthorization(Configuration, HostEnvironment)
              .AddHttpClient()
              .AddHealthChecks();
            services.AddSingleton<IMapper, Mapper>();
            services.Configure<ResourceConfiguration>(options => Configuration.GetSection("Resources").Bind(options));
            services.AddHttpContextAccessor();
            services.AddTransient<SetTokenHandler>();
            services.AddResourcesServiceClient(Configuration)
                    .AddHeaderPropagation(options =>
                    {
                        options.Headers.Add("Cache-Control");
                        options.Headers.Add("Accept-Language");
                    });
            services.AddHeaderPropagation(options =>
            {
                options.Headers.Add("Cache-Control");
                options.Headers.Add("Accept-Language");
            });
            services.AddSingleton<IAuthorizationHandler, OneTimePasswordHandler>();
        }

        public void Configure(IApplicationBuilder app)
        {
            if (HostEnvironment.IsDevelopment())
            {
                IdentityModelEventSource.ShowPII = true;

                app.UseDeveloperExceptionPage();
            }

            app.UseRewriter(string.Empty);
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseHeaderPropagation();
            app.UseRequestLocalization("ru", "en");
            
            if (!HostEnvironment.IsProduction())
            {
                app.UseSwagger();
                app.UseSwaggerUI(uiOptions =>
                {
                    uiOptions.SwaggerEndpoint($"/swagger/{HostEnvironment.ApplicationName}/swagger.json",
                        HostEnvironment.ApplicationName);
                });
            }

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHealthChecks("/health");
            });
        }
    }
}