using Microsoft.AspNetCore.Authorization;

namespace SP.OnlineBank.Api.Gateway.Authorization
{
  public class OneTimePasswordRequirement : IAuthorizationRequirement
  {
  }
}