using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Http;
using System.Security.Claims;
using System.Threading.Tasks;
using IdentityModel.Client;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace SP.OnlineBank.Api.Gateway.Authorization
{
  public class OneTimePasswordHandler : AuthorizationHandler<OneTimePasswordRequirement, OneTimePasswordResource>
  {
    private readonly IHttpClientFactory _clientFactory;
    private readonly ILogger<OneTimePasswordHandler> _logger;
    private readonly IOptionsMonitor<JwtBearerOptions> _options;

    public OneTimePasswordHandler(IHttpClientFactory clientFactory,
      IOptionsMonitor<JwtBearerOptions> options,
      ILogger<OneTimePasswordHandler> logger)
    {
      _clientFactory = clientFactory;
      _options = options;
      _logger = logger;
    }

    protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context,
      OneTimePasswordRequirement requirement, OneTimePasswordResource resource)
    {
      JwtBearerOptions? options = _options.Get(JwtBearerDefaults.AuthenticationScheme);

      _logger.LogDebug("Start OTP Authorization");
      HttpClient? client = _clientFactory.CreateClient();

      var request = new DiscoveryDocumentRequest
      {
        Address = options.Authority,
        Policy = new DiscoveryPolicy {Authority = options.Authority, RequireHttps = false}
      };

      DiscoveryDocumentResponse? discoveryDocument = await client.GetDiscoveryDocumentAsync(request);

      if (!discoveryDocument.IsError)
      {
        _logger.LogDebug("HttpClient resolved");
        _logger.LogDebug("DiscoveryDocument resolved");
        _logger.LogDebug("Authority {authority}", options.Authority);
        _logger.LogDebug("TokenEndpoint {tokenEndpoint}", discoveryDocument.TokenEndpoint);

        var tokenReq = new TokenRequest
        {
          Address = discoveryDocument.TokenEndpoint,
          GrantType = "otp",
          ClientId = "SP.OnlineBank.Api.Gateway",
          ClientSecret = "secret",
          Parameters =
          {
            {"rcasId", resource.RcasId?.ToString()},
            {"requestId", resource.RequestId},
            {"operationTypeId", resource.OperationTypeId},
            {
              "document",
              resource.OTP != null ? resource.Document.Replace("{otp}", resource.OTP.ToString()) : resource.Document
            },
            {"method", resource.Method},
            {"amount", resource.Amount},
            {"otp", resource.OTP?.ToString()},
            {"username", resource.UserName},
            {"deviceId", resource.DeviceId},
            {"pushId", resource.PushId},
          }
        };

        if (!string.IsNullOrWhiteSpace(resource.AppId))
        {
          tokenReq.Parameters.Add("appId", resource.AppId);
        }

        TokenResponse? result = await client.RequestTokenAsync(tokenReq);

        if (!result.IsError)
        {
          try
          {
            var claims = new List<Claim>();
            JwtSecurityToken? token = new JwtSecurityTokenHandler().ReadJwtToken(result.AccessToken);

            if (result.Json.TryGetValue(OnlineBankJwtClaimTypes.RcasIdClaimType, out var rcasId))
            {
              claims.Add(new Claim(OnlineBankJwtClaimTypes.RcasIdClaimType, rcasId.ToString()));
            }

            if (result.Json.TryGetValue(OnlineBankJwtClaimTypes.RcasAppIdClaimType, out var appId))
            {
              claims.Add(new Claim(OnlineBankJwtClaimTypes.RcasAppIdClaimType, appId.ToString()));
            }

            if (result.Json.TryGetValue(OnlineBankJwtClaimTypes.RepeatOtpWaitIntervalClaimType,
              out var repeatIntervalValue))
            {
              var repeatIntervalClaim =
                new Claim(OnlineBankJwtClaimTypes.RepeatOtpWaitIntervalClaimType, repeatIntervalValue.ToString());
              claims.Add(repeatIntervalClaim);
            }

            context.User.AddIdentity(new ClaimsIdentity(claims));
          }
          catch (Exception e)
          {
            _logger.LogError(e, "Read token error");
          }


          context.Succeed(requirement);
        }
        else
        {
          _logger.LogDebug(result?.ErrorDescription);
          _logger.LogDebug(result?.Error);
        }
      }
      else
      {
        _logger.LogDebug(discoveryDocument?.Error);
      }
    }
  }
}