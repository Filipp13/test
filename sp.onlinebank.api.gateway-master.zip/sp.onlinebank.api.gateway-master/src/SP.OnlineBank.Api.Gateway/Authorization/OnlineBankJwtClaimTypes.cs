namespace SP.OnlineBank.Api.Gateway.Authorization
{
  public static class OnlineBankJwtClaimTypes
  {
    public const string ConfirmationMethods = "confirmation_methods";
    public const string RcasIdClaimType = "rcas_id";
    public const string RcasAppIdClaimType = "app_id";
    public const string RcasDocumentSignOnClaimType = "rcas_document_sign_on";
    public const string RcasSignedDocumentClaimType = "rcas_signed_document";
    public const string RepeatOtpWaitIntervalClaimType = "repeat_otp_wait_interval";
  }
}