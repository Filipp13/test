namespace SP.OnlineBank.Api.Gateway.Authorization
{
  public sealed class OneTimePasswordResource
  {
    public OneTimePasswordResource(
      string operationTypeId,
      string method,
      string requestId,
      string userName,
      string? document = null,
      string? amount = null,
      long? rcasId = null,
      string? appId = null,
      string? otp = null)
    {
      UserName = userName;
      RcasId = rcasId;
      AppId = appId;
      Document = document;
      OperationTypeId = operationTypeId;
      OTP =  int.TryParse(otp, out var parsedOtp) ? parsedOtp : (int?)null;
      Method = method;
      RequestId = requestId;
      Amount = amount;
    }

    public string UserName { get; }
    public long? RcasId { get; }
    public string? AppId { get; }
    public string? Document { get; }
    public string OperationTypeId { get; }
    public string Method { get; }
    public int? OTP { get; }
    public string? RequestId { get; }
    public string? Amount { get; }
    
    /// <summary>
    ///   Получает или задаёт уникальный идентификатор устройства клиента.
    /// </summary>
    public string? DeviceId { get; set; }

    /// <summary>
    ///   Получает или задаёт уникальный PUSH идентификатор приложения для доставки PUSH сообщений.
    /// </summary>
    public string? PushId { get; set; }
  }
}