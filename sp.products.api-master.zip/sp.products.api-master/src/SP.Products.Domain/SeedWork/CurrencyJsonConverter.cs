using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using SP.Products.Domain.Aggregates.ValueTypes;

namespace SP.Products.Domain.SeedWork
{
  /// <inheritdoc />
  public class CurrencyJsonConverter : JsonConverter<Currency>
  {
    /// <inheritdoc />
    public override Currency? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
      try
      {
        return new Currency(reader.GetString()!);
      }
      catch
      {
        return null;
      }
    }

    /// <inheritdoc />
    public override void Write(Utf8JsonWriter writer, Currency value, JsonSerializerOptions options) =>
      writer.WriteStringValue(value.ToString());
  }
}