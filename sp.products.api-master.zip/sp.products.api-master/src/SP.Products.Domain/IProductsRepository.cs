using System.Collections.Generic;
using System.Threading.Tasks;
using SP.Products.Domain.Aggregates;
using ViennaNET.Domain.Seedwork;

namespace SP.Products.Domain
{
  /// <summary>
  ///   Представляет интерфейс для взаимодействия с источником данных агрегата <see cref="Product" />.
  /// </summary>
  public interface IProductsRepository : IRepository<Product>
  {
    /// <summary>
    ///   Считывает из источника все известные продукты.
    /// </summary>
    /// <returns>Коллекция продуктов <see cref="Product" />.</returns>
    public Task<List<Product>> ToListAsync();

    /// <summary>
    ///   Считывает из источника продукт с указанным идентификатором.
    /// </summary>
    /// <param name="gpc">Уникальный идентификатор группы продуктов.</param>
    /// <param name="lpc">Уникальный идентификатор продукта.</param>
    /// <returns>
    ///   Ссылка на задачу <see cref="Task" />,
    ///   содержащую ссылку на объект <see cref="Product" />, если продукт существует,
    ///   иначе значение <see langword="null" />.
    /// </returns>
    public Task<Product?> FindAsync(string gpc, string lpc);
  }
}