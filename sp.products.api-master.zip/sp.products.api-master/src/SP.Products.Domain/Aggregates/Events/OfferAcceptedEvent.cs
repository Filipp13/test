using SP.Products.Domain.Aggregates.Entities;
using ViennaNET.Mediator.Seedwork;

namespace SP.Products.Domain.Aggregates.Events
{
  /// <summary>
  ///   Представляет событие агрегата <see cref="SP.Products.Domain.Aggregates.Customer" />,
  ///   возникающее после принятия предложения <see cref="SP.Products.Domain.Aggregates.Customer.AcceptOffer" />.
  /// </summary>
  public record OfferAcceptedEvent : IEvent
  {
    /// <summary>
    ///   Инициализирует новый экземпляр <see cref="OfferAcceptedEvent" />.
    /// </summary>
    /// <param name="account"></param>
    internal OfferAcceptedEvent(Account account)
    {
      Account = account;
    }

    /// <summary>
    ///   Получает счёт созданый в процессе принятия предложения.
    /// </summary>
    /// <value>Ссылка на объект <see cref="Account" />.</value>
    public Account Account { get; }
  }
}