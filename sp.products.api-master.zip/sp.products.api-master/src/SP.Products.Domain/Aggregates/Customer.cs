using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using SP.Products.Domain.Aggregates.Entities;
using SP.Products.Domain.Aggregates.Events;
using SP.Products.Domain.Aggregates.ValueTypes;
using ViennaNET.Domain.Seedwork;
using ViennaNET.Kernel.Domain.ValueObjects;

namespace SP.Products.Domain.Aggregates
{
  /// <summary>
  ///   Представляет сущность "Клиент" - корень агрегата "Клиент".
  /// </summary>
  [SuppressMessage("ReSharper", "FieldCanBeMadeReadOnly.Local")]
  [SuppressMessage("ReSharper", "ReturnTypeCanBeEnumerable.Global")]
  public sealed class Customer : Entity<CustomerNumber>, IAggregateRoot
  {
    private List<Account> _accounts;

    /// <summary>
    ///   Инициализирует новый экземпляр класса <see cref="Customer" />.
    /// </summary>
    private Customer()
    {
      Id = null!;
      _accounts = new List<Account>();
    }

    /// <summary>
    ///   Инициализирует новый экземпляр класса <see cref="Customer" />.
    /// </summary>
    /// <param name="id">Ссылка на объект <see cref="CustomerNumber" />.</param>
    public Customer(CustomerNumber id) : this()
    {
      Id = id;
    }

    /// <summary>
    ///   Получает список продуктов когдалибо открытых клиентом.
    /// </summary>
    public IReadOnlyCollection<Account> Accounts => _accounts.AsReadOnly();


    /// <summary>
    ///   Открыть счёт по предложению или специальному предложению.
    /// </summary>
    /// <param name="operationId">Основание или идентификатор активной операции.</param>
    /// <param name="offer">Ссылка на объект <see cref="Offer" />.</param>
    /// <param name="specialOfferId">Идентификатор специального предложения, если действительно иначе <see langword="null" />.</param>
    public void AcceptOffer(Guid operationId, Offer offer, int? specialOfferId = null)
    {
      Account account = specialOfferId is not null
        ? new Account(this, offer, operationId, specialOfferId.Value)
        : new Account(this, offer, operationId);

      _accounts.Add(account);

      Enqueue(new OfferAcceptedEvent(account));
    }
  }
}