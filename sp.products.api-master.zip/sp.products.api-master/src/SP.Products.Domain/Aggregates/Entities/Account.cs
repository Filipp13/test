using System;
using System.Text.RegularExpressions;
using SP.Products.Domain.Aggregates.ValueTypes;
using ViennaNET.Domain.Seedwork;

namespace SP.Products.Domain.Aggregates.Entities
{
  /// <summary>
  ///   Представляет сущность "Счёт".
  /// </summary>
  /// <remarks>
  ///   В контексте продукта, это экземпляр "Предложения" <see cref="Offer" />
  ///   с которым связанн счёт в системе учёта <see cref="Number" /> и клиент <see cref="Owner" />.
  /// </remarks>
  public class Account : IEntity
  {
    private Account()
    {
      OperationId = Guid.Empty;
      SpecialOfferId = null;
      Offer = null!;
      Owner = null!;
    }

    /// <summary>
    ///   Инициализирует новый экземпляр класса <see cref="Account" />.
    /// </summary>
    /// <param name="operationId">Уникальный идентификатор операции.</param>
    /// <param name="owner"></param>
    /// <param name="offer">Ссылка на объект <see cref="Offer" /></param>
    internal Account(Customer owner, Offer offer, Guid operationId) : this()
    {
      Owner = owner;
      Offer = offer;
      OperationId = operationId;
    }

    /// <summary>
    ///   Инициализирует новый экземпляр класса <see cref="Account" />.
    /// </summary>
    /// <param name="operationId">Уникальный идентификатор операции.</param>
    /// <param name="owner">Ссылка на объект <see cref="Customer" /> - владельца счёта.</param>
    /// <param name="offer">Ссылка на объект <see cref="Offer" />.</param>
    /// <param name="specialOfferId">Уникальный идентификатор специального предложения.</param>
    internal Account(Customer owner, Offer offer, Guid operationId, int specialOfferId)
      : this(owner, offer, operationId)
    {
      SpecialOfferId = specialOfferId;
    }

    /// <summary>
    ///   Получает ссылку на владельца счёта <see cref="Owner" />.
    /// </summary>
    /// <remarks>Не возможно сменить владельца счёта.</remarks>
    public Customer Owner { get; }

    /// <summary>
    ///   Получает ссылку на объект <see cref="Offer" />.
    /// </summary>
    /// <remarks>Возможно сменить предложение (смена тарифа).</remarks>
    public Offer Offer { get; private set; }

    /// <summary>
    ///   Получает уникальный идентификатор основания на котором открыт счёт.
    /// </summary>
    /// <remarks>
    ///   Идентификатор активной операции или любой другой сущности внешней системы связанной с подписаным документом.
    /// </remarks>
    public Guid OperationId { get; }

    /// <summary>
    ///   Получает уникальный идентификатор специального предложения, если имело место быть, иначе <see langword="null" />.
    /// </summary>
    public int? SpecialOfferId { get; }

    /// <summary>
    ///   Получает 20-значный номер счёта в формате ЦБ,
    ///   если счёт успешно открыт в системе учёта, иначе <see langword="null" />.
    /// </summary>
    public string? Number { get; private set; }

    /// <summary>
    ///   Привязать 20 значный номер счёта в формате ЦБ.
    /// </summary>
    /// <param name="number">20-значный номер счёта в формате ЦБ.</param>
    /// <exception cref="ArgumentNullException">
    ///   Возникает если параметр <paramref name="number" /> имеет значение <see langword="null" />.
    /// </exception>
    /// <exception cref="FormatException">
    ///   Возникает если параметр <paramref name="number" /> имеет не верный формат <see cref="Number" />.
    /// </exception>
    public void BindAccountNumber(string number)
    {
      Number = number ?? throw new ArgumentNullException(nameof(number));

      if (!Regex.IsMatch(number, "[0-9]{20}"))
      {
        throw new FormatException("Number string must be 20 digit symbols.");
      }
    }
  }
}