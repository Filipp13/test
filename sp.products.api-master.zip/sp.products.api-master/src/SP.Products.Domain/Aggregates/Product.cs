﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text.RegularExpressions;
using SP.Products.Domain.Aggregates.ValueTypes;
using ViennaNET.Domain.Seedwork;

namespace SP.Products.Domain.Aggregates
{
  /// <summary>
  ///   Представляет сущность "Продукт", корень агрегата "Продукт".
  ///   <para>
  ///     "Продукт" - это определение счёта в продуктовом каталоге банка, с ним связанны тарифы.
  ///   </para>
  /// </summary>
  [SuppressMessage("ReSharper", "FieldCanBeMadeReadOnly.Local")]
  [SuppressMessage("ReSharper", "ReturnTypeCanBeEnumerable.Global")]
  public sealed class Product : IEntity, IAggregateRoot
  {
    private List<Offer> _offers;
    private List<Tariff> _tariffs;

    /// <summary>
    ///   Инициаизирует новый экземпляр класса <see cref="Product" />.
    /// </summary>
    private Product()
    {
      GPC = string.Empty;
      LPC = string.Empty;
      Name = string.Empty;

      _offers = new List<Offer>();
      _tariffs = new List<Tariff>();
    }

    /// <summary>
    ///   Инициализирует новый экземпляр класса <see cref="Product" />.
    /// </summary>
    /// <param name="gpc">Уникальный идентификатор группы в продуктовом каталоге.</param>
    /// <param name="lpc">Уникальный идентификатор.</param>
    /// <param name="name">Техническое наименование.</param>
    public Product(string gpc, string lpc, string name) : this()
    {
      GPC = gpc ?? throw new ArgumentNullException(nameof(gpc));
      LPC = lpc ?? throw new ArgumentNullException(nameof(lpc));
      Name = name ?? throw new ArgumentNullException(nameof(name));

      if (!Regex.IsMatch(gpc, "[A-Z0-9]{6}"))
      {
        throw new FormatException("Group product code must be a alphanumeric-6.");
      }

      if (!Regex.IsMatch(lpc, "[A-Z0-9]{4}"))
      {
        throw new FormatException("Local product code must be a alphanumeric-4.");
      }
    }

    /// <summary>
    ///   Получает уникальный идентификатор группы продуктов в продуктовом каталоге.
    /// </summary>
    public string GPC { get; }

    /// <summary>
    ///   Получает уникальный идентификатор в продуктовом каталоге.
    /// </summary>
    public string LPC { get; }

    /// <summary>
    ///   Получает наименование в продуктовом каталоге.
    /// </summary>
    public string Name { get; }

    /// <summary>
    ///   Получает коллекцию связанных предложений.
    /// </summary>
    public IReadOnlyCollection<Offer> Offers => _offers.ToList().AsReadOnly();

    /// <summary>
    ///   Получает коллекцию действующих тарифов.
    /// </summary>
    public IReadOnlyCollection<Tariff> Tariffs => _tariffs.ToList().AsReadOnly();

    /// <summary>
    ///   Создаёт новый тариф и связывает его с продуктом через предложение <see cref="Offer" />.
    /// </summary>
    /// <remarks>
    ///   <paramref name="tariffId" />
    ///   - это значение должно соответствовать subtypeId счёта или nettype депозита во внешних системах.
    /// </remarks>
    /// <param name="tariffId">Уникальный идентификатор тарифа</param>
    /// <param name="currency">Ссылка на объект <see cref="Currency" />.</param>
    /// <exception cref="ArgumentNullException">
    ///   Возникает если один из параметров имеет значение <see langword="null" />.
    /// </exception>
    public void AddTariff(int tariffId, Currency currency)
    {
      if (currency == null)
      {
        throw new ArgumentNullException(nameof(currency));
      }

      var tariff = new Tariff(tariffId, currency);
      Offer offer = tariff.Bind(this);

      _offers.Add(offer);
      _tariffs.Add(tariff);
    }
  }
}