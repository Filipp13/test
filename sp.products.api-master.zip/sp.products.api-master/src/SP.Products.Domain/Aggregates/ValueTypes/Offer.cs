namespace SP.Products.Domain.Aggregates.ValueTypes
{
  /// <summary>
  ///   Представляет сущность "Предложение".
  ///   <para>
  ///     "Предложение" - это естественная связь продукта и тарифа.
  ///     Именно "Предложение" отображается в пользовательском интерфейсе онлайн банка.
  ///   </para>
  ///   <para>
  ///     С предложениями связанны локализованые ресурсы в службе ресурсов. Для отображения в онлайн банке.
  ///   </para>
  /// </summary>
  public sealed record Offer
  {
    /// <summary>
    ///   Инициализирует новый экземпляр класса <see cref="Offer" />.
    /// </summary>
    private Offer()
    {
      Product = null!;
      Tariff = null!;
    }

    /// <summary>
    ///   Инициализирует новый экземпляр класса <see cref="Offer" />.
    /// </summary>
    /// <param name="product">Ссылка на объект <see cref="Product" />.</param>
    /// <param name="tariff">Ссылка на объект <see cref="Tariff" />.</param>
    internal Offer(Product product, Tariff tariff) : this()
    {
      Product = product;
      Tariff = tariff;
    }

    /// <summary>
    ///   Получает ссылку на объект <see cref="Product" />.
    /// </summary>
    public Product Product { get; private set; }

    /// <summary>
    ///   Получает ссылку на объект <see cref="Tariff" />.
    /// </summary>
    public Tariff Tariff { get; private set; }
  }
}