using System;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using SP.Products.Domain.SeedWork;

namespace SP.Products.Domain.Aggregates.ValueTypes
{
  /// <summary>
  ///   Представляет валюту в формате ISO-4217.
  /// </summary>
  [JsonConverter(typeof(CurrencyJsonConverter))]
  public record Currency
  {
    /// <summary>
    ///   Возвращает 3-х буквенный код валюты по стандарту ISO-4217.
    /// </summary>
    public static readonly Currency RUB = new("RUB");

    private readonly string _currency;

    /// <summary>
    ///   Инициализирует новый экземпляр <see cref="Currency" />.
    /// </summary>
    /// <param name="currency">3-х буквенный код валюты в формате ISO-4217.</param>
    /// <exception cref="FormatException">
    ///   Если строка не соответствует формату 3-х буквенного кода валюты по стандарту ISO-4217.
    /// </exception>
    public Currency(string currency)
    {
      _currency = currency ?? throw new ArgumentNullException(nameof(currency));

      if (!Regex.IsMatch(currency, "[A-Z]{3}"))
      {
        throw new FormatException("Currency string must be a ISO-4217 alpha-3 currency code.");
      }
    }

    /// <summary>
    ///   Неявно привести к типу <see cref="Currency" />.
    /// </summary>
    /// <param name="currency">3-х буквенный код валюты в формате ISO-4217.</param>
    /// <returns>Результат приведения.</returns>
    public static implicit operator Currency?(string? currency)
    {
      try
      {
        return new Currency(currency!);
      }
      catch
      {
        return null;
      }
    }

    /// <summary>
    ///   Неявно привести к типу <see cref="string" />.
    /// </summary>
    /// <param name="currency">Ссылка на объект <see cref="Currency" />.</param>
    /// <returns>Результат приведения.</returns>
    public static implicit operator string(Currency currency) => currency.ToString();

    /// <summary>
    ///   Если исходная строка содержит код RUR,
    ///   то значение будет преобразованно в формат ISO-4217 (RUB),
    ///   иначе вернёт исходное значение.
    /// </summary>
    /// <returns>3-х буквенный код валюты.</returns>
    public override string ToString() => _currency == "RUR" ? "RUB" : _currency;
  }
}