using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace SP.Products.Domain.Aggregates.ValueTypes
{
  /// <summary>
  ///   Представляет сущность "Тариф".
  ///   "Тариф" - это ссылки на объекты внешних систем (ICDB, Midas) определяющих процентную ставку.
  /// </summary>
  [SuppressMessage("ReSharper", "FieldCanBeMadeReadOnly.Local")]
  [SuppressMessage("ReSharper", "ReturnTypeCanBeEnumerable.Global")]
  public record Tariff
  {
    private List<Offer> _offers;
    private List<Product> _products;

    /// <summary>
    ///   Инициализиует новый экземпляр класса <see cref="Tariff" />.
    /// </summary>
    private Tariff()
    {
      Currency = Currency.RUB;
      _products = new List<Product>();
      _offers = new List<Offer>();
    }

    /// <summary>
    ///   Инициализирует новый экземпляр класса <see cref="Tariff" />.
    /// </summary>
    /// <param name="id">Уникальный идентификато тарифа.</param>
    /// <param name="currency">3-буквенный код валюты в формате ISO-4217.</param>
    /// <exception cref="ArgumentNullException">
    ///   Возникает если один из параметров имеет значение <see langword="null" />.
    /// </exception>
    internal Tariff(int id, Currency currency) : this()
    {
      Id = id;
      Currency = currency ?? throw new ArgumentNullException(nameof(currency));
    }

    /// <summary>
    ///   Получает уникальный идентификатор тарифа.
    /// </summary>
    /// <remarks>
    ///   Не смотря на наличие идентификатора, тариф является типом значения,
    ///   так как связан с продуктом и не отделим от него.
    /// </remarks>
    /// <value>Значение соответствующее subtypeId счёта или nettype депозита.</value>
    [SuppressMessage("ReSharper", "MemberCanBePrivate.Global")]
    public int Id { get; }

    /// <summary>
    ///   Получает или задаёт 3-х буквенный код валюты в формате ISO-4217.
    /// </summary>
    /// <example>RUB</example>
    public Currency Currency { get; }

    /// <summary>
    ///   Получает коллекцию связанных продуктов.
    /// </summary>
    public IReadOnlyCollection<Product> Products => _products.ToList().AsReadOnly();

    /// <summary>
    ///   Получает список связанных предложений.
    /// </summary>
    public IReadOnlyCollection<Offer> Offers => _offers.ToList().AsReadOnly();

    /// <summary>
    ///   Привязать тариф к продукту.
    /// </summary>
    /// <param name="product">Ссылка на объект <see cref="Product" />.</param>
    /// <returns>Ссылка на объект <see cref="Offer" />.</returns>
    internal Offer Bind(Product product)
    {
      var offer = new Offer(product, this);

      _offers.Add(offer);
      _products.Add(offer.Product);

      return offer;
    }
  }
}