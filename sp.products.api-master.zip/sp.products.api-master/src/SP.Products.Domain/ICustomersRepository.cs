using System.Threading;
using System.Threading.Tasks;
using SP.Products.Domain.Aggregates;
using ViennaNET.Domain.Seedwork;
using ViennaNET.Kernel.Domain.ValueObjects;

namespace SP.Products.Domain
{
  /// <summary>
  ///   Представляет интерфейс для взаимодействия с источником данных агрегата <see cref="Customer" />.
  /// </summary>
  public interface ICustomersRepository : IRepository<Customer>
  {
    /// <summary>
    ///   Добавляет нового клиента.
    /// </summary>
    /// <param name="customer">Ссылка на объект <see cref="Customer" />.</param>
    /// <param name="cancellationToken">Значение <see cref="CancellationToken" />.</param>
    /// <returns>Задача содержащая ссылку на объект <see cref="Customer" />.</returns>
    Task<Customer> AddAsync(Customer customer, CancellationToken cancellationToken = default);

    /// <summary>
    ///   Обновляет информацию в источнике данных.
    /// </summary>
    /// <param name="customer">Ссылка на объект <see cref="Customer" />.</param>
    /// <param name="cancellationToken">Значение <see cref="CancellationToken" />.</param>
    /// <returns>Ссылка на объект <see cref="Customer" />.</returns>
    Task<Customer> UpdateAsync(Customer customer, CancellationToken cancellationToken = default);

    /// <summary>
    ///   Выполняет поиск клиента в источнике даннхы по уникальному идентификатору.
    /// </summary>
    /// <param name="number">Ссылка на объект <see cref="CustomerNumber" />.</param>
    /// <param name="cancellationToken">Значение <see cref="CancellationToken" />.</param>
    /// <returns>
    ///   Ссылка на объект <see cref="Customer" />,
    ///   если запись обнаружена в источнике, иначе <see langword="null" />.
    /// </returns>
    Task<Customer?> FindAsync(CustomerNumber number, CancellationToken cancellationToken = default);
  }
}