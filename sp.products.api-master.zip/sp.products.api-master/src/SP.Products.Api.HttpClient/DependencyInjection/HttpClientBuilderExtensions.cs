using System;
using System.Net.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Polly;
using Polly.Extensions.Http;

namespace SP.Products.Api.HttpClient.DependencyInjection
{
  /// <summary>
  ///   Предоставляет методы регистрации HTTP клиента - агента службы.
  /// </summary>
  public static class HttpClientBuilderExtensions
  {
    /// <summary>
    ///   Регистрирует агента службы продуктов в DI контейнере.
    /// </summary>
    /// <param name="services">Ссылка на объект <see cref="IServiceCollection" />.</param>
    /// <param name="configuration">Ссылка на объект <see cref="IConfiguration" />.</param>
    /// <returns>Ссылка на объект <see cref="IHttpClientBuilder" />.</returns>
    /// <exception cref="InvalidOperationException">
    ///   Возникает если не удалось обнаружить секцию <see cref="ProductsServiceOptions.SectionName" />
    ///   в конфигурации.
    /// </exception>
    public static IHttpClientBuilder AddProductsServiceClient(
      this IServiceCollection services,
      IConfiguration configuration)
    {
      ProductsServiceOptions? options = configuration.GetSection(ProductsServiceOptions.SectionName)
        .Get<ProductsServiceOptions>();

      if (options is null)
      {
        throw new InvalidOperationException(
          "Unable to configure service agent. " +
          $"Configuration options from \"{ProductsServiceOptions.SectionName}\" not found.");
      }

      services.Configure<ProductsServiceOptions>(configuration.GetSection(ProductsServiceOptions.SectionName));

      return services.AddHttpClient<IProductsService, ProductsService>()
        .SetHandlerLifetime(TimeSpan.FromMinutes(1))
        .AddPolicyHandler(GetRetryPolicy(options.RetryCount, options.RetryDelay))
        .AddPolicyHandler(Policy.TimeoutAsync<HttpResponseMessage>(options.TryTimeout))
        .ConfigureHttpClient(client =>
        {
          client.BaseAddress = new Uri(options.BaseAddress!);
          client.Timeout = TimeSpan.FromSeconds(options.OverallTimeout);
        });
    }

    private static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy(int retryCount, int retryDelay) =>
      HttpPolicyExtensions
        .HandleTransientHttpError()
        .WaitAndRetryAsync(retryCount,
          retryAttempt => TimeSpan.FromSeconds(Math.Pow(retryDelay, retryAttempt)));
  }
}