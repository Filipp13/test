using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace SP.Products.Api.HttpClient
{
  /// <summary>
  ///   Предоставляет агента службы управляющей ресурсами типа <see cref="Product" />.
  /// </summary>
  public interface IProductsService
  {
    /// <summary>
    ///   Получить коллекцию всех экземпляров ресурса <see cref="Product" />.
    /// </summary>
    /// <remarks>
    ///   "Продукт" - это определение счёта в продуктовом каталоге банка, с ним связанны тарифы.
    ///   Тариф связан с продуктом через предложение.
    ///   Именно предложение отображается в пользовательском интерфейсе онлайн банка.
    ///   С предложениями связанны локализованные ресурсы в службе ресурсов.
    /// </remarks>
    /// <returns>Коллекция всех зарегистрированных экземпляров ресурса <see cref="Product" />.</returns>
    public Task<IEnumerable<Product>?> GetAsync();

    /// <summary>
    ///   Получает ресурс <see cref="Product" />  по заданному идентификатору.
    /// </summary>
    /// <param name="gpc">Group product code - уникальный идентификатор группы продуктов.</param>
    /// <param name="lpc">Local product code - уникальный идентификатор.</param>
    /// <remarks>
    ///   "Продукт" - это определение счёта в продуктовом каталоге банка, с ним связанны тарифы.
    ///   Тариф связан с продуктом через предложение.
    ///   Именно предложение отображается в пользовательском интерфейсе онлайн банка.
    ///   С предложениями связанны локализованные ресурсы в службе ресурсов.
    /// </remarks>
    /// <returns>
    ///   Ссылка на объект <see cref="Product" /> если продукт найден,
    ///   иначе HTTP Status Code 404 -NotFound".
    /// </returns>
    public Task<Product?> GetAsync(string gpc, string lpc);
  }

  /// <summary>
  ///   Представляет сущность "Продукт", корень агрегата "Продукт".
  ///   <para>
  ///     "Продукт" - это определение счёта в продуктовом каталоге банка, с ним связанны тарифы.
  ///   </para>
  /// </summary>
  public record Product
  {
    /// <summary>
    ///   Получает уникальный идентификатор группы продуктов в продуктовом каталоге.
    /// </summary>
    public string GPC { get; init; }

    /// <summary>
    ///   Получает уникальный идентификатор в продуктовом каталоге.
    /// </summary>
    public string LPC { get; init; }

    /// <summary>
    ///   Получает коллекцию действующих тарифов.
    /// </summary>

    public IEnumerable<Tariff> Tariffs { get; init; }
  }

  /// <summary>
  ///   Представляет сущность "Тариф".
  ///   "Тариф" - это ссылки на объекты внешних систем (ICDB, Midas) определяющих процентную ставку.
  /// </summary>
  public record Tariff
  {
    /// <summary>
    ///   Получает уникальный идентификатор тарифа.
    /// </summary>
    /// <remarks>
    ///   Не смотря на наличие идентификатора, тариф является типом значения,
    ///   так как связан с продуктом и не отделим от него.
    /// </remarks>
    /// <value>Значение соответствующее subtypeId счёта или nettype депозита.</value>
    [SuppressMessage("ReSharper", "MemberCanBePrivate.Global")]
    public int Id { get; init; }

    /// <summary>
    ///   Получает или задаёт 3-х буквенный код валюты в формате ISO-4217.
    /// </summary>
    /// <example>RUB</example>
    [SuppressMessage("ReSharper", "MemberCanBePrivate.Global")]
    public string Currency { get; init; }
  }
}