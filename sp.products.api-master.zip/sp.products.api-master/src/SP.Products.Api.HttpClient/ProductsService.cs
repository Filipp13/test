﻿using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace SP.Products.Api.HttpClient
{
  /// <inheritdoc />
  internal class ProductsService : IProductsService
  {
    private readonly System.Net.Http.HttpClient _client;
    private readonly JsonSerializerOptions _serializerOptions;

    public ProductsService(System.Net.Http.HttpClient client)
    {
      _client = client;
      _serializerOptions = new JsonSerializerOptions {PropertyNameCaseInsensitive = true};
    }

    /// <inheritdoc />
    public async Task<IEnumerable<Product>?> GetAsync()
    {
      var json = await _client.GetStringAsync("products");
      await using var stream = new MemoryStream(Encoding.UTF8.GetBytes(json));

      return json == string.Empty
        ? default
        : await JsonSerializer.DeserializeAsync<IEnumerable<Product>?>(stream, _serializerOptions);
    }

    /// <inheritdoc />
    public async Task<Product?> GetAsync(string gpc, string lpc)
    {
      var json = await _client.GetStringAsync(
        $"products/{gpc}/{lpc}");
      await using var stream = new MemoryStream(Encoding.UTF8.GetBytes(json));

      return json == string.Empty
        ? default
        : await JsonSerializer.DeserializeAsync<Product>(stream, _serializerOptions);
    }
  }
}