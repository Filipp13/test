using System;
using SP.Products.Api.Infrastructure;
using ViennaNET.Kernel.Domain.ValueObjects;

namespace SP.Products.Api.Application.IntegrationEvents
{
  /// <summary>
  ///   Представляет событие "Операция подписана".
  /// </summary>
  public record OperationSignedEvent : IIntegrationEvent
  {
    /// <summary>
    ///   Получает или задаёт уникальный идентификатор операции.
    /// </summary>
    public Guid OperationId { get; init; }

    /// <summary>
    ///   Получает или задаёт уникальный идентификатор клиента.
    /// </summary>
    public CustomerNumber CustomerNumber { get; init; }

    /// <summary>
    ///   Получает уникальный идентификатор группы продуктов.
    /// </summary>
    public string GPC { get; init; }

    /// <summary>
    ///   Получает уникальный идентификатор продукта.
    /// </summary>
    public string LPC { get; init; }

    /// <summary>
    ///   Получает или задаёт уникальный идентификатор тарифа.
    /// </summary>
    public int TariffId { get; init; }

    /// <summary>
    ///   Получает уникальный идентификатор специального предложения.
    /// </summary>
    public int? SpecialOfferId { get; init; }

    /// <summary>
    ///   Получает или задаёт уникальный идентификатор.
    /// </summary>
    public Guid Id { get; init; }

    /// <summary>
    ///   Получает или задаёт временную метку создания.
    /// </summary>
    public DateTime CreatedAt { get; init; }
  }
}