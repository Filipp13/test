using System;
using SP.Products.Api.Infrastructure;
using ViennaNET.Kernel.Domain.ValueObjects;

namespace SP.Products.Api.Application.IntegrationEvents
{
  /// <summary>
  ///   Представляет событие сигнализирующее о том, что счёт открыт в системе учёта.
  /// </summary>
  public record AccountOpenedEvent(
      Guid Id, DateTime CreatedAt, Guid OperationId, CustomerNumber CustomerNumber, string AccountNumber)
    : IIntegrationEvent;
}