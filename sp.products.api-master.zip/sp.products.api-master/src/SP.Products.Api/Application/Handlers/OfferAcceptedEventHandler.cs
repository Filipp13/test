using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using SP.Products.Domain.Aggregates.Events;
using ViennaNET.Mediator;

namespace SP.Products.Api.Application.Handlers
{
  /// <summary>
  ///   Представляет один из обраотчиков события <see cref="OfferAcceptedEvent" />.
  /// </summary>
  [ExcludeFromCodeCoverage(Justification = "До реализации логики исключить из анализа покрытия.")]
  public class NotifyPropositionServiceOfOfferAcceptedHandler : IMessageHandlerAsync<OfferAcceptedEvent>
  {
    /// <summary>
    ///   В текущей версии, не выполняет каких-либо действий.
    /// </summary>
    /// <param name="message">Ссылка на объект <see cref="OfferAcceptedEvent" />.</param>
    /// <param name="cancellationToken">Значение <see cref="CancellationToken" />.</param>
    /// <returns>Ссылка на объект <see cref="Task" />.</returns>
    public Task HandleAsync(OfferAcceptedEvent message, CancellationToken cancellationToken) => Task.CompletedTask;
  }
}