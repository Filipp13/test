using System;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client.Events;
using SP.Products.Api.Application.IntegrationEvents;
using SP.Products.Api.Infrastructure;
using SP.Products.Domain;
using SP.Products.Domain.Aggregates;
using SP.Products.Domain.Aggregates.Entities;

namespace SP.Products.Api.Application.Consumers
{
  /// <summary>
  ///   Представляет подписчика на <see cref="OperationSignedEvent" />
  /// </summary>
  public class AccountOpenedConsumer : IIntegrationEventHandler<AccountOpenedEvent>
  {
    private readonly ICustomersRepository _customersRepository;
    private readonly ILogger _logger;

    /// <summary>
    ///   Инициализирует новый экземпляр класса <see cref="OperationSignedConsumer" />.
    /// </summary>
    /// <param name="customersRepository"></param>
    /// <param name="productsRepository"></param>
    /// <param name="logger"></param>
    public AccountOpenedConsumer(
      ICustomersRepository customersRepository,
      ILogger<AccountOpenedConsumer> logger)
    {
      _customersRepository = customersRepository ?? throw new ArgumentNullException(nameof(customersRepository));
      _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    ///   Ссылка на объект <see cref="OperationSignedEvent" />.
    /// </summary>
    public AccountOpenedEvent? Event { get; set; }

    /// <summary>
    ///   Получает маршрут.
    /// </summary>
    public string RoutingKey { get; } = "accounts.opened";

    /// <inheritdoc />
    public async Task HandleAsync(object sender, BasicDeliverEventArgs @event)
    {
      var isCompleted = false;
      var consumer = (AsyncEventingBasicConsumer)sender;
      var json = Encoding.UTF8.GetString(@event.Body.ToArray());

      try
      {
        Event = JsonSerializer.Deserialize<AccountOpenedEvent>(json);

        if (Event is not null)
        {
          Customer? customer = await _customersRepository.FindAsync(Event.CustomerNumber);

          Account? account = customer!.Accounts.FirstOrDefault(item => item.OperationId == Event.OperationId);

          account!.BindAccountNumber(Event.AccountNumber);

          await _customersRepository.UpdateAsync(customer);

          isCompleted = true;


          if (isCompleted)
          {
            consumer.Model.BasicAck(@event.DeliveryTag, false);
          }
          else
          {
            consumer.Model.BasicNack(@event.DeliveryTag, false, true);
          }
        }
        else
        {
          consumer.Model.BasicNack(@event.DeliveryTag, false, true);
        }
      }
      catch (Exception e)
      {
        _logger.LogError(e, "Не удалось выполнить десериализацию сообщения {MessageId}",
          @event.BasicProperties.MessageId);
        consumer.Model.BasicNack(@event.DeliveryTag, false, false);
      }
    }
  }
}