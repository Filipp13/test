using System.Diagnostics.CodeAnalysis;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using ViennaNET.AspNetCore.SwaggerGen;

namespace SP.Products.Api
{
  [ExcludeFromCodeCoverage(Justification = "Класс Program не участвует в анализе покрытия.")]
  internal static class Program
  {
    public static Task Main(string[] args) => CreateHostBuilder(args).Build().RunAsync();

    private static IHostBuilder CreateHostBuilder(string[] args)
    {
      IHostBuilder? builder = Host.CreateDefaultBuilder(args);

      if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
      {
        builder.UseWindowsService();
      }

      return builder.ConfigureWebHostDefaults(webBuilder =>
      {
        webBuilder.UseSwaggerGenStartupAssembly()
          .UseStartup<Startup>();
      });
    }
  }
}