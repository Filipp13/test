using System;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Logging;
using SP.Products.Api.Application.Consumers;
using SP.Products.Api.DependencyInjection;
using SP.Products.Api.Domain;
using SP.Products.Domain;
using SP.Products.Domain.Aggregates;
using ViennaNET.Extensions.Mediator;

namespace SP.Products.Api
{
  internal class Startup
  {
    public Startup(IConfiguration configuration, IWebHostEnvironment hostEnvironment)
    {
      Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
      HostEnvironment = hostEnvironment ?? throw new ArgumentNullException(nameof(hostEnvironment));
    }

    private IConfiguration Configuration { get; }
    private IWebHostEnvironment HostEnvironment { get; }

    public void ConfigureServices(IServiceCollection services)
    {
      services.AddControllers()
        .AddJsonOptions(options => options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.Preserve);
      services.AddDefaultMediator()
        .AddRepository<IProductsRepository, ProductsRepository, Product>()
        .AddRepository<ICustomersRepository, CustomersRepository, Customer>()
        .AddUnitOfWork(Configuration)
        .AddRabbitMQClient(Configuration, HostEnvironment)
        .AddEventConsumer<OperationSignedConsumer>()
        .AddEventConsumer<AccountOpenedConsumer>()
        .AddResponseCaching()
        .AddResponseCompression()
        .AddHealthChecks();
    }

    public void Configure(IApplicationBuilder app)
    {
      if (HostEnvironment.IsDevelopment())
      {
        IdentityModelEventSource.ShowPII = true;

        app.UseDeveloperExceptionPage();
      }

      app.UseRouting();
      app.UseResponseCaching();
      app.UseResponseCompression();
      app.UseSwaggerUI(uiOptions =>
      {
        uiOptions.SwaggerEndpoint($"/swagger/{HostEnvironment.ApplicationName}/swagger.json",
          HostEnvironment.ApplicationName);
      });
      app.UseEndpoints(endpoints =>
      {
        endpoints.MapControllers();
        endpoints.MapHealthChecks("/health");
      });
    }
  }
}