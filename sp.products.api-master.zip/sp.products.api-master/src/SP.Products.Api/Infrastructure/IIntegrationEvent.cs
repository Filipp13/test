using System;
using ViennaNET.Mediator.Seedwork;

namespace SP.Products.Api.Infrastructure
{
  public interface IIntegrationEvent : IEvent
  {
    public Guid Id { get; init; }

    public DateTime CreatedAt { get; init; }
  }
}