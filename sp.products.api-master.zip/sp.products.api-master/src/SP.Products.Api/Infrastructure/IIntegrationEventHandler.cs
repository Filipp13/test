using System.Threading.Tasks;
using RabbitMQ.Client.Events;
using ViennaNET.Mediator;

namespace SP.Products.Api.Infrastructure
{
  public interface IIntegrationEventHandler : IMessageHandler
  {
    public string RoutingKey { get; }
    Task HandleAsync(object sender, BasicDeliverEventArgs @event);
  }

  public interface IIntegrationEventHandler<TEvent> : IIntegrationEventHandler
    where TEvent : IIntegrationEvent
  {
    TEvent? Event { get; set; }
  }
}