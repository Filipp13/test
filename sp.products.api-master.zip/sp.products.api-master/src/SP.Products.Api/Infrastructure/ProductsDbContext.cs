using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SP.Products.Api.Domain;
using SP.Products.Domain.Aggregates;
using ViennaNET.Domain.Seedwork;
using ViennaNET.Mediator;

namespace SP.Products.Api.Infrastructure
{
  /// <summary>
  ///   Представляет контекст доступа к базе данных продуктов.
  /// </summary>
  internal class ProductsDbContext : DbContext, IUnitOfWork
  {
    private readonly ILogger<ProductsDbContext> _logger;
    private readonly IMediator _mediator;

    /// <summary>
    ///   Инициализирует новый экземпляр класса <see cref="ProductsDbContext" />.
    /// </summary>
    /// <param name="options">Ссылка на объект <see cref="DbContextOptions{TContext}" />.</param>
    /// <param name="logger">Ссылка на объект <see cref="ILogger{TCategoryName}" />.</param>
    /// <param name="mediator">Ссылка на объект <see cref="IMediator" />.</param>
    public ProductsDbContext(
      DbContextOptions<ProductsDbContext> options,
      ILogger<ProductsDbContext> logger,
      IMediator mediator) :
      base(options)
    {
      _logger = logger ?? throw new ArgumentNullException(nameof(logger));
      _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
    }

    public async Task<bool> PublishAndSaveAsync(CancellationToken cancellationToken = default)
    {
      _logger.LogInformation("Dispatch domain events and then save changes");

      await DispatchDomainEventsAsync(cancellationToken)
        .ContinueWith(_ => base.SaveChangesAsync(cancellationToken), TaskContinuationOptions.OnlyOnRanToCompletion)
        .ConfigureAwait(false);

      _logger.LogInformation("Dispatched domain events and then changes saved");

      return true;
    }

    public async Task<bool> SaveAndPublishAsync(CancellationToken cancellationToken = default)
    {
      _logger.LogInformation("Save changes and then dispatch domain events");

      await SaveChangesAsync(cancellationToken)
        .ContinueWith(_ => DispatchDomainEventsAsync(cancellationToken), TaskContinuationOptions.OnlyOnRanToCompletion)
        .ConfigureAwait(false);

      _logger.LogInformation("Changes saved and then dispatched domain events");

      return true;
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
      _logger.LogDebug("Model creating");

      builder.ApplyConfiguration(new ProductEntityTypeConfiguration());
      builder.ApplyConfiguration(new CustomerEntityTypeConfiguration());
      builder.ApplyConfiguration(new AccountEntityTypeConfiguration());
      builder.ApplyConfiguration(new TariffEntityTypeConfiguration());

      _logger.LogDebug("Entity types registered: {Types}",
        builder.Model.GetEntityTypes().Select(type => string.Join(',', type.Name)));
    }

    private async Task DispatchDomainEventsAsync(CancellationToken cancellationToken = default)
    {
      _logger.LogInformation("Dispatch domain events");

      var entries = ChangeTracker
        .Entries<Customer>()
        .Where(x => x.Entity.Events.Any())
        .ToList();


      var events = entries
        .SelectMany(x => x.Entity.Events)
        .ToList();

      entries.ForEach(entry => entry.Entity.ClearQueue());

      foreach (var @event in events)
      {
        _logger.LogInformation("Dispatch domain {FullName}", @event.GetType().FullName);
        await _mediator.SendMessageAsync(@event, cancellationToken);
      }

      _logger.LogInformation("Dispatched domain events");
    }

#nullable disable
    /// <summary>
    ///   Получает или задаёт коллекцию клиентов <see cref="Customer" />.
    /// </summary>
    public DbSet<Customer> Customers { get; set; }

    /// <summary>
    ///   Получает или задаёт коллекцию клиентов <see cref="Product" />.
    /// </summary>
    public DbSet<Product> Products { get; set; }
#nullable restore
  }
}