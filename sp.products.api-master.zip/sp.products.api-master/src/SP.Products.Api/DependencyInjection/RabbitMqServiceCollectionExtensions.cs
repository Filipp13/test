using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using SP.Products.Api.Infrastructure;
using SP.Products.Api.Services;

namespace SP.Products.Api.DependencyInjection
{
  [ExcludeFromCodeCoverage(Justification = "Этот тип необходимо вынести в ViennaNET и покрыть тестами там")]
  internal static class RabbitMqServiceCollectionExtensions
  {
    public static IServiceCollection AddRabbitMQClient(this IServiceCollection services,
      IConfiguration configuration,
      IWebHostEnvironment environment)
    {
      services.AddSingleton<IConnectionFactory, ConnectionFactory>()
        .AddOptions<RabbitMQOptions>()
        .Bind(configuration.GetSection(RabbitMQOptions.SectionName))
        .Configure<IConnectionFactory>((options, factory) =>
        {
          ((ConnectionFactory)factory).Uri = new Uri(options.BaseAddress);
          ((ConnectionFactory)factory).DispatchConsumersAsync = true;
        });
      services.AddSingleton<IConnection>(provider =>
      {
        RabbitMQOptions? options = provider.GetRequiredService<IOptions<RabbitMQOptions>>().Value;
        IConnectionFactory? factory = provider.GetRequiredService<IConnectionFactory>();
        return factory.CreateConnection(environment.ApplicationName);
      });

      services.AddHostedService<RabbitMqHostedService>();
      return services;
    }

    public static IServiceCollection AddEventConsumer<TEventHandler>(
      this IServiceCollection services)
      where TEventHandler : class, IIntegrationEventHandler =>
      services.AddScoped<IIntegrationEventHandler, TEventHandler>();
  }
}