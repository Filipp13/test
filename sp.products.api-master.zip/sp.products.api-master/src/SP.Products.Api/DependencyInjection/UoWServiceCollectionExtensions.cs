using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SP.Products.Api.Infrastructure;

namespace SP.Products.Api.DependencyInjection
{
  internal static class UoWServiceCollectionExtensions
  {
    public static IServiceCollection AddUnitOfWork(this IServiceCollection services, IConfiguration configuration)
    {
      services
        .AddDbContext<ProductsDbContext>(options =>
          {
            options.UseSqlServer(configuration.GetConnectionString("SP.Products.Api"),
              sqlServerOptions =>
              {
                sqlServerOptions.EnableRetryOnFailure(15, TimeSpan.FromSeconds(30), null);
              });
          }
        );

      return services;
    }
  }
}