using Microsoft.Extensions.DependencyInjection;
using ViennaNET.Domain.Seedwork;

namespace SP.Products.Api.DependencyInjection
{
  internal static class RepositoryServiceCollectionExtensions
  {
    public static IServiceCollection AddRepository<TRepository, TImplementation, TEntity>(
      this IServiceCollection services)
      where TEntity : IAggregateRoot
      where TRepository : class, IRepository<TEntity>
      where TImplementation : class, TRepository =>
      services.AddScoped<TRepository, TImplementation>();
  }
}