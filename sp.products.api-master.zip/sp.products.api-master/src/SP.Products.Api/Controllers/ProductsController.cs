using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SP.Products.Domain;
using SP.Products.Domain.Aggregates;

namespace SP.Products.Api.Controllers
{
  /// <summary>
  ///   Предоставляет API для управления ресурсами типа <see cref="Product" />.
  /// </summary>
  [ApiController]
  [Route("api/v1/[controller]")]
  [Produces("application/json")]
  [ApiConventionType(typeof(DefaultApiConventions))]
  public class ProductsController : ControllerBase
  {
    private readonly IProductsRepository _productsRepository;

    /// <summary>
    ///   Инициализирует новый экземпляр класса <see cref="ProductsController" />
    /// </summary>
    /// <param name="productsRepository">Ссылка на объект <see cref="IProductsRepository" />.</param>
    public ProductsController(IProductsRepository productsRepository)
    {
      _productsRepository = productsRepository;
    }

    /// <summary>
    ///   Получить коллекцию всех экземпляров ресурса <see cref="Product" />.
    /// </summary>
    /// <remarks>
    ///   "Продукт" - это определение счёта в продуктовом каталоге банка, с ним связанны тарифы.
    ///   Тариф связан с продуктом через предложение.
    ///   Именно предложение отображается в пользовательском интерфейсе онлайн банка.
    ///   С предложениями связанны локализованные ресурсы в службе ресурсов.
    /// </remarks>
    /// <returns>Коллекция всех зарегистрированных экземпляров ресурса <see cref="Product" />.</returns>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesDefaultResponseType]
    public Task<List<Product>> GetAsync() => _productsRepository.ToListAsync();

    /// <summary>
    ///   Получает ресурс <see cref="Product" />  по заданному идентификатору.
    /// </summary>
    /// <param name="gpc">Group product code - уникальный идентификатор группы продуктов.</param>
    /// <param name="lpc">Local product code - уникальный идентификатор.</param>
    /// <remarks>
    ///   "Продукт" - это определение счёта в продуктовом каталоге банка, с ним связанны тарифы.
    ///   Тариф связан с продуктом через предложение.
    ///   Именно предложение отображается в пользовательском интерфейсе онлайн банка.
    ///   С предложениями связанны локализованные ресурсы в службе ресурсов.
    /// </remarks>
    /// <returns>
    ///   Ссылка на объект <see cref="Product" /> если продукт найден,
    ///   иначе HTTP Status Code = <see cref="StatusCodes.Status404NotFound" />.
    /// </returns>
    [HttpGet("{gpc}/{lpc}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesDefaultResponseType]
    public Task<Product?> GetAsync(string gpc, string lpc) => _productsRepository.FindAsync(gpc, lpc);
  }
}