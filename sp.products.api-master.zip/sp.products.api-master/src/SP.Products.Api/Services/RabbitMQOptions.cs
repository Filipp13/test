using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace SP.Products.Api.Services
{
  [ExcludeFromCodeCoverage(Justification = "Этот тип необходимо вынести в ViennaNET и покрыть тестами там")]
  public class RabbitMQOptions
  {
    /// <summary>
    ///   Получает наименование секции в конфигурации приложения.
    /// </summary>
    public static readonly string SectionName = "Endpoints:RabbitMQ";

    /// <summary>
    ///   Базовый адрес службы.
    /// </summary>
    public string BaseAddress { get; set; } = "localhost";

    /// <summary>
    ///   Коллекция настроек очередей.
    /// </summary>
    public IEnumerable<RabbitMQExchangeOptions>? Exchanges { get; set; }

    /// <summary>
    ///   Получает или задаёт общее время ожидания для всех попыток в секундах.
    /// </summary>
    public int OverallTimeout { get; set; } = 60;

    /// <summary>
    ///   Получает или задаёт время ожидания для каждой отдельной попыти в секундах.
    /// </summary>
    /// <remarks>
    ///   Общее время выполнения запроса ограничено значением <see cref="OverallTimeout" />.
    ///   Независимо от количества повторных попыток.
    /// </remarks>
    public int TryTimeout { get; set; } = 3;

    /// <summary>
    ///   Получает или задаёт время задержки первой повторной попытки в секундах.
    /// </summary>
    /// <remarks>
    ///   Последующие попытки будут выполняться с экспоненциальной задержкой.
    /// </remarks>
    public int RetryDelay { get; set; } = 3;

    /// <summary>
    ///   Задаёт максимальное количество повторных попыток.
    /// </summary>
    public int RetryCount { get; set; } = 10;
  }
}