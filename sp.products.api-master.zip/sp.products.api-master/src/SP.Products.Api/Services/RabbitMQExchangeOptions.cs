using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace SP.Products.Api.Services
{
  [ExcludeFromCodeCoverage(Justification = "Этот тип необходимо вынести в ViennaNET и покрыть тестами там")]
  public class RabbitMQExchangeOptions
  {
    public string? Name { get; set; }
    public string Type { get; set; } = "direct";
    public bool Durable { get; set; } = false;
    public bool AutoDelete { get; set; } = false;
    public IDictionary<string, object>? Arguments { get; set; }

    /// <summary>
    ///   Коллекция настроек очередей.
    /// </summary>
    public IEnumerable<RabbitMQQueueOptions>? Queues { get; set; }
  }
}