using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using SP.Products.Api.Infrastructure;

namespace SP.Products.Api.Services
{
  [ExcludeFromCodeCoverage(Justification = "Этот тип необходимо вынести в ViennaNET и покрыть тестами там")]
  internal class RabbitMqHostedService : IHostedService
  {
    private readonly IConnection _connection;
    private readonly ILogger<RabbitMqHostedService> _logger;
    private readonly IOptions<RabbitMQOptions> _options;
    private readonly IServiceScopeFactory _serviceScopeFactory;

    public RabbitMqHostedService(ILogger<RabbitMqHostedService> logger,
      IOptions<RabbitMQOptions> options,
      IConnection connection,
      IServiceScopeFactory serviceScopeFactory)
    {
      _logger = logger ?? throw new ArgumentNullException(nameof(logger));
      _connection = connection ?? throw new ArgumentNullException(nameof(connection));
      _serviceScopeFactory = serviceScopeFactory ?? throw new ArgumentNullException(nameof(serviceScopeFactory));
      _options = options ?? throw new ArgumentNullException(nameof(options));

      _connection.ConnectionShutdown += ConnectionOnConnectionShutdown;
      _connection.ConnectionBlocked += ConnectionOnConnectionBlocked;
      _connection.ConnectionUnblocked += ConnectionOnConnectionUnblocked;
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
      using IServiceScope? scope = _serviceScopeFactory.CreateScope();
      var handlers = scope.ServiceProvider.GetRequiredService<IEnumerable<IIntegrationEventHandler>>().ToList();

      if (_options.Value.Exchanges is null)
      {
        return Task.CompletedTask;
      }

      foreach (var exchange in _options.Value.Exchanges)
      {
        IModel? channel = _connection.CreateModel();

        channel.CallbackException += (sender, args) =>
        {
          _logger.LogWarning("RabbitMQ channel has been shutdown");
          channel = _connection.CreateModel();
        };

        channel.ExchangeDeclare(
          exchange.Name, exchange.Type, exchange.Durable, exchange.AutoDelete, exchange.Arguments);

        if (exchange.Queues is not null)
        {
          foreach (var queue in exchange.Queues)
          {
            QueueDeclareOk? queueDeclare = channel.QueueDeclare(
              queue.Name, queue.Durable, queue.Exclusive, queue.AutoDelete, queue.Arguments);

            _logger.LogDebug(
              "Queue {QueueName} has been declare. Current consumers {ConsumerCount} and messages in queue {MessageCount}",
              queueDeclare.QueueName, queueDeclare.ConsumerCount, queueDeclare.MessageCount);

            if (queue.RoutingKeys is not null)
            {
              foreach (var routingKey in queue.RoutingKeys)
              {
                channel.QueueBind(queueDeclare.QueueName, exchange.Name, routingKey);

                var eventHandlers = handlers.Where(handler => handler.RoutingKey == routingKey)
                  .ToList();
                foreach (var handler in eventHandlers)
                {
                  var consumer = new AsyncEventingBasicConsumer(channel);
                  consumer.Received += handler.HandleAsync;
                  consumer.Shutdown += (sender, @event)
                    =>
                  {
                    _logger.LogWarning("RabbitMQ consumer channel has been shutdown for reason: {Reason}",
                      @event.ReplyText);
                    return Task.CompletedTask;
                  };
                  channel.BasicConsume(queue.Name, false, consumer);
                }
              }
            }
          }
        }

        _logger.LogDebug("Exchange {Name} has been declare", exchange.Name);
      }

      return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
      _connection.Close();
      return Task.CompletedTask;
    }

    private void ConnectionOnConnectionShutdown(object? sender, ShutdownEventArgs e) => _logger.LogWarning(e.ReplyCode,
      "RabbitMQ connection has been shutdown for reason: {Reason}", e.ReplyText);

    private void ConnectionOnConnectionBlocked(object? sender, ConnectionBlockedEventArgs e) =>
      _logger.LogWarning("RabbitMQ connection has been blocked for {Reason}", e.Reason);

    private void ConnectionOnConnectionUnblocked(object? sender, EventArgs e) =>
      _logger.LogWarning("RabbitMQ connection has been unblocked. The service resumed sending messages");
  }
}