using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace SP.Products.Api.Services
{
  [ExcludeFromCodeCoverage(Justification = "Этот тип необходимо вынести в ViennaNET и покрыть тестами там")]
  public class RabbitMQQueueOptions
  {
    public string? Name { get; set; }
    public string[]? RoutingKeys { get; set; }
    public bool Durable { get; set; } = false;
    public bool Exclusive { get; set; } = false;
    public bool AutoDelete { get; set; } = false;

    public IDictionary<string, object>? Arguments { get; set; }
  }
}