using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SP.Products.Domain.Aggregates.ValueTypes;

namespace SP.Products.Api.Domain
{
  internal class TariffEntityTypeConfiguration : IEntityTypeConfiguration<Tariff>
  {
    public void Configure(EntityTypeBuilder<Tariff> builder)
    {
      builder.ToTable("Tariffs")
        .HasKey(tariff => tariff.Id)
        .HasName("PK_Tariffs");

      builder.Property(tariff => tariff.Currency)
        .HasConversion(currency => currency.ToString(), s => new Currency(s));
    }
  }
}