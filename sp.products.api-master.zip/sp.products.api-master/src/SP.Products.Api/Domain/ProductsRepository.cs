using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SP.Products.Api.Infrastructure;
using SP.Products.Domain;
using SP.Products.Domain.Aggregates;
using ViennaNET.Domain.Seedwork;

namespace SP.Products.Api.Domain
{
  /// <inheritdoc />
  [SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
  internal class ProductsRepository : IProductsRepository
  {
    private readonly ProductsDbContext _context;

    public ProductsRepository(ProductsDbContext context)
    {
      _context = context;
    }

    /// <inheritdoc />
    public IUnitOfWork UnitOfWork => _context;

    /// <inheritdoc />
    public Task<List<Product>> ToListAsync()
      => _context.Products.Include(product => product.Tariffs).ToListAsync();

    /// <inheritdoc />
    public Task<Product?> FindAsync(string gpc, string lpc) => _context.Products.FindAsync(gpc, lpc).AsTask();
  }
}