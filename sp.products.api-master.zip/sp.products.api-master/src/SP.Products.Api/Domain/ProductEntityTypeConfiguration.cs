using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SP.Products.Domain.Aggregates;
using SP.Products.Domain.Aggregates.ValueTypes;

namespace SP.Products.Api.Domain
{
  internal class ProductEntityTypeConfiguration : IEntityTypeConfiguration<Product>
  {
    public void Configure(EntityTypeBuilder<Product> builder)
    {
      builder.ToTable("Products")
        .HasKey(product => new {product.GPC, product.LPC})
        .HasName("PK_Products");

      builder.Property(product => product.Name)
        .HasMaxLength(6);

      builder.HasMany(product => product.Tariffs)
        .WithMany(offer => offer.Products)
        .UsingEntity<Offer>(
          typeBuilder => typeBuilder.ToTable("Offers")
            .HasOne(offer => offer.Tariff)
            .WithMany(tariff => tariff.Offers)
            .OnDelete(DeleteBehavior.Cascade)
            .HasForeignKey("TariffsId")
            .IsRequired(),
          typeBuilder => typeBuilder.HasOne(offer => offer.Product)
            .WithMany(product => product.Offers)
            .OnDelete(DeleteBehavior.Cascade)
            .HasForeignKey("ProductsGPC", "ProductsLPC")
            .IsRequired(),
          typeBuilder => typeBuilder.HasKey("ProductsGPC", "ProductsLPC", "TariffsId")
        );
    }
  }
}