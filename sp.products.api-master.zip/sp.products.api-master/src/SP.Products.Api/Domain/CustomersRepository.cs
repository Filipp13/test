using System;
using System.Threading;
using System.Threading.Tasks;
using SP.Products.Api.Infrastructure;
using SP.Products.Domain;
using SP.Products.Domain.Aggregates;
using ViennaNET.Domain.Seedwork;
using ViennaNET.Kernel.Domain.ValueObjects;

namespace SP.Products.Api.Domain
{
  /// <inheritdoc />
  internal class CustomersRepository : ICustomersRepository
  {
    private readonly ProductsDbContext _context;

    public CustomersRepository(ProductsDbContext context)
    {
      _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    /// <inheritdoc />
    public IUnitOfWork UnitOfWork => _context;

    /// <inheritdoc />
    public async Task<Customer> AddAsync(Customer customer, CancellationToken cancellationToken = default)
    {
      Customer? entity = (await _context.Customers.AddAsync(customer, cancellationToken).ConfigureAwait(false)).Entity;
      await UnitOfWork.PublishAndSaveAsync(cancellationToken).ConfigureAwait(false);
      return entity;
    }

    /// <inheritdoc />
    public async Task<Customer> UpdateAsync(Customer customer, CancellationToken cancellationToken = default)
    {
      Customer? entity = _context.Customers.Update(customer).Entity;
      await UnitOfWork.PublishAndSaveAsync(cancellationToken).ConfigureAwait(false);
      return entity;
    }

    /// <inheritdoc />
    public Task<Customer?> FindAsync(CustomerNumber number, CancellationToken cancellationToken = default)
      => _context.Customers.FindAsync(new object[] {number}, cancellationToken).AsTask();
  }
}