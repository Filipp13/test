using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SP.Products.Domain.Aggregates.Entities;
using ViennaNET.Kernel.Domain.ValueObjects;

namespace SP.Products.Api.Domain
{
  internal class AccountEntityTypeConfiguration : IEntityTypeConfiguration<Account>
  {
    public void Configure(EntityTypeBuilder<Account> builder)
    {
      builder.ToTable("Accounts");

      builder.Property<string>("ProductsGPC");
      builder.Property<string>("ProductsLPC");
      builder.Property<int>("TariffsId");
      builder.Property<CustomerNumber>("CustomerNumber")
        .HasConversion(number => number.ToString(), s => new CustomerNumber(s));
      builder.HasKey("ProductsGPC", "ProductsLPC", "TariffsId", "CustomerNumber", "OperationId")
        .HasName("PK_Accounts");
      builder.Property(account => account.OperationId)
        .ValueGeneratedNever();

      builder.HasOne(account => account.Owner)
        .WithMany(customer => customer.Accounts)
        .HasForeignKey("CustomerNumber")
        .HasConstraintName("FK_Accounts_Customers")
        .IsRequired();

      builder.HasOne(account => account.Offer)
        .WithMany()
        .HasForeignKey("ProductsGPC", "ProductsLPC", "TariffsId")
        .HasConstraintName("FK_Accounts_Offers")
        .IsRequired();
    }
  }
}