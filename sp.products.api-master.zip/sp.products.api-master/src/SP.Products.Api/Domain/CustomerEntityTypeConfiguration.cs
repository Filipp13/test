using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SP.Products.Domain.Aggregates;
using ViennaNET.Kernel.Domain.ValueObjects;

namespace SP.Products.Api.Domain
{
  internal class CustomerEntityTypeConfiguration : IEntityTypeConfiguration<Customer>
  {
    public void Configure(EntityTypeBuilder<Customer> builder)
    {
      builder.ToTable("Customers")
        .HasKey(customer => customer.Id)
        .HasName("PK_Customers");

      builder.Property(customer => customer.Id)
        .HasConversion(number => number.ToString(), s => new CustomerNumber(s))
        .HasColumnName("Number")
        .HasMaxLength(6);

      builder.HasMany(customer => customer.Accounts)
        .WithOne(account => account.Owner)
        .HasForeignKey("CustomerNumber")
        .HasConstraintName("FK_Accounts_Customers")
        .IsRequired();
    }
  }
}