using System;
using System.Linq;
using NUnit.Framework;
using SP.Products.Domain.Aggregates;
using SP.Products.Domain.Aggregates.Entities;
using SP.Products.Domain.Aggregates.ValueTypes;
using ViennaNET.Kernel.Domain.ValueObjects;

namespace SP.Products.Domain.Tests.Aggregates.Entities
{
  [TestFixture(Category = "Unit", TestOf = typeof(Account))]
  public class AccountTests
  {
    [SetUp]
    public void SetUp()
    {
      var product = new Product("FD0200", "SA02", "Saving Account");
      var operationId = Guid.NewGuid();
      product.AddTariff(1, Currency.RUB);
      Offer offer = product.Offers.Single();

      Customer = new Customer(new CustomerNumber(123456));
      Customer.AcceptOffer(operationId, offer);
      Account = Customer.Accounts.Single();
    }

    private const string TestAccountNumber = "12345678901234567890";

    [Test]
    public void BindAccountNumber_DoesNotThrow() =>
      Assert.DoesNotThrow(() => Account.BindAccountNumber(TestAccountNumber));

    [Test]
    public void BindAccountNumber_Number_IsBind()
    {
      Account.BindAccountNumber(TestAccountNumber);

      Assert.AreEqual(TestAccountNumber, Account.Number);
    }

    [TestCase("123")]
    [TestCase("1234567890123456789A")]
    [TestCase("1234567890123456789b")]
    [TestCase("")]
    public void BindAccountNumber_Throw_FormatException(string input)
    {
      Account.BindAccountNumber(TestAccountNumber);

      Assert.Catch<FormatException>(() => Account.BindAccountNumber(input));
    }

    [Test]
    public void BindAccountNumber_Throw_ArgumentNullException() =>
      Assert.Catch<ArgumentNullException>(() => Account.BindAccountNumber(null!));

#nullable disable
    private Customer Customer { get; set; }
    private Account Account { get; set; }
#nullable restore
  }
}