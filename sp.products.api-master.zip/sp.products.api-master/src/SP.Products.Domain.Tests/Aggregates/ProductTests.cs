using System;
using System.Linq;
using NUnit.Framework;
using SP.Products.Domain.Aggregates;
using SP.Products.Domain.Aggregates.ValueTypes;

namespace SP.Products.Domain.Tests.Aggregates
{
  [TestFixture(Category = "Unit", TestOf = typeof(Product))]
  public class ProductTests
  {
    [TestCase("F12345", "A123", "TestProduct")]
    [TestCase("012345", "0123", "TestProduct2")]
    public void DefaultCtor_DoesNotThrow(string gpc, string lpc, string name)
      => Assert.DoesNotThrow(() => _ = new Product(gpc, lpc, name));

    [TestCase("F12345", "A123", "TestProduct")]
    [TestCase("012345", "0123", "TestProduct2")]
    public void Ctor_ShouldBe_Product_Initialized(string gpc, string lpc, string name)
    {
      var product = new Product(gpc, lpc, name);

      Assert.Multiple(() =>
      {
        Assert.AreEqual(gpc, product.GPC);
        Assert.AreEqual(lpc, product.LPC);
        Assert.AreEqual(name, product.Name);
      });
    }

    [TestCase("", "")]
    [TestCase("F12345", "")]
    [TestCase("", "A123")]
    [TestCase("F1234", "A123")]
    [TestCase("F12345", "A12")]
    public void Ctor_Throw_FormatException(string gpc, string lpc)
      => Assert.Catch<FormatException>(() => _ = new Product(gpc, lpc, "TestProduct"));

    [TestCase(null, "A123", "TestProduct")]
    [TestCase("F12345", null, "TestProduct")]
    [TestCase("F12345", "A123", null)]
    public void Ctor_Throw_ArgumentNullException(string gpc, string lpc, string name)
      => Assert.Catch<ArgumentNullException>(() => _ = new Product(gpc, lpc, name));

    [Test]
    public void AddTariff__ShouldBe_Adds_Tariff()
    {
      const int tariffId = 1;
      var product = new Product("F12345", "A123", "TestProduct");

      product.AddTariff(tariffId, Currency.RUB);

      Offer? offer = product.Offers.SingleOrDefault();
      Tariff? tariff = product.Tariffs.SingleOrDefault();

      Assert.Multiple(() =>
      {
        Assert.IsNotNull(offer);
        Assert.IsNotNull(tariff);
        Assert.AreEqual(product, offer!.Product);
        Assert.AreEqual(tariff, offer.Tariff);
        Assert.AreEqual(Currency.RUB, offer.Tariff.Currency);
        Assert.AreEqual(tariffId, offer.Tariff.Id);
        CollectionAssert.IsNotEmpty(tariff!.Offers);
        CollectionAssert.IsNotEmpty(tariff.Products);
      });
    }

    [Test]
    public void AddTariff_Throw_ArgumentNullException()
    {
      var product = new Product("F12345", "A123", "TestProduct");

      Assert.Catch<ArgumentNullException>(() => product.AddTariff(1, null!));
    }
  }
}