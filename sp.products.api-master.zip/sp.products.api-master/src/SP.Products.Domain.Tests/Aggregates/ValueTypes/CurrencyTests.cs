using System;
using NUnit.Framework;
using SP.Products.Domain.Aggregates.ValueTypes;

namespace SP.Products.Domain.Tests.Aggregates.ValueTypes
{
  [TestFixture(Category = "Unit", TestOf = typeof(Currency))]
  public class CurrencyTests
  {
    [Test]
    public void Ctor_DoesNotThrow() => Assert.DoesNotThrow(() => _ = new Currency("RUR"));

    [Test]
    public void Ctor_Throw_ArgumentNullException()
      => Assert.Catch<ArgumentNullException>(() => _ = new Currency(null!));

    [TestCase("s")]
    [TestCase("rur")]
    [TestCase("")]
    [TestCase("1")]
    public void Ctor_Throw_FormatException(string input)
      => Assert.Catch<FormatException>(() => _ = new Currency(input));

    [Test]
    public void ToString_Return_ISO_Code() => Assert.AreEqual("RUB", new Currency("RUR").ToString());

    [TestCase("s")]
    [TestCase("rur")]
    [TestCase("")]
    [TestCase(null)]
    [TestCase("1")]
    public void ImplicitOperatorCurrency_DoesNotThrow_And_ReturnNull(string input) => Assert.IsNull((Currency?)input);

    [TestCase("RUR", ExpectedResult = "RUB")]
    [TestCase("USD", ExpectedResult = "USD")]
    public string ImplicitOperatorString_Return_ISO_Code(string input) => new Currency(input);
  }
}