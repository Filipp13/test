using System;
using System.Linq;
using NUnit.Framework;
using SP.Products.Domain.Aggregates;
using SP.Products.Domain.Aggregates.Entities;
using SP.Products.Domain.Aggregates.Events;
using SP.Products.Domain.Aggregates.ValueTypes;
using ViennaNET.Kernel.Domain.ValueObjects;

namespace SP.Products.Domain.Tests.Aggregates
{
  [TestFixture(Category = "Unit", TestOf = typeof(Customer))]
  public class CustomerTests
  {
    [SetUp]
    public void SetUp()
    {
      Customer = new Customer(new CustomerNumber(123456));
      Product = new Product("FD0200", "SA02", "Saving Account");
      Product.AddTariff(1, Currency.RUB);
    }

    [Test]
    public void Ctor_DoesNotThrow() => Assert.DoesNotThrow(() => _ = new Customer(new CustomerNumber(123456)));

    [Test]
    public void AcceptOffer_ShouldBe_Adds_Account()
    {
      var operationId = Guid.NewGuid();
      Offer offer = Product.Offers.Single();

      bool Predicate(Account item)
      {
        return item.Owner.Equals(Customer) &&
          item.Offer.Equals(offer) &&
          item.Number is null &&
          item.OperationId == operationId &&
          item.SpecialOfferId is null;
      }

      Customer.AcceptOffer(operationId, offer);

      Account? account = Customer.Accounts.SingleOrDefault(Predicate);
      var offerAcceptedEvent = (OfferAcceptedEvent?)Customer.Events.SingleOrDefault();

      Assert.Multiple(() =>
      {
        CollectionAssert.IsNotEmpty(Customer.Accounts);
        CollectionAssert.IsNotEmpty(Customer.Events);
        Assert.IsNotNull(account);
        Assert.IsNotNull(offerAcceptedEvent);
        Assert.AreEqual(account, offerAcceptedEvent!.Account);
      });
    }

    [Test]
    public void AcceptOffer_BySpecialOffer_ShouldBe_Adds_Account()
    {
      const int specialOfferId = 1;
      var operationId = Guid.NewGuid();
      Offer offer = Product.Offers.Single();

      bool Predicate(Account item)
      {
        return item.Owner.Equals(Customer) &&
          item.Offer.Equals(offer) &&
          item.Number is null &&
          item.OperationId == operationId &&
          item.SpecialOfferId == specialOfferId;
      }

      Customer.AcceptOffer(operationId, offer, specialOfferId);
      Account? account = Customer.Accounts.SingleOrDefault(Predicate);
      var offerAcceptedEvent = (OfferAcceptedEvent?)Customer.Events.SingleOrDefault();

      Assert.Multiple(() =>
      {
        CollectionAssert.IsNotEmpty(Customer.Accounts);
        CollectionAssert.IsNotEmpty(Customer.Events);
        Assert.IsNotNull(account);
        Assert.IsNotNull(offerAcceptedEvent);
        Assert.AreEqual(account, offerAcceptedEvent!.Account);
      });
    }

#nullable disable
    private Customer Customer { get; set; }
    private Product Product { get; set; }
#nullable restore
  }
}