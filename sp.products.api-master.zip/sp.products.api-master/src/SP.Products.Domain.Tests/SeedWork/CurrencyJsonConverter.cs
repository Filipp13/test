using System.Text.Json;
using NUnit.Framework;
using SP.Products.Domain.Aggregates.ValueTypes;

namespace SP.Products.Domain.Tests.SeedWork
{
  [TestFixture(Category = "Unit", TestOf = typeof(CurrencyJsonConverter))]
  public class CurrencyJsonConverter
  {
    [Test]
    public void Read_Currency_Return_IsNotNull()
      => Assert.AreEqual("USD", (string?)JsonSerializer.Deserialize<Currency>("\"USD\"")!);

    [Test]
    public void Read_Currency_Return_IsNull()
      => Assert.IsNull(JsonSerializer.Deserialize<Currency>("\"USd\"")!);

    [Test]
    public void Write_Currency_DoesNotThrow()
      => TestContext.Out.WriteLine(JsonSerializer.Serialize(new Currency("RUR")));
  }
}