using System.Collections.Generic;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Builder;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using SP.Products.Domain;

namespace SP.Products.Api.Tests
{
  [TestFixture(Category = "Integration", TestOf = typeof(Startup))]
  public class StartupTests
  {
    [SetUp]
    public void Setup()
    {
      IConfigurationBuilder? builder = new ConfigurationBuilder()
        .AddInMemoryCollection(new Dictionary<string, string>
        {
          {"ConnectionStrings:SP.Products.Api", "Database=SP.Products.Api;Server=localhost,1433;"}
        });

      _config = builder.Build();
      _envMock = new Mock<IWebHostEnvironment>();
    }

    [Test]
    public void Ctor_DoesNotThrow()
      => Assert.DoesNotThrow(() => _ = new Startup(_config, _envMock.Object));

    [Test]
    public void ConfigureServices_DoesNotThrow()
    {
      var startup = new Startup(_config, _envMock.Object);
      var services = new ServiceCollection();

      Assert.DoesNotThrow(() => startup.ConfigureServices(services));
    }

    [Test]
    public void ConfigureServices_BuildServiceProvider_GetRequiredService()
    {
      var startup = new Startup(_config, _envMock.Object);
      var services = new ServiceCollection();

      services.AddLogging(builder => builder.AddSimpleConsole());

      startup.ConfigureServices(services);

      ServiceProvider? provider = services.BuildServiceProvider(true);
      using IServiceScope? scope = provider.CreateScope();
      IProductsRepository? productsRepository = scope.ServiceProvider.GetRequiredService<IProductsRepository>();
      ICustomersRepository? customersRepository = scope.ServiceProvider.GetRequiredService<ICustomersRepository>();

      Assert.Multiple(() =>
      {
        Assert.IsNotNull(productsRepository);
        Assert.IsNotNull(customersRepository);
      });
    }

    [Test]
    public void Configure_DoesNotThrow()
    {
      var startup = new Startup(_config, _envMock.Object);
      var services = new ServiceCollection();

      startup.ConfigureServices(services);
      services.AddRouting();
      services.AddLogging(builder => builder.AddSimpleConsole());

      IApplicationBuilder? applicationBuilder = new ApplicationBuilderFactory(services.BuildServiceProvider())
        .CreateBuilder(new FeatureCollection());

      Assert.DoesNotThrow(() => startup.Configure(applicationBuilder));
    }

    [Test]
    public void Configure_With_DevelopmentEnv_DoesNotThrow()
    {
      _envMock.Setup(environment => environment.EnvironmentName).Returns("Development");
      var startup = new Startup(_config, _envMock.Object);
      var services = new ServiceCollection();

      startup.ConfigureServices(services);
      services.AddRouting();
      services.AddLogging(builder => builder.AddSimpleConsole());

      IApplicationBuilder? applicationBuilder = new ApplicationBuilderFactory(services.BuildServiceProvider())
        .CreateBuilder(new FeatureCollection());

      Assert.DoesNotThrow(() => startup.Configure(applicationBuilder));
    }
#nullable disable
    private IConfiguration _config;
    private Mock<IWebHostEnvironment> _envMock;
#nullable restore
  }
}