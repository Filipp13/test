using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using SP.Products.Api.Domain;
using SP.Products.Api.Infrastructure;
using SP.Products.Domain.Aggregates;
using SP.Products.Domain.Aggregates.ValueTypes;
using ViennaNET.Kernel.Domain.ValueObjects;
using ViennaNET.Mediator;

namespace SP.Products.Api.Tests.Domain
{
  [TestFixture(Category = "Unit", TestOf = typeof(CustomersRepository))]
  public class CustomersRepositoryTests
  {
    [OneTimeSetUp]
    public void Setup()
    {
      DbContextOptions<ProductsDbContext>?
        options = _provider.GetRequiredService<DbContextOptions<ProductsDbContext>>();
      ILogger<ProductsDbContext>? logger = new Mock<ILogger<ProductsDbContext>>().Object;
      IMediator? mediator = new Mock<IMediator>().Object;
      using var context = new ProductsDbContext(options, logger, mediator);
      context.Customers.Add(new Customer(new CustomerNumber(123456)));
      context.Customers.Add(new Customer(new CustomerNumber(123457)));
      context.SaveChanges();

      Context = _provider.GetRequiredService<ProductsDbContext>();
    }

    public CustomersRepositoryTests()
    {
      var mediatorMock = new Mock<IMediator>();
      var services = new ServiceCollection();
      services
        .AddLogging(builder =>
        {
          builder.AddSimpleConsole(options => options.IncludeScopes = true)
            .SetMinimumLevel(LogLevel.Trace)
            .AddDebug();
        })
        .AddSingleton(mediatorMock.Object)
        .AddEntityFrameworkInMemoryDatabase()
        .AddDbContext<ProductsDbContext>(
          builder => builder.UseInMemoryDatabase("TestDB")
            .UseInternalServiceProvider(_provider)
            .EnableSensitiveDataLogging(),
          ServiceLifetime.Singleton);

      _provider = services.BuildServiceProvider(true);
    }

    [Test]
    public void UnitOfWork_Get_ReturnProductsDbContext()
      => Assert.IsInstanceOf<ProductsDbContext>(new CustomersRepository(Context).UnitOfWork);

    [Test]
    public async Task AddAsync_ShouldBe_Added_ToDatabase()
    {
      var repository = new CustomersRepository(Context);
      Customer? customer = await repository.AddAsync(new Customer(new CustomerNumber(123451)));

      Assert.AreEqual(customer, await repository.FindAsync(customer.Id));
    }

    [Test]
    public async Task UpdateAsync_ShouldBe_Updated_InDatabase()
    {
      var product = new Product("FD0200", "SA02", "Saving Account");
      var repository = new CustomersRepository(Context);

      Customer customer = await repository.AddAsync(new Customer(new CustomerNumber(123455)));
      product.AddTariff(1, Currency.RUB);
      await Context.Products.AddAsync(product);
      await Context.SaveAndPublishAsync();
      Customer? savedCustomer = await repository.FindAsync(customer.Id);
      savedCustomer!.AcceptOffer(Guid.NewGuid(), product.Offers.Single());
      Customer updatedCustomer = await repository.UpdateAsync(savedCustomer);

      Assert.IsNotNull(updatedCustomer.Accounts.Single());
    }

    [TestCase(123456)]
    [TestCase(123457)]
    public async Task FindAsync_IsNotNull(int id)
      => Assert.IsNotNull(await new CustomersRepository(Context).FindAsync(new CustomerNumber(id)));

    [TestCase("01")]
    [TestCase("123458")]
    public async Task FindAsync_IsNull(string id)
      => Assert.IsNull(await new CustomersRepository(Context).FindAsync(new CustomerNumber(id)));
#nullable disable
    private readonly ServiceProvider _provider;
    private ProductsDbContext Context { get; set; }
#nullable restore
  }
}