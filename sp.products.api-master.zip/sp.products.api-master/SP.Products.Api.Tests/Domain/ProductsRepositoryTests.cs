using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using SP.Products.Api.Domain;
using SP.Products.Api.Infrastructure;
using SP.Products.Domain.Aggregates;
using ViennaNET.Mediator;

namespace SP.Products.Api.Tests.Domain
{
  [TestFixture(Category = "Unit", TestOf = typeof(ProductsRepository))]
  public class ProductsRepositoryTests
  {
    [OneTimeSetUp]
    public void Setup()
    {
      DbContextOptions<ProductsDbContext>?
        options = _provider.GetRequiredService<DbContextOptions<ProductsDbContext>>();
      ILogger<ProductsDbContext>? logger = new Mock<ILogger<ProductsDbContext>>().Object;
      IMediator? mediator = new Mock<IMediator>().Object;
      using var context = new ProductsDbContext(options, logger, mediator);
      context.Products.Add(new Product("FD0000", "SA00", "TestProduct1"));
      context.Products.Add(new Product("FD0000", "SA01", "TestProduct2"));
      context.SaveChanges();

      Context = _provider.GetRequiredService<ProductsDbContext>();
    }

    public ProductsRepositoryTests()
    {
      var mediatorMock = new Mock<IMediator>();
      var services = new ServiceCollection();
      services
        .AddLogging(builder =>
        {
          builder.AddSimpleConsole(options => options.IncludeScopes = true)
            .SetMinimumLevel(LogLevel.Trace)
            .AddDebug();
        })
        .AddSingleton(mediatorMock.Object)
        .AddEntityFrameworkInMemoryDatabase()
        .AddDbContext<ProductsDbContext>(
          builder => builder.UseInMemoryDatabase("TestDB")
            .UseInternalServiceProvider(_provider)
            .EnableSensitiveDataLogging(),
          ServiceLifetime.Singleton);

      _provider = services.BuildServiceProvider(true);
    }

    [Test]
    public void UnitOfWork_Get_ReturnProductsDbContext()
      => Assert.IsInstanceOf<ProductsDbContext>(new ProductsRepository(Context).UnitOfWork);

    [Test]
    public async Task ToListAsync_TwoItemsAreNotNull()
      => CollectionAssert.AllItemsAreNotNull(await new ProductsRepository(Context).ToListAsync());

    [TestCase("FD0000", "SA00")]
    [TestCase("FD0000", "SA01")]
    public async Task FindAsync_IsNotNull(string gpc, string lpc)
      => Assert.IsNotNull(await new ProductsRepository(Context).FindAsync(gpc, lpc));

    [TestCase("", "")]
    [TestCase("FD0000", null)]
    [TestCase(null, "SA02")]
    [TestCase("FD0000", "SA02")]
    public async Task FindAsync_IsNull(string gpc, string lpc)
      => Assert.IsNull(await new ProductsRepository(Context).FindAsync(gpc, lpc));
#nullable disable
    private readonly ServiceProvider _provider;
    private ProductsDbContext Context { get; set; }
#nullable restore
  }
}