using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using SP.Products.Api.Infrastructure;
using SP.Products.Domain.Aggregates;
using SP.Products.Domain.Aggregates.ValueTypes;
using ViennaNET.Kernel.Domain.ValueObjects;
using ViennaNET.Mediator;

namespace SP.Products.Api.Tests.Infrastructure
{
  [TestFixture(Category = "Integration", TestOf = typeof(ProductsDbContext))]
  public class ProductsDbContextTests
  {
    [OneTimeSetUp]
    public void Setup() => Context = _provider.GetRequiredService<ProductsDbContext>();

    public ProductsDbContextTests()
    {
      var mediatorMock = new Mock<IMediator>();
      var services = new ServiceCollection();
      services
        .AddLogging(builder =>
        {
          builder.AddSimpleConsole(options => options.IncludeScopes = true)
            .SetMinimumLevel(LogLevel.Trace)
            .AddDebug();
        })
        .AddSingleton(mediatorMock.Object)
        .AddEntityFrameworkInMemoryDatabase()
        .AddDbContext<ProductsDbContext>(
          builder => builder.UseInMemoryDatabase("TestDB")
            .UseInternalServiceProvider(_provider)
            .EnableSensitiveDataLogging(),
          ServiceLifetime.Singleton);

      _provider = services.BuildServiceProvider(true);
    }

    [Test(Description = "Материализует сущности для проверки сопоставлений.")]
    public void Products_IsEmpty()
    {
      var products = Context.Products.ToList();
      var customers = Context.Customers.ToList();

      Assert.Multiple(() =>
      {
        CollectionAssert.IsEmpty(products);
        CollectionAssert.IsEmpty(customers);
      });
    }

    [Test]
    [Category("Unit")]
    public void Customers_SaveAndPublishAsync_DoesNotThrow()
    {
      var product = new Product("FD0200", "SA02", "Saving Account");
      product.AddTariff(1, Currency.RUB);
      EntityEntry<Customer>? customer = Context.Customers.Add(new Customer(new CustomerNumber(123450)));
      customer.Entity.AcceptOffer(Guid.Empty, product.Offers.Single());

      Assert.DoesNotThrow(() => Context.SaveAndPublishAsync());
    }

    [Test]
    [Category("Unit")]
    public void Customers_PublishAndSaveAsync_DoesNotThrow()
    {
      var product = new Product("FD0200", "SA02", "Saving Account");
      product.AddTariff(1, Currency.RUB);
      EntityEntry<Customer>? customer = Context.Customers.Add(new Customer(new CustomerNumber(123459)));
      customer.Entity.AcceptOffer(Guid.Empty, product.Offers.Single());

      Assert.DoesNotThrow(() => Context.PublishAndSaveAsync());
    }

#nullable disable
    private readonly ServiceProvider _provider;
    private ProductsDbContext Context { get; set; }
#nullable restore
  }
}