using IdentityServer4.Models;
using IdentityServer4.Stores;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;
using SP.Identity.Api.DependencyInjection;
using SP.Identity.Api.Stores;
using IdentityServerBuilderExtensions = SP.Identity.Api.DependencyInjection.IdentityServerBuilderExtensions;

namespace SP.Identity.Api.Tests.DependencyInjection
{
  [TestFixture(Category = "Integration",
    TestOf = typeof(IdentityServerBuilderExtensions))]
  public class IdentityServerBuilderExtensionsTests
  {
    [OneTimeSetUp]
    public void Setup()
    {
      ServiceCollection.AddIdentityServer()
        .AddCustomPluggableServices()
        .AddInMemoryApiScopes(new[] {new ApiScope("Test Scope")})
        .AddInMemoryApiResources(new[] {new ApiResource("Test Resource")})
        .AddInMemoryClients(new[] {new Client {ClientName = "Test Client"}})
        .AddInMemoryIdentityResources(new[]
        {
          new IdentityResource("Test Identity resource", new[] {"Test identity resource claim"})
        });
    }

    private IServiceCollection ServiceCollection { get; }

    public IdentityServerBuilderExtensionsTests()
    {
      ServiceCollection = new ServiceCollection();
    }

    [Test]
    public void AddCustomPluggableServices()
    {
      Assert.IsInstanceOf<ReferenceTokenStore>(ServiceCollection.BuildServiceProvider()
        .GetService<IReferenceTokenStore>());
    }
  }
}