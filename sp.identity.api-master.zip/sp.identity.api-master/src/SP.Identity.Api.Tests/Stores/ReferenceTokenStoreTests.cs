using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using IdentityModel;
using IdentityServer4;
using IdentityServer4.Models;
using IdentityServer4.Services;
using IdentityServer4.Stores;
using IdentityServer4.Stores.Serialization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using SP.AspNetCore.Authentication.OnlineBank;
using SP.Identity.Api.Stores;

namespace SP.Identity.Api.Tests.Stores
{
  [TestFixture(Category = "Unit", TestOf = typeof(ReferenceTokenStore))]
  public class ReferenceTokenStoreTests
  {
    [OneTimeSetUp]
    public void Setup()
    {
      PersistentGrantSerializerMock.Setup(serializer => serializer.Deserialize<Token>(It.IsAny<string>()))
        .Returns(DefaultTestToken);

      ClientStoreMock.Setup(store => store.FindClientByIdAsync(It.IsAny<string>()))
        .Returns(Task.FromResult(new Client
        {
          ClientName = "Test client",
          ClientId = "test-client",
          ClientSecrets = new List<Secret> {new("secret".Sha256())},
          AllowedScopes = new List<string> {"test scope"}
        }));

      PersistedGrantStoreMock.Setup(store => store.GetAsync(It.IsAny<string>()))
        .Returns(Task.FromResult(new PersistedGrant
        {
          ClientId = "test-client",
          Key = DefaultTestTokenId.ToString(),
          Data = JsonConvert.SerializeObject(DefaultTestToken),
          Type = IdentityServerConstants.PersistedGrantTypes.ReferenceToken,
          SessionId = Guid.NewGuid().ToString(),
          Expiration = DateTime.Now.AddDays(1),
          SubjectId = "test-client"
        }));
    }

    public Guid DefaultTestTokenId { get; }
    public Guid TestOnlineBankTokenId { get; }
    private Token DefaultTestToken { get; }
    private Token OnlineBankToken { get; }
    private Mock<IHttpContextAccessor> HttpContextAccessorMock { get; }
    private Mock<IClientStore> ClientStoreMock { get; }
    private Mock<IPersistedGrantStore> PersistedGrantStoreMock { get; }
    private Mock<IPersistentGrantSerializer> PersistentGrantSerializerMock { get; }
    private Mock<IHandleGenerationService> HandleGenerationServiceMock { get; }
    private Mock<ILogger<ReferenceTokenStore>> LoggerMock { get; }

    public ReferenceTokenStoreTests()
    {
      DefaultTestTokenId = Guid.Empty;
      TestOnlineBankTokenId = Guid.NewGuid();
      DefaultTestToken = new Token(IdentityServerConstants.TokenTypes.AccessToken)
      {
        ClientId = "test-client",
        Claims =
          new List<Claim>
          {
            new(JwtClaimTypes.Subject, "Not online bank user"), new(JwtClaimTypes.Scope, "test scope")
          },
        Issuer = "LOCAL",
        CreationTime = DateTime.Now,
        Lifetime = (DateTime.Now - DateTime.Now.AddMinutes(2)).Seconds,
        AccessTokenType = AccessTokenType.Reference
      };
      OnlineBankToken = new Token(IdentityServerConstants.TokenTypes.AccessToken)
      {
        ClientId = "test-client",
        Claims =
          new List<Claim>
          {
            new(JwtClaimTypes.Subject, "Online bank user"), new(JwtClaimTypes.Scope, "test online bank scope")
          },
        Issuer = "online bank",
        CreationTime = DateTime.Now,
        Lifetime = (DateTime.Now - DateTime.Now.AddMinutes(2)).Seconds,
        AccessTokenType = AccessTokenType.Reference
      };
      HttpContextAccessorMock = new Mock<IHttpContextAccessor>();
      ClientStoreMock = new Mock<IClientStore>();
      PersistedGrantStoreMock = new Mock<IPersistedGrantStore>();
      PersistentGrantSerializerMock = new Mock<IPersistentGrantSerializer>();
      HandleGenerationServiceMock = new Mock<IHandleGenerationService>();
      LoggerMock = new Mock<ILogger<ReferenceTokenStore>>();
    }

    [Test]
    public async Task GetItemAsync_HttpContextIsNull_ReturnDefaultToken()
    {
      var store = new ReferenceTokenStore(PersistedGrantStoreMock.Object, PersistentGrantSerializerMock.Object,
        HandleGenerationServiceMock.Object, LoggerMock.Object, HttpContextAccessorMock.Object, ClientStoreMock.Object);

      Token? token = await store.GetReferenceTokenAsync(DefaultTestTokenId.ToString());

      Assert.AreEqual(DefaultTestToken.SubjectId, token.SubjectId);
    }

    [Test]
    public async Task GetItemAsync_UserIsNotAuthenticated_ReturnDefaultToken()
    {
      HttpContextAccessorMock.SetupGet(accessor => accessor.HttpContext).Returns(new DefaultHttpContext
      {
        User = new ClaimsPrincipal(new ClaimsIdentity())
      });
      var store = new ReferenceTokenStore(PersistedGrantStoreMock.Object, PersistentGrantSerializerMock.Object,
        HandleGenerationServiceMock.Object, LoggerMock.Object, HttpContextAccessorMock.Object, ClientStoreMock.Object);

      Token? token = await store.GetReferenceTokenAsync(DefaultTestTokenId.ToString());

      Assert.AreEqual(DefaultTestToken.SubjectId, token.SubjectId);
    }

    [Test]
    public async Task GetItemAsync_UserIsNotOnlineBankUser_ReturnDefaultToken()
    {
      HttpContextAccessorMock.SetupGet(accessor => accessor.HttpContext).Returns(new DefaultHttpContext
      {
        User = new ClaimsPrincipal(new ClaimsIdentity("Test Scheme"))
      });
      var store = new ReferenceTokenStore(PersistedGrantStoreMock.Object, PersistentGrantSerializerMock.Object,
        HandleGenerationServiceMock.Object, LoggerMock.Object, HttpContextAccessorMock.Object, ClientStoreMock.Object);

      Token? token = await store.GetReferenceTokenAsync(DefaultTestTokenId.ToString());

      Assert.AreEqual(DefaultTestToken.SubjectId, token.SubjectId);
    }

    [Test]
    public async Task GetItemAsync_ReturnOnlineBankToken()
    {
      var claims = new List<Claim>
      {
        new(JwtClaimTypes.Role, ReferenceTokenDefaults.UserRole),
        new(JwtClaimTypes.Issuer, "Test Issuer"),
        new(JwtClaimTypes.IssuedAt, DateTime.Now.ToLongTimeString()),
        new(JwtClaimTypes.Expiration, DateTime.Now.AddDays(1).ToLongTimeString()),
        new(JwtClaimTypes.Subject, "Online bank user")
      };

      HttpContextAccessorMock.SetupGet(accessor => accessor.HttpContext)
        .Returns(new DefaultHttpContext
        {
          Request =
          {
            Method = HttpMethods.Post,
            Form = new FormCollection(new Dictionary<string, StringValues> {{"client_id", "test-client"}})
          },
          User = new ClaimsPrincipal(
            new ClaimsIdentity(claims, "Test Scheme", JwtClaimTypes.Name, JwtClaimTypes.Role))
        });

      var store = new ReferenceTokenStore(PersistedGrantStoreMock.Object, PersistentGrantSerializerMock.Object,
        HandleGenerationServiceMock.Object, LoggerMock.Object, HttpContextAccessorMock.Object, ClientStoreMock.Object);

      Token? token = await store.GetReferenceTokenAsync(OnlineBankToken.ToString());

      Assert.AreEqual(OnlineBankToken.SubjectId, token.SubjectId);
    }
  }
}