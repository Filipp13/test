using System.Collections.Specialized;
using System.Threading.Tasks;
using IdentityServer4.Validation;
using Microsoft.AspNetCore.Http;
using Moq;
using NUnit.Framework;
using SP.Identity.Api.Validation;

namespace SP.Identity.Api.Tests.Validation
{
  [TestFixture(Category = "Unit", TestOf = typeof(JwtTokenGrantValidator))]
  public class JwtTokenGrantValidatorTests
  {
    private const string TestJwtToken =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9" +
      ".eyJpc3MiOiJ0b3B0YWwuY29tIiwiZXhwIjoxNDI2NDIwODAwLCJodHRwOi8vdG9wdGFsLmN" +
      "vbS9qd3RfY2xhaW1zL2lzX2FkbWluIjp0cnVlLCJjb21wYW55IjoiVG9wdGFsIiwiYXdlc29tZSI6dHJ1ZX0" +
      ".yRQYnWzskCZUxPwaQupWkiUzKELZ49eM7oWxAQK_ZXw";

    public JwtTokenGrantValidatorTests()
    {
      TokenValidatorMock = new Mock<ITokenValidator>();
      HttpContextAccessorMock = new Mock<IHttpContextAccessor>();
    }

    private Mock<ITokenValidator> TokenValidatorMock { get; }
    private Mock<IHttpContextAccessor> HttpContextAccessorMock { get; }

    [Test]
    public Task ValidateAsync()
    {
      var parameters = new NameValueCollection();
      var validator = new JwtTokenGrantValidator(TokenValidatorMock.Object, HttpContextAccessorMock.Object);

      parameters.Add("token", TestJwtToken);
      validator.ValidateAsync(new ExtensionGrantValidationContext()
      {
        Request = new ValidatedTokenRequest {ClientId = "test-client", GrantType = "obo", Raw = parameters}
      });

      return Task.CompletedTask;
    }
  }
}