using NUnit.Framework;
using SP.Identity.Api.Validation;

namespace SP.Identity.Api.Tests.Validation
{
  [TestFixture(Category = "Unit", TestOf = typeof(OneTimePasswordGrantValidator))]
  public class OneTimePasswordGrantValidatorTests
  {
  }
}