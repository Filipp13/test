using System;
using System.Security.Claims;
using IdentityModel;
using NUnit.Framework;
using SP.AspNetCore.Authentication.OnlineBank.Extensions;
using PrincipalExtensions = SP.AspNetCore.Authentication.OnlineBank.Extensions.PrincipalExtensions;

namespace SP.AspNetCore.Authentication.OnlineBank.Tests.Extensions
{
  [TestFixture(Category = "Unit",
    TestOf = typeof(PrincipalExtensions))]
  public class PrincipalExtensionsTests
  {
    private const string DefaultSubject = "123456";
    private const string DefaultExtSystemId = "123456";
    private Claim DefaultSubjectClaim { get; } = new(JwtClaimTypes.Subject, DefaultSubject);

    private Claim DefaultExtSystemIdClaim { get; } =
      new(ReferenceTokenJwtClaimTypes.ExternalSystem, DefaultExtSystemId);

    [Test(ExpectedResult = DefaultSubject)]
    public string GetSubjectId_FromClaimsIdentity_ReturnDefaultSubject()
    {
      return new ClaimsIdentity(new[] {DefaultSubjectClaim}).GetSubjectId();
    }

    [Test]
    public void GetSubjectId_FromClaimsPrincipal_ThrowInvalidOperationException()
    {
      Assert.Catch<InvalidOperationException>(() => _ = new ClaimsPrincipal(new ClaimsIdentity()).GetSubjectId());
    }

    [Test(ExpectedResult = DefaultSubject)]
    public string GetSubjectId_FromClaimsPrincipal_ReturnDefaultSubject()
    {
      return new ClaimsPrincipal(new ClaimsIdentity(new[] {DefaultSubjectClaim})).GetSubjectId();
    }

    [Test]
    public void GetSubjectId_FromClaimsIdentity_ThrowInvalidOperationException()
    {
      Assert.Catch<InvalidOperationException>(() => _ = new ClaimsIdentity().GetSubjectId());
    }

    [Test(ExpectedResult = DefaultExtSystemId)]
    public string GetExtSystemId_FromClaimsPrincipal_ReturnDefaultSubject()
    {
      return new ClaimsPrincipal(new ClaimsIdentity(new[] {DefaultExtSystemIdClaim})).GetExtSystemId();
    }

    [Test]
    public void GetExtSystemId_FromClaimsPrincipal_ThrowInvalidOperationException()
    {
      Assert.Catch<InvalidOperationException>(() => _ = new ClaimsPrincipal(new ClaimsIdentity()).GetExtSystemId());
    }

    [Test(ExpectedResult = DefaultExtSystemId)]
    public string GetExtSystemId_FromClaimsIdentity_ReturnDefaultSubject()
    {
      return new ClaimsIdentity(new[] {DefaultExtSystemIdClaim}).GetExtSystemId();
    }

    [Test]
    public void GetExtSystemId_FromClaimsIdentity_ThrowInvalidOperationException()
    {
      Assert.Catch<InvalidOperationException>(() => _ = new ClaimsIdentity().GetExtSystemId());
    }
  }
}