using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Threading.Tasks;
using IdentityModel;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Primitives;
using Microsoft.Net.Http.Headers;
using Moq;
using NUnit.Framework;
using SP.OnlineBank.Auth.HttpClient;
using SP.OnlineBank.Rcas.Contracts;
using SP.OnlineBank.Rcas.SoapClient;

#pragma warning disable 8618

namespace SP.AspNetCore.Authentication.OnlineBank.Tests
{
  [TestFixture(Category = "Unit", TestOf = typeof(ReferenceTokenHandler))]
  public class ReferenceTokenHandlerTests
  {
    [SetUp]
    public async Task Setup()
    {
      AuthServiceMock = new Mock<IAuthorizationService>();
      ProfileServiceMock = new Mock<IProfileService>();

      Host = new HostBuilder().ConfigureWebHost(builder => builder.UseTestServer()
          .Configure(app =>
          {
            app.UseAuthentication();
            app.Use(async (context, _) =>
            {
              if (context.User.Identity != null && context.User.Identity.IsAuthenticated)
              {
                await context.Response.WriteAsJsonAsync(context.User.Identity);
              }
            });
          })
          .ConfigureServices(services =>
          {
            services.AddSingleton(AuthServiceMock.Object);
            services.AddSingleton(ProfileServiceMock.Object);
            services.AddAuthentication(ReferenceTokenDefaults.AuthenticationScheme)
              .AddScheme<ReferenceTokenSchemeOptions, ReferenceTokenHandler>(
                ReferenceTokenDefaults.AuthenticationScheme, _ => { });
            services.Configure<ReferenceTokenSchemeOptions>(options =>
            {
              options.ClaimsIssuer = "http://auth";
            });
          }))
        .Build();

      await Host.StartAsync();
    }

    public ReferenceTokenHandlerTests()
    {
      DefaultIntrospectionResponse = new ROnlineIntrospectionResponse
      {
        AccessToken = DefaultAccessToken.ToString(),
        Expiration = DateTimeOffset.Now.AddSeconds(100),
        IssuedAt = DateTimeOffset.Now,
        CustomerNumber = "123456",
        Owner = new ResourceOwner
        {
          CustomerNumber = 123456,
          Branch = 123,
          Compliance = false,
          IsResident = true,
          FirstName = "test_first_name",
          LastName = "test_last_name",
          Patronymic = "test_patronymic",
          PassportNumber = "0000 123456",
          PassportIssuer = "test_passport_issuer",
          FullName = "test_first_name test_last_name test_patronymic",
          PassportIssueAt = DateTime.Now,
          BirthDate = DateTime.Now,
          EmployerNumber = 12345,
          IndividualTaxpayerNumber = "1234567890"
        }
      };
    }

    private IHost Host { get; set; }
    private Mock<IAuthorizationService> AuthServiceMock { get; set; }
    private Mock<IProfileService> ProfileServiceMock { get; set; }
    private ROnlineIntrospectionResponse DefaultIntrospectionResponse { get; }
    private Guid DefaultAccessToken { get; } = Guid.NewGuid();

    [Test]
    public async Task HandleAuthenticateAsync_NotAuthHeader_AuthenticateResult_NoResult()
    {
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(_ => { });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task HandleAuthenticateAsync_NotFoundAuthHeaderPrefix_AuthenticateResult_NoResult()
    {
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(context =>
      {
        context.Request.Headers.Add(HeaderNames.Authorization, Guid.NewGuid().ToString());
      });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task HandleAuthenticateAsync_AuthHeaderContainsDot_AuthenticateResult_NoResult()
    {
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(context =>
      {
        context.Request.Headers.Add(HeaderNames.Authorization, "#JHKS2313DF.@98DSAV#382");
      });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task HandleAuthenticateAsync_AuthHeaderNotContainsDot_AuthenticateResult_Fail()
    {
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.Headers.Add(HeaderNames.Authorization, $"Bearer {Guid.NewGuid()}");
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task HandleAuthenticateAsync_GetTokenFromHeader_ReturnSuccess()
    {
      AuthServiceMock.Setup(service => service.Introspection(It.IsAny<string>()))
        .Returns(() => Task.FromResult<ROnlineIntrospectionResponse?>(DefaultIntrospectionResponse));
      ProfileServiceMock.Setup(service =>
          service.GetCustomerAuthDevicesAsync(It.IsAny<CustomerAuthDevicesRequestBody>()))
        .Returns(() => Task.FromResult(new[] {"SMSOTP"}));

      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.Method = HttpMethods.Get;
        context.Request.Headers.Add(HeaderNames.Authorization, $"Bearer {DefaultAccessToken}");
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        Assert.AreEqual("123456", httpContext.User.FindFirstValue(JwtClaimTypes.Subject));
        Assert.AreEqual("online bank authorization service",
          httpContext.User.FindFirstValue(JwtClaimTypes.IdentityProvider));
        Assert.AreEqual("test_first_name test_last_name test_patronymic",
          httpContext.User.FindFirstValue(JwtClaimTypes.Name));
        Assert.AreEqual("test_first_name", httpContext.User.FindFirstValue(JwtClaimTypes.GivenName));
        Assert.AreEqual("test_last_name", httpContext.User.FindFirstValue(JwtClaimTypes.FamilyName));
        Assert.AreEqual("test_patronymic", httpContext.User.FindFirstValue(JwtClaimTypes.MiddleName));
        Assert.AreEqual(DateTime.Now.ToString("dd-MM-yyyy"), httpContext.User.FindFirstValue(JwtClaimTypes.BirthDate));
        Assert.AreEqual("0000 123456", httpContext.User.FindFirstValue(ReferenceTokenJwtClaimTypes.IdentityCardNumber));
        Assert.AreEqual("test_passport_issuer",
          httpContext.User.FindFirstValue(ReferenceTokenJwtClaimTypes.IdentityCardIssuer));
        Assert.AreEqual(DateTime.Now.ToString("dd-MM-yyyy"),
          httpContext.User.FindFirstValue(ReferenceTokenJwtClaimTypes.IdentityCardIssueAt));
        Assert.AreEqual("12345", httpContext.User.FindFirstValue(ReferenceTokenJwtClaimTypes.EmployerNumber));
        Assert.AreEqual("1234567890",
          httpContext.User.FindFirstValue(ReferenceTokenJwtClaimTypes.IndividualTaxpayerNumber));
        Assert.AreEqual(
          httpContext.User.FindFirstValue(ReferenceTokenJwtClaimTypes.ConfirmationMethods), "SMSOTP");
      });
    }

    [Test]
    public async Task HandleAuthenticateAsync_GetTokenFromForm_ReturnSuccess()
    {
      AuthServiceMock.Setup(service => service.Introspection(It.IsAny<string>()))
        .Returns(() => Task.FromResult<ROnlineIntrospectionResponse?>(DefaultIntrospectionResponse));
      ProfileServiceMock.Setup(service =>
          service.GetCustomerAuthDevicesAsync(It.IsAny<CustomerAuthDevicesRequestBody>()))
        .Returns(() => Task.FromResult(new[] {"SMSOTP"}));

      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.Method = HttpMethods.Post;
        context.Request.Form = new FormCollection(new Dictionary<string, StringValues>
        {
          {"token", DefaultAccessToken.ToString()}
        });
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        Assert.AreEqual("123456", httpContext.User.FindFirstValue(JwtClaimTypes.Subject));
        Assert.AreEqual("online bank authorization service",
          httpContext.User.FindFirstValue(JwtClaimTypes.IdentityProvider));
        Assert.AreEqual("test_first_name test_last_name test_patronymic",
          httpContext.User.FindFirstValue(JwtClaimTypes.Name));
        Assert.AreEqual("test_first_name", httpContext.User.FindFirstValue(JwtClaimTypes.GivenName));
        Assert.AreEqual("test_last_name", httpContext.User.FindFirstValue(JwtClaimTypes.FamilyName));
        Assert.AreEqual("test_patronymic", httpContext.User.FindFirstValue(JwtClaimTypes.MiddleName));
        Assert.AreEqual(DateTime.Now.ToString("dd-MM-yyyy"), httpContext.User.FindFirstValue(JwtClaimTypes.BirthDate));
        Assert.AreEqual("0000 123456", httpContext.User.FindFirstValue(ReferenceTokenJwtClaimTypes.IdentityCardNumber));
        Assert.AreEqual("test_passport_issuer",
          httpContext.User.FindFirstValue(ReferenceTokenJwtClaimTypes.IdentityCardIssuer));
        Assert.AreEqual(DateTime.Now.ToString("dd-MM-yyyy"),
          httpContext.User.FindFirstValue(ReferenceTokenJwtClaimTypes.IdentityCardIssueAt));
        Assert.AreEqual("12345", httpContext.User.FindFirstValue(ReferenceTokenJwtClaimTypes.EmployerNumber));
        Assert.AreEqual("1234567890",
          httpContext.User.FindFirstValue(ReferenceTokenJwtClaimTypes.IndividualTaxpayerNumber));
        Assert.AreEqual(
          httpContext.User.FindFirstValue(ReferenceTokenJwtClaimTypes.ConfirmationMethods), "SMSOTP");
      });
    }

    [Test]
    public async Task HandleAuthenticateAsync_ReturnFail_Because_IntrospectionFail()
    {
      AuthServiceMock.Setup(service => service.Introspection(It.IsAny<string>()))
        .Returns(() => Task.FromResult<ROnlineIntrospectionResponse?>(new ROnlineIntrospectionResponse
        {
          AccessToken = DefaultAccessToken.ToString(),
          Expiration = DateTimeOffset.Now.AddMinutes(4),
          IssuedAt = DateTimeOffset.Now,
          CustomerNumber = string.Empty
        }));
      ProfileServiceMock.Setup(service =>
          service.GetCustomerAuthDevicesAsync(It.IsAny<CustomerAuthDevicesRequestBody>()))
        .Returns(() => Task.FromResult(new[] {"SMSOTP"}));

      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
        context.Request.Headers.Add(HeaderNames.Authorization, $"Bearer {DefaultAccessToken}"));

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task HandleAuthenticateAsync_ReturnFail_Because_IntrospectionResponseIsNull()
    {
      AuthServiceMock.Setup(service => service.Introspection(It.IsAny<string>()))
        .Returns(() => Task.FromResult<ROnlineIntrospectionResponse?>(null));

      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
        context.Request.Headers.Add(HeaderNames.Authorization, $"Bearer {DefaultAccessToken}"));

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task HandleAuthenticateAsync_ReturnFail_Because_BadRequest()
    {
      AuthServiceMock.Setup(service => service.Introspection(It.IsAny<string>()))
        .Throws(new HttpRequestException("Invalid request", null, HttpStatusCode.BadRequest));

      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
        context.Request.Headers.Add(HeaderNames.Authorization, $"Bearer {DefaultAccessToken}"));

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task HandleAuthenticateAsync_ReturnFail_Because_RetrieveAuthDevicesFail()
    {
      AuthServiceMock.Setup(service => service.Introspection(It.IsAny<string>()))
        .Returns(() => Task.FromResult<ROnlineIntrospectionResponse?>(DefaultIntrospectionResponse));
      ProfileServiceMock.Setup(service =>
          service.GetCustomerAuthDevicesAsync(It.IsAny<CustomerAuthDevicesRequestBody>()))
        .Returns(() => Task.FromResult(Array.Empty<string>()));

      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
        context.Request.Headers.Add(HeaderNames.Authorization, $"Bearer {DefaultAccessToken}"));

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }
  }
}