﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using IdentityModel;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Primitives;
using Moq;
using NUnit.Framework;
using SP.OnlineBank.Rcas.Contracts;
using SP.OnlineBank.Rcas.Contracts.Authentication;
using SP.OnlineBank.Rcas.SoapClient;

#pragma warning disable 8618

namespace SP.AspNetCore.Authentication.OneTimePassword.Tests
{
  public class OneTimePasswordHandlerTests
  {
    private IHost Host { get; set; }
    private Mock<IProfileService> ProfileServiceMock { get; set; }
    private Mock<IAuthenticationService> AuthenticationServiceMock { get; set; }

    [SetUp]
    public async Task Setup()
    {
      AuthenticationServiceMock = new Mock<IAuthenticationService>();
      ProfileServiceMock = new Mock<IProfileService>();

      Host = new HostBuilder().ConfigureWebHost(builder => builder.UseTestServer()
          .Configure(app =>
          {
            app.UseAuthentication();
            app.Use(async (context, _) =>
            {
              if (context.User.Identity != null && context.User.Identity.IsAuthenticated)
              {
                await context.Response.WriteAsJsonAsync(context.User.Identity);
              }
            });
          })
          .ConfigureServices(services =>
          {
            services.AddSingleton(ProfileServiceMock.Object);
            services.AddSingleton(AuthenticationServiceMock.Object);
            services.AddAuthentication(OneTimePasswordDefaults.AuthenticationScheme)
              .AddScheme<OneTimePasswordSchemeOptions, OneTimePasswordHandler>(
                OneTimePasswordDefaults.AuthenticationScheme, _ => { });
          }))
        .Build();

      await Host.StartAsync();
    }


    [Test]
    public async Task HandleAuthenticateAsync_NotFormContentType_AuthenticateResult_NoResult()
    {
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(_ => { });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task HandleAuthenticateAsync_ConfirmationMethodNotFound_AuthenticateResult_NoResult()
    {
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
      });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task HandleAuthenticateAsync_UserNameNotFound_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues> {{"confirmation_method", "PUSHOTP"}};
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task HandleAuthenticateAsync_OperationTypeIdNotFound_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues> {{"confirmation_method", "PUSHOTP"}, {"username", "123456"}};
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task HandleAuthenticateAsync_RequestIdNotFound_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"}, {"username", "123456"}, {"operation_type_id", "TEST_TYPE"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task HandleAuthenticateAsync_ConfirmationMethodIsNull_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues> {{"confirmation_method", StringValues.Empty}};
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task HandleAuthenticateAsync_UserNameIsNull_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"}, {"username", StringValues.Empty}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task HandleAuthenticateAsync_OperationTypeIdIsNull_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"}, {"username", "123456"}, {"operation_type_id", StringValues.Empty}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task HandleAuthenticateAsync_RequestIdIsNull_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", StringValues.Empty}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task HandleAuthenticateAsync_NotSupportedConfirmationMethod_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "NOTSUPPORTETOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task SendPush_PushIdNotFound_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task SendPush_PushIdIsNull_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"push_id", StringValues.Empty},
        {"amount", "default"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? response = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.AreEqual((int)HttpStatusCode.OK, response.Response.StatusCode);
    }

    [Test]
    public async Task SendPush_AppIdIsEmptyString_AuthenticateResult_Fail()
    {
      ProfileServiceMock
        .Setup(service => service.GetApplicationIdAsync(It.IsAny<AppByPushIdRequestBody>()))
        .ReturnsAsync(() => string.Empty);

      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"push_id", "12345"},
        {"amount", 100M.ToString(CultureInfo.InvariantCulture)},
        {"external_system", "RC"},
        {"outer.testcode", "test-arg"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });


      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task SendPush_RcasIdIsNull_AuthenticateResult_Fail()
    {
      ProfileServiceMock
        .Setup(service => service.GetApplicationIdAsync(It.IsAny<AppByPushIdRequestBody>()))
        .ReturnsAsync(() => "12345");

      AuthenticationServiceMock
        .Setup(service => service.SendPushOTPAsync(It.IsAny<SendPushOTPRequestBody>()))
        .ReturnsAsync(() => null);

      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"push_id", "12345"},
        {"outer.testcode", "test-arg"},
        {"outer.testnumber", "1"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task SendPush_AuthenticateResult_Success()
    {
      ProfileServiceMock
        .Setup(service => service.GetApplicationIdAsync(It.IsAny<AppByPushIdRequestBody>()))
        .ReturnsAsync(() => "12345");

      AuthenticationServiceMock
        .Setup(service => service.SendPushOTPAsync(It.IsAny<SendPushOTPRequestBody>()))
        .ReturnsAsync(() => 1234);

      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"push_id", "12345"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        Assert.AreEqual("123456", httpContext.User.FindFirstValue(JwtClaimTypes.Subject));
        Assert.AreEqual("1234", httpContext.User.FindFirstValue(OtpJwtClaimTypes.RcasId));
        Assert.AreEqual("12345", httpContext.User.FindFirstValue(OtpJwtClaimTypes.RcasAppId));
        Assert.AreEqual("PUSHOTP", httpContext.User.FindFirstValue(OtpJwtClaimTypes.ConfirmationMethod));
      });
    }

    [Test]
    public async Task SendSms_RcasIdIsNull_AuthenticateResult_Fail()
    {
      AuthenticationServiceMock
        .Setup(service => service.SendPushOTPAsync(It.IsAny<SendPushOTPRequestBody>()))
        .ReturnsAsync(() => null);

      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "SMSOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"amount", "12345"},
        {"outer.testcode", "test-arg"},
        {"outer.testnumber", "1"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task SendSms_AuthenticateResult_Success()
    {
      AuthenticationServiceMock
        .Setup(service => service.SendSmsOtpAsync(It.IsAny<SendSmsOTPRequestBody>()))
        .ReturnsAsync(() => 1234);

      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "SMSOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"amount", "12345"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        Assert.AreEqual("123456", httpContext.User.FindFirstValue(JwtClaimTypes.Subject));
        Assert.AreEqual("1234", httpContext.User.FindFirstValue(OtpJwtClaimTypes.RcasId));
        Assert.AreEqual("SMSOTP", httpContext.User.FindFirstValue(OtpJwtClaimTypes.ConfirmationMethod));
      });
    }

    [Test]
    public async Task ValidatePushCode_RcasIdIsInvalid_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "invalid rcas id"},
        {"amount", "12345"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task ValidatePushCode_RcasAppIdNotFound_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "1111"},
        {"amount", "12345"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task ValidatePushCode_RcasAppIdIsEmpty_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_app_id", StringValues.Empty},
        {"rcas_id", "1111"},
        {"amount", "12345"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task ValidatePushCode_OneTimePasswordNotFound_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "1111"},
        {"rcas_app_id", "123"},
        {"amount", "12345"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task ValidatePushCode_OneTimePasswordIsNotLong_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "1111"},
        {"rcas_app_id", "123"},
        {"otp", "invalid otp"},
        {"amount", "12345"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task ValidatePushCode_RcasSignedDocumentNotFound_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "1111"},
        {"rcas_app_id", "123"},
        {"amount", "12345"},
        {"otp", "1234"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task ValidatePushCode_RcasSignedDocumentIsEmpty_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "1111"},
        {"rcas_app_id", "123"},
        {"amount", "12345"},
        {"otp", "1234"},
        {"rcas_signed_document", StringValues.Empty}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task ValidatePushCode_OtpIsNotVerified_AuthenticateResult_Fail()
    {
      AuthenticationServiceMock
        .Setup(service => service.VerifyPushOTPAsync(It.IsAny<VerifyPushOTPRequestBody>()))
        .ReturnsAsync(() => false);

      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "1111"},
        {"rcas_app_id", "123"},
        {"amount", "12345"},
        {"otp", "1234"},
        {"rcas_signed_document", "test rcas signed document {otp}"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task ValidatePushCode_OtpIsVerified_AuthenticateResult_Success()
    {
      AuthenticationServiceMock
        .Setup(service => service.VerifyPushOTPAsync(It.IsAny<VerifyPushOTPRequestBody>()))
        .ReturnsAsync(() => true);

      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "PUSHOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "1111"},
        {"rcas_app_id", "123"},
        {"amount", "12345"},
        {"otp", "1234"},
        {"rcas_signed_document", "test rcas signed document {otp}"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });


      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        Assert.AreEqual("123456", httpContext.User.FindFirstValue(JwtClaimTypes.Subject));
        Assert.AreEqual("PUSHOTP", httpContext.User.FindFirstValue(OtpJwtClaimTypes.ConfirmationMethod));
        Assert.AreEqual("otp", httpContext.User.FindFirstValue(JwtClaimTypes.AuthenticationMethod));
        Assert.AreEqual("operations.signed", httpContext.User.FindFirstValue(JwtClaimTypes.Scope));
        Assert.AreEqual("test rcas signed document 1234",
          httpContext.User.FindFirstValue(OtpJwtClaimTypes.RcasSignedDocument));
        Assert.AreEqual(DateTime.Now.ToString(CultureInfo.InvariantCulture),
          httpContext.User.FindFirstValue(OtpJwtClaimTypes.RcasDocumentSignOn));
      });
    }

    [Test]
    public async Task ValidateSmsCode_RcasIdIsInvalid_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "SMSOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "invalid rcas id"},
        {"amount", "12345"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }


    [Test]
    public async Task ValidateSmsCode_OneTimePasswordNotFound_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "SMSOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "1111"},
        {"amount", "12345"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task ValidateSmsCode_OneTimePasswordIsNotLong_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "SMSOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "1111"},
        {"otp", "invalid otp"},
        {"amount", "12345"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task ValidateSmsCode_RcasSignedDocumentNotFound_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "SMSOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "1111"},
        {"amount", "12345"},
        {"otp", "1234"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task ValidateSmsCode_RcasSignedDocumentIsEmpty_AuthenticateResult_NoResult()
    {
      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "SMSOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "1111"},
        {"amount", "12345"},
        {"otp", "1234"},
        {"rcas_signed_document", StringValues.Empty}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task ValidateSmsCode_OtpIsNotVerified_AuthenticateResult_Fail()
    {
      AuthenticationServiceMock
        .Setup(service => service.VerifySmsOtpAsync(It.IsAny<VerifySmsOTPRequestBody>()))
        .ReturnsAsync(() => false);

      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "SMSOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "1111"},
        {"amount", "12345"},
        {"otp", "1234"},
        {"rcas_signed_document", "test rcas signed document {otp}"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });

      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        CollectionAssert.IsEmpty(httpContext.User.Claims);
      });
    }

    [Test]
    public async Task ValidateSmsCode_OtpIsVerified_AuthenticateResult_Success()
    {
      AuthenticationServiceMock
        .Setup(service => service.VerifySmsOtpAsync(It.IsAny<VerifySmsOTPRequestBody>()))
        .ReturnsAsync(() => true);

      var form = new Dictionary<string, StringValues>
      {
        {"confirmation_method", "SMSOTP"},
        {"username", "123456"},
        {"operation_type_id", "TEST_TYPE"},
        {"request_id", "1234567"},
        {"rcas_id", "1111"},
        {"amount", "12345"},
        {"otp", "1234"},
        {"rcas_signed_document", "test rcas signed document {otp}"}
      };
      TestServer? server = Host.GetTestServer();
      HttpContext? httpContext = await server.SendAsync(context =>
      {
        context.Request.ContentType = "application/x-www-form-urlencoded";
        context.Request.Form = new FormCollection(form);
      });


      Assert.Multiple(() =>
      {
        Assert.AreEqual((int)HttpStatusCode.OK, httpContext.Response.StatusCode);
        Assert.AreEqual("123456", httpContext.User.FindFirstValue(JwtClaimTypes.Subject));
        Assert.AreEqual("SMSOTP", httpContext.User.FindFirstValue(OtpJwtClaimTypes.ConfirmationMethod));
        Assert.AreEqual("otp", httpContext.User.FindFirstValue(JwtClaimTypes.AuthenticationMethod));
        Assert.AreEqual("operations.signed", httpContext.User.FindFirstValue(JwtClaimTypes.Scope));
        Assert.AreEqual("test rcas signed document 1234",
          httpContext.User.FindFirstValue(OtpJwtClaimTypes.RcasSignedDocument));
        Assert.AreEqual(DateTime.Now.ToString(CultureInfo.InvariantCulture),
          httpContext.User.FindFirstValue(OtpJwtClaimTypes.RcasDocumentSignOn));
      });
    }
  }
}