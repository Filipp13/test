using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SP.AspNetCore.Authentication.OneTimePassword;
using SP.AspNetCore.Authentication.OnlineBank;
using SP.Identity.Api.DependencyInjection;
using SP.Identity.Api.Validation;
using SP.OnlineBank.Auth.HttpClient.DependencyInjection;
using SP.OnlineBank.Rcas.SoapClient.DependencyInjection;
using ViennaNET.Metrics;

namespace SP.Identity.Api
{
  [ExcludeFromCodeCoverage]
  public class Startup
  {
    public Startup(IConfiguration configuration, IWebHostEnvironment environment)
    {
      Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
      Environment = environment;
    }

    private IConfiguration Configuration { get; }
    private IWebHostEnvironment Environment { get; }

    public void ConfigureServices(IServiceCollection services)
    {
      services.AddPrometheusMetrics(Configuration);
      services
        .AddRcasAuthenticationServiceClient(Configuration)
        .AddRcasProfileServiceClient(Configuration)
        .AddOnlineBankAuthorizationHttpClient(Configuration);

      IIdentityServerBuilder? identityServerBuilder = services.AddIdentityServer()
        .AddCustomPluggableServices()
        .AddExtensionGrantValidator<OneTimePasswordGrantValidator>()
        .AddExtensionGrantValidator<JwtTokenGrantValidator>()
        .AddInMemoryApiScopes(Configuration.GetSection("IdentityServer:ApiScopes"))
        .AddInMemoryApiResources(Configuration.GetSection("IdentityServer:ApiResources"))
        .AddInMemoryClients(Configuration.GetSection("IdentityServer:Clients"))
        .AddInMemoryIdentityResources(Configuration.GetSection("IdentityServer:IdentityResources"));

      services.AddHealthChecks();
      services.AddAuthentication(ReferenceTokenDefaults.AuthenticationScheme)
        .AddScheme<ReferenceTokenSchemeOptions, ReferenceTokenHandler>(
          ReferenceTokenDefaults.AuthenticationScheme,
          options => Configuration.Bind(ReferenceTokenSchemeOptions.ConfigurationSection, options))
        .AddScheme<OneTimePasswordSchemeOptions, OneTimePasswordHandler>(
          OneTimePasswordDefaults.AuthenticationScheme,
          options => Configuration.Bind(OneTimePasswordSchemeOptions.ConfigurationSection, options));

      services.AddCors(options =>
      {
        options.AddPolicy("CorsPolicy", builder => builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
      });

      identityServerBuilder.AddDeveloperSigningCredential(false);
    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
      if (env.IsDevelopment())
      {
        app.UseDeveloperExceptionPage();
      }

      app.UseRouting()
        .UseIdentityServer()
        .UseCors("CorsPolicy")
        .UseEndpoints(endpoints =>
        {
          endpoints.MapHealthChecks("/health");
        });
    }
  }
}