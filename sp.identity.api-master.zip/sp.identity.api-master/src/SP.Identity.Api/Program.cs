using System.Diagnostics.CodeAnalysis;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;

namespace SP.Identity.Api
{
  [ExcludeFromCodeCoverage]
  internal static class Program
  {
    public static Task Main(string[] args)
    {
      return CreateHostBuilder(args).Build().RunAsync();
    }

    private static IHostBuilder CreateHostBuilder(string[] args)
    {
      IHostBuilder? builder = Host.CreateDefaultBuilder(args);

      if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
      {
        builder.UseWindowsService();
        builder.ConfigureAppConfiguration(configurationBuilder =>
          configurationBuilder.AddEnvironmentVariables("IDENTITY_"));
      }

      return builder.ConfigureWebHostDefaults(webBuilder =>
      {
        webBuilder.UseStartup<Startup>();
      });
    }
  }
}