using System.Threading.Tasks;
using IdentityServer4.Models;
using IdentityServer4.Validation;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using SP.AspNetCore.Authentication.OnlineBank;

namespace SP.Identity.Api.Validation
{
  /// <summary>
  ///   Раширение позволяет запрашивать токены доступа по потоку On-Behalf-Of (от имени).
  ///   <remarks>
  ///     Когда есть необходимость из Api среднего уровня вызвать Api более низкого уровня,
  ///     используйте полученный ранее токен доступа для получения нового токена с объявленой областью.
  ///   </remarks>
  /// </summary>
  internal class JwtTokenGrantValidator : IExtensionGrantValidator
  {
    public JwtTokenGrantValidator(ITokenValidator validator, IHttpContextAccessor httpContextAccessor)
    {
      Validator = validator;
      HttpContextAccessor = httpContextAccessor;
    }

    private ITokenValidator Validator { get; }
    private IHttpContextAccessor HttpContextAccessor { get; }

    /// <inheritdoc />
    public async Task ValidateAsync(ExtensionGrantValidationContext context)
    {
      var userToken = context.Request.Raw.Get("token");

      if (string.IsNullOrEmpty(userToken))
      {
        context.Result = new GrantValidationResult(TokenRequestErrors.InvalidGrant);
        return;
      }

      TokenValidationResult result = await Validator.ValidateAccessTokenAsync(userToken);

      if (result.IsError)
      {
        context.Result = new GrantValidationResult(TokenRequestErrors.InvalidGrant);
        return;
      }

      if (HttpContextAccessor.HttpContext != null)
      {
        await HttpContextAccessor.HttpContext.AuthenticateAsync(ReferenceTokenDefaults.AuthenticationScheme);
        context.Result = new GrantValidationResult(HttpContextAccessor.HttpContext.User);
      }
    }

    /// <summary>
    ///   Получает тип разрешения. По умолчанию равно On-Behalf-Of (от имени).
    /// </summary>
    /// <remarks>Позволяет делегировать вызовы к API более низкого уровня.</remarks>
    public string GrantType { get; } = "obo";
  }
}