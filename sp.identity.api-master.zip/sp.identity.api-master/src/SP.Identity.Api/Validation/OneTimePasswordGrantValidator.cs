using System.Threading.Tasks;
using IdentityServer4.Models;
using IdentityServer4.Validation;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using SP.AspNetCore.Authentication.OneTimePassword;

namespace SP.Identity.Api.Validation
{
  /// <summary>
  ///   Обрабатывает проверку запросов токенов с использованием OTP типа гранта.
  /// </summary>
  internal class OneTimePasswordGrantValidator : IExtensionGrantValidator
  {
    public OneTimePasswordGrantValidator(IHttpContextAccessor httpContextAccessor)
    {
      HttpContextAccessor = httpContextAccessor;
    }

    private IHttpContextAccessor HttpContextAccessor { get; }

    public string GrantType { get; } = "otp";

    /// <inheritdoc />
    public async Task ValidateAsync(ExtensionGrantValidationContext context)
    {
      var method = context.Request.Raw.Get("confirmation_method");

      if (string.IsNullOrEmpty(method))
      {
        context.Result = new GrantValidationResult(TokenRequestErrors.InvalidRequest);
      }

      if (HttpContextAccessor.HttpContext != null)
      {
        AuthenticateResult result =
          await HttpContextAccessor.HttpContext.AuthenticateAsync(OneTimePasswordDefaults.AuthenticationScheme);
        context.Result = new GrantValidationResult(result.Principal);
      }
    }
  }
}