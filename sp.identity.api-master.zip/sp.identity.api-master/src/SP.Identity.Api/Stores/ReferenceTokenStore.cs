using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using IdentityModel;
using IdentityServer4.Extensions;
using IdentityServer4.Models;
using IdentityServer4.Services;
using IdentityServer4.Stores;
using IdentityServer4.Stores.Serialization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SP.AspNetCore.Authentication.OnlineBank;

namespace SP.Identity.Api.Stores
{
  internal class ReferenceTokenStore : DefaultReferenceTokenStore
  {
    public ReferenceTokenStore(
      IPersistedGrantStore store,
      IPersistentGrantSerializer serializer,
      IHandleGenerationService handleGenerationService,
      ILogger<ReferenceTokenStore> logger,
      IHttpContextAccessor httpContextAccessor,
      IClientStore clientStore) : base(store, serializer, handleGenerationService, logger)
    {
      HttpContextAccessor = httpContextAccessor;
      ClientStore = clientStore;
    }

    private IHttpContextAccessor HttpContextAccessor { get; }
    private IClientStore ClientStore { get; }

    protected override async Task<Token> GetItemAsync(string key)
    {
      if (HttpContextAccessor.HttpContext == null ||
          !HttpContextAccessor.HttpContext.User.IsAuthenticated() ||
          !HttpContextAccessor.HttpContext.User.IsInRole(ReferenceTokenDefaults.UserRole))
      {
        return await base.GetItemAsync(key);
      }

      ClaimsPrincipal user = HttpContextAccessor.HttpContext.User;
      var clientId = HttpContextAccessor.HttpContext.Request.Form["client_id"].ToString();
      Client? client = await ClientStore.FindClientByIdAsync(clientId);
      var issuer = user.FindFirstValue(JwtClaimTypes.Issuer);
      var issuedAt = user.FindFirstValue(JwtClaimTypes.IssuedAt);
      var expiration = user.FindFirstValue(JwtClaimTypes.Expiration);
      IEnumerable<Claim> clientScopes = client.AllowedScopes.Select(scope => new Claim(JwtClaimTypes.Scope, scope));
      var token = new Token
      {
        AccessTokenType = AccessTokenType.Reference,
        Issuer = issuer,
        CreationTime = DateTime.Parse(issuedAt),
        ClientId = clientId,
        Audiences = new[] {clientId},
        Claims = user.Claims.Concat(clientScopes).ToList(),
        Lifetime = (int)(DateTime.Parse(expiration) - DateTime.Parse(issuedAt)).TotalSeconds
      };

      return token;
    }
  }
}