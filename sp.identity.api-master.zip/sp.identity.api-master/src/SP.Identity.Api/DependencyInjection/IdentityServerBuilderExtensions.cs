using IdentityServer4.Stores;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using SP.Identity.Api.Stores;

namespace SP.Identity.Api.DependencyInjection
{
  /// <summary>
  ///   Метод расширения <see cref="IIdentityServerBuilder" /> для регистрации служб.
  /// </summary>
  internal static class IdentityServerBuilderExtensions
  {
    /// <summary>
    ///   Добавляет подключаемые службы.
    /// </summary>
    /// <param name="builder">Ссылка на объект <see cref="IIdentityServerBuilder" />.</param>
    /// <returns>Ссылка на объект <see cref="IIdentityServerBuilder" />.</returns>
    public static IIdentityServerBuilder AddCustomPluggableServices(this IIdentityServerBuilder builder)
    {
      var descriptor = new ServiceDescriptor(
        typeof(IReferenceTokenStore),
        typeof(ReferenceTokenStore),
        ServiceLifetime.Transient);

      builder.Services.Replace(descriptor);

      return builder;
    }
  }
}