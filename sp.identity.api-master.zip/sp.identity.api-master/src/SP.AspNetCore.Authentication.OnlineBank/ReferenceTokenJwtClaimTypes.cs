namespace SP.AspNetCore.Authentication.OnlineBank
{
  /// <summary>
  ///   Представляет набор имён утверждений используемых для интеграции с онлайн банком.
  /// </summary>
  public static class ReferenceTokenJwtClaimTypes
  {
    /// <summary>
    ///   Представляет наименование утвержения о токене доступа выданном клиенту пользователя службой авторизации онлайн банка.
    /// </summary>
    public const string ReferenceToken = "onlinebank_reference_token";

    /// <summary>
    ///   Представляет наименование утвержения о доступных клиенту способах подтверждения операций в онлайн банке.
    /// </summary>
    public const string ConfirmationMethods = "confirmation_methods";

    /// <summary>
    ///   Представляет наименование утверждения о номере удостоверения личности пользователя.
    /// </summary>
    public const string IdentityCardNumber = "identity_card_number";

    /// <summary>
    ///   Представляет наименование утверждения об органе, выпустившем удостоверение личности пользователя.
    /// </summary>
    public const string IdentityCardIssuer = "identity_card_issuer";

    /// <summary>
    ///   Представляет наименование утверждения о дате выпуска удостоверения личности пользователя.
    /// </summary>
    public const string IdentityCardIssueAt = "identity_card_issuer_at";

    /// <summary>
    ///   Представляет наименование утверждения о признаке резидентства пользователя.
    /// </summary>
    public const string ResidentStatus = "resident_status";

    /// <summary>
    ///   Представляет наименование утверждения о признаке работы с пользователем по линии Сompliance.
    /// </summary>
    public const string ComplianceStatus = "compliance_status";

    /// <summary>
    ///   Представляет наименование утверждения о идентификационном номере налогоплательщика ФЛ (ИНН = ITN).
    /// </summary>
    public const string IndividualTaxpayerNumber = "individual_taxpayer_number";

    /// <summary>
    ///   Представляет наименование утверждения о идентификаторе отделения в котором обслуживается пользователь онлайн банка.
    /// </summary>
    public const string Branch = "branch";

    /// <summary>
    ///   Представляет наименование утверждения о идентификаторе компании - зарплатного клиента, пользователя онлайн банка.
    /// </summary>
    public const string EmployerNumber = "employer_number";

    /// <summary>
    ///   Представляет наименование утверждения о системе, внешней, по отношению к службам аутентификации и авторизации онлайн
    ///   банка.
    /// </summary>
    public const string ExternalSystem = "external_system";
  }
}