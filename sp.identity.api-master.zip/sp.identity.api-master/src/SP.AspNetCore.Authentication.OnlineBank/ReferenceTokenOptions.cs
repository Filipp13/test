﻿using Microsoft.AspNetCore.Authentication;

namespace SP.AspNetCore.Authentication.OnlineBank
{
  /// <summary>
  ///   Класс параметров предоставляет информацию, необходимую для управления поведением обработчика согласованной
  ///   аутентификации.
  /// </summary>
  public class ReferenceTokenSchemeOptions : AuthenticationSchemeOptions
  {
    /// <summary>
    ///   Получает наименование секции конфигурации.
    /// </summary>
    public const string ConfigurationSection = "Authentication:ReferenceToken";
  }
}