using IdentityModel;

namespace SP.AspNetCore.Authentication.OnlineBank
{
  /// <summary>
  ///   Значения по умолчанию, используемые при проверке подлинности с помощью службы авторизации и токена доступа онлайн
  ///   банка.
  /// </summary>
  public static class ReferenceTokenDefaults
  {
    /// <summary>
    ///   Значение по умолчанию для AuthenticationScheme, используемое для идентификации обработчика аутентификации OnlineBank.
    /// </summary>
    public const string AuthenticationScheme = "OnlineBank";

    /// <summary>
    ///   Значение по умолчанию для <see cref="JwtClaimTypes.Role" /> типа утверждения.
    /// </summary>
    public const string UserRole = "OnlineBankUser";
  }
}