using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("SP.AspNetCore.Authentication.OnlineBank.Tests")]