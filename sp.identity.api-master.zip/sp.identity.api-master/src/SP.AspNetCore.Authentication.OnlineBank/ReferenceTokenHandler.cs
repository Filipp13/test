using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using IdentityModel;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;
using Microsoft.Net.Http.Headers;
using SP.AspNetCore.Authentication.OnlineBank.Extensions;
using SP.OnlineBank.Auth.HttpClient;
using SP.OnlineBank.Rcas.Contracts;
using SP.OnlineBank.Rcas.SoapClient;
using ViennaNET.Kernel.Domain.ValueObjects;

namespace SP.AspNetCore.Authentication.OnlineBank
{
  /// <summary>
  ///   Аутентифицирует запрос, используя службу авторизации и токен доступа, выданный этой службой, платформы онлайн банка.
  /// </summary>
  public class ReferenceTokenHandler : AuthenticationHandler<ReferenceTokenSchemeOptions>
  {
    private const string FormTokenKey = "token";

    /// <inheritdoc />
    public ReferenceTokenHandler(
      IOptionsMonitor<ReferenceTokenSchemeOptions> options,
      ILoggerFactory logger,
      UrlEncoder encoder,
      ISystemClock clock,
      IAuthorizationService authorizationService,
      IProfileService profileService) : base(options, logger, encoder, clock)
    {
      AuthorizationService = authorizationService;
      ProfileService = profileService;
    }

    private IAuthorizationService AuthorizationService { get; }
    private IProfileService ProfileService { get; }

    /// <inheritdoc />
    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
      var token = string.Empty;

      if (Request.Headers.ContainsKey(HeaderNames.Authorization) &&
          Request.Headers.TryGetValue(HeaderNames.Authorization, out StringValues header) &&
          !StringValues.IsNullOrEmpty(header))
      {
        token = header.ToString().Substring("Bearer ".Length).Trim();
      }
      else if (Request.HasFormContentType &&
               Request.Form.TryGetValue(FormTokenKey, out StringValues value) &&
               !StringValues.IsNullOrEmpty(value))
      {
        token = value.ToString().Trim();
      }

      // если токен содержит точку, тогда мы получили JWT токен, а не reference токен онлайн банка.
      if (string.IsNullOrWhiteSpace(token) || token.Contains('.'))
      {
        return AuthenticateResult.NoResult();
      }

      ClaimsIdentity? identity = await IntrospectReferenceToken(token).ConfigureAwait(false);

      if (identity?.FindFirst(JwtClaimTypes.Subject) is null)
      {
        return AuthenticateResult.Fail(
          "Вызов конечной точки самоанализа, службы авторизации онлайн банка, завершился с ошибками.");
      }

      if (!await RetrieveAuthDevices(identity).ConfigureAwait(false))
      {
        return AuthenticateResult.Fail(
          "Запрос списка подключенных пользователем устройств, в службе профилей онлайн банка, завершился с ошибками.");
      }

      identity.AddClaim(new Claim(JwtClaimTypes.Issuer, Options.ClaimsIssuer ?? ClaimsIssuer));

      var principal = new ClaimsPrincipal(identity);

      return AuthenticateResult.Success(
        new AuthenticationTicket(principal, ReferenceTokenDefaults.AuthenticationScheme));
    }

    /// <summary>
    ///   Вызывает службу авторизации онлайн банка, для проверки действительности токена и получения информации о владельце
    ///   ресурсов.
    /// </summary>
    /// <param name="token">Строка представляющая ссылочный токен доступа, выданный слубой авторизации онлайн банка.</param>
    /// <returns>Ссылка на объект <see cref="ClaimsIdentity" />.</returns>
    private async Task<ClaimsIdentity?> IntrospectReferenceToken(string token)
    {
      try
      {
        ROnlineIntrospectionResponse? response = await AuthorizationService.Introspection(token).ConfigureAwait(false);
        return response is not null
          ? new ClaimsIdentity(response.ToClaims(), ReferenceTokenDefaults.AuthenticationScheme, JwtClaimTypes.Name,
            JwtClaimTypes.Role)
          : null;
      }
      catch (HttpRequestException e) when (e.StatusCode == HttpStatusCode.BadRequest)
      {
        return null;
      }
    }

    /// <summary>
    ///   Получает список доступных способов двухфакторной проверки подленности (claim type is amr=otp),
    ///   запрашивая в службе профилей клиентов онлайн банка информацию о зарегистрированных клиентом устройствах.
    /// </summary>
    /// <param name="identity">Ссылка на объект <see cref="ClaimsIdentity" />.</param>
    /// <returns>Ссылка на объект <see cref="Task" />.</returns>
    private async Task<bool> RetrieveAuthDevices(ClaimsIdentity identity)
    {
      var subject = identity.GetSubjectId();
      var extSystemId = identity.GetExtSystemId();
      var request = new CustomerAuthDevicesRequestBody(new CustomerNumber(subject), extSystemId);
      var devices = await ProfileService.GetCustomerAuthDevicesAsync(request);

      if (!devices.Any())
      {
        return false;
      }

      IEnumerable<Claim> claims =
        devices.Select(device => new Claim(ReferenceTokenJwtClaimTypes.ConfirmationMethods, device));
      identity.AddClaims(claims);

      return true;
    }
  }
}