using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using IdentityModel;
using SP.OnlineBank.Auth.HttpClient;

namespace SP.AspNetCore.Authentication.OnlineBank.Extensions
{
  /// <summary>
  ///   Предоставляет методы расширения типа <see cref="ROnlineIntrospectionResponse" />.
  /// </summary>
  internal static class IntrospectionResponseExtensions
  {
    /// <summary>
    ///   Преобразует значения полей <see cref="ROnlineIntrospectionResponse" /> в коллекцию <see cref="Claim" />.
    /// </summary>
    /// <param name="response">Ссылка на объект <see cref="ROnlineIntrospectionResponse" />.</param>
    /// <returns>Коллекция утверждений о пользователе онлайн банка.</returns>
    internal static IEnumerable<Claim> ToClaims(this ROnlineIntrospectionResponse? response)
    {
      if (response?.Owner is null)
      {
        return Enumerable.Empty<Claim>();
      }

      return response.Owner.ToClaims()
        .Append(new Claim(ReferenceTokenJwtClaimTypes.ReferenceToken, response.AccessToken!))
        .Append(new Claim(JwtClaimTypes.Role, ReferenceTokenDefaults.UserRole))
        .Append(new Claim(JwtClaimTypes.IssuedAt, response.IssuedAt.ToString(), ClaimValueTypes.DateTime))
        .Append(new Claim(JwtClaimTypes.Expiration, response.Expiration.ToString(), ClaimValueTypes.DateTime));
    }

    private static IEnumerable<Claim> ToClaims(this ResourceOwner resourceOwner)
    {
      return new List<Claim>
      {
        new(JwtClaimTypes.IdentityProvider, "online bank authorization service"),
        new(JwtClaimTypes.Subject, resourceOwner.CustomerNumber.ToString()),
        new(JwtClaimTypes.Name, resourceOwner.FullName ?? string.Empty),
        new(JwtClaimTypes.GivenName, resourceOwner.FirstName ?? string.Empty),
        new(JwtClaimTypes.FamilyName, resourceOwner.LastName ?? string.Empty),
        new(JwtClaimTypes.MiddleName, resourceOwner.Patronymic ?? string.Empty),
        new(JwtClaimTypes.BirthDate, resourceOwner.BirthDate.ToString("dd-MM-yyyy")),
        new(ReferenceTokenJwtClaimTypes.IdentityCardNumber, resourceOwner.PassportNumber ?? string.Empty),
        new(ReferenceTokenJwtClaimTypes.IdentityCardIssuer, resourceOwner.PassportIssuer ?? string.Empty),
        new(ReferenceTokenJwtClaimTypes.IdentityCardIssueAt, resourceOwner.PassportIssueAt.ToString("dd-MM-yyyy")),
        new(ReferenceTokenJwtClaimTypes.ResidentStatus, resourceOwner.IsResident.ToString()),
        new(ReferenceTokenJwtClaimTypes.ComplianceStatus, resourceOwner.Compliance.ToString()),
        new(ReferenceTokenJwtClaimTypes.Branch, resourceOwner.Branch.ToString()),
        new(ReferenceTokenJwtClaimTypes.EmployerNumber, resourceOwner.EmployerNumber.ToString()),
        new(ReferenceTokenJwtClaimTypes.IndividualTaxpayerNumber,
          resourceOwner.IndividualTaxpayerNumber ?? string.Empty),
        new(ReferenceTokenJwtClaimTypes.ExternalSystem, "MWS")
      };
    }
  }
}