namespace SP.AspNetCore.Authentication.OneTimePassword
{
  /// <summary>
  ///   Значения по умолчанию, используемые при проверке подлинности с помощью службы авторизации и токена доступа онлайн
  ///   банка.
  /// </summary>
  public static class OneTimePasswordDefaults
  {
    /// <summary>
    ///   Значение по умолчанию для AuthenticationScheme, используемое для идентификации обработчика аутентификации OnlineBank.
    /// </summary>
    public const string AuthenticationScheme = "OneTimePassword";
  }
}