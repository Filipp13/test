using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("SP.AspNetCore.Authentication.OneTimePassword.Tests")]