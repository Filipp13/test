namespace SP.AspNetCore.Authentication.OneTimePassword
{
  /// <summary>
  ///   Представляет набор имён утверждений используемых для интеграции с онлайн банком.
  /// </summary>
  public static class OtpJwtClaimTypes
  {
    /// <summary>
    ///   Представляет наименование утвержения о доступных клиенту способах подтверждения операций в онлайн банке.
    /// </summary>
    public const string ConfirmationMethods = "confirmation_methods";

    /// <summary>
    ///   Представляет наименование утвержения о используемом способе подтверждения операций в онлайн банке.
    /// </summary>
    public const string ConfirmationMethod = "confirmation_method";

    /// <summary>
    ///   Представляет наименование утверждения о назначенном операции клиента инедтификаторе в системе RCAS.
    /// </summary>
    public const string RcasId = "rcas_id";

    /// <summary>
    ///   Представляет наименование утверждения о идентификаторе, использованного пользователя мобильном приложении, для
    ///   совершения операции.
    /// </summary>
    public const string RcasAppId = "rcas_app_id";

    /// <summary>
    ///   Представляет наименование утверждения о дате подписания документа связанного с операцией пользователя, в онлайн
    ///   банке.
    /// </summary>
    public const string RcasDocumentSignOn = "rcas_document_sign_on";

    /// <summary>
    ///   Представляет наименование утверждения о подписанном, в рамках операции пользователя в онлайн банке, документе.
    /// </summary>
    public const string RcasSignedDocument = "rcas_signed_document";

    /// <summary>
    ///   Представляет наименование утверждения о использованом пользователем,
    ///   одноразовом пароле, для подписания операции в онлайн банке.
    /// </summary>
    public const string OneTimePassword = "otp";

    /// <summary>
    ///   Представляет наименование утверждения о допустимом времени действия высланного одноразового пароля.
    /// </summary>
    public const string RepeatOtpWaitIntervalClaimType = "repeat_otp_wait_interval";

    /// <summary>
    ///   Представляет наименование утверждения о системе, внешней, по отношению к службам аутентификации и авторизации онлайн
    ///   банка.
    /// </summary>
    public const string ExternalSystem = "external_system";
  }
}