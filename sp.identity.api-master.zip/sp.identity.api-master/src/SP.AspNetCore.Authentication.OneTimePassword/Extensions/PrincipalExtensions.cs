using System;
using System.Security.Claims;
using IdentityModel;

namespace SP.AspNetCore.Authentication.OneTimePassword.Extensions
{
  /// <summary>
  ///   Предоставляет методы расширения для извлечения утверждений.
  /// </summary>
  internal static class PrincipalExtensions
  {
    /// <summary>
    ///   Получает значение утверждения <see cref="JwtClaimTypes.Subject" /> из <see cref="ClaimsPrincipal" />.
    /// </summary>
    /// <param name="principal">Ссылка на объект <see cref="ClaimsPrincipal" />.</param>
    /// <returns>Значение утверждения о субъекте.</returns>
    /// <exception cref="InvalidOperationException">Возникает если утверждение не найдено.</exception>
    public static string GetSubjectId(this ClaimsPrincipal principal)
    {
      Claim? claim = principal.FindFirst(JwtClaimTypes.Subject);

      if (claim == null)
      {
        throw new InvalidOperationException("Missing of claim type the sub");
      }

      return claim.Value;
    }

    /// <summary>
    ///   Получает значение утверждения <see cref="JwtClaimTypes.Subject" /> из <see cref="ClaimsIdentity" />.
    /// </summary>
    /// <param name="identity">Ссылка на объект <see cref="ClaimsIdentity" />.</param>
    /// <returns>Значение утверждения о субъекте.</returns>
    /// <exception cref="InvalidOperationException">Возникает если утверждение не найдено.</exception>
    internal static string GetSubjectId(this ClaimsIdentity identity)
    {
      Claim? claim = identity.FindFirst(JwtClaimTypes.Subject);

      if (claim == null)
      {
        throw new InvalidOperationException("Missing of claim type the sub");
      }

      return claim.Value;
    }

    /// <summary>
    ///   Получает значение утверждения <see cref="OtpJwtClaimTypes.ExternalSystem" /> из
    ///   <see cref="ClaimsIdentity" />.
    /// </summary>
    /// <param name="identity">Ссылка на объект <see cref="ClaimsIdentity" />.</param>
    /// <returns>Значение утверждения о внешней системе.</returns>
    /// <exception cref="InvalidOperationException">Возникает если утверждение не найдено.</exception>
    internal static string GetExtSystemId(this ClaimsIdentity identity)
    {
      Claim? claim = identity.FindFirst(OtpJwtClaimTypes.ExternalSystem);

      if (claim == null)
      {
        throw new InvalidOperationException("Missing of claim type the external_system");
      }

      return claim.Value;
    }

    /// <summary>
    ///   Получает значение утверждения <see cref="OtpJwtClaimTypes.ExternalSystem" /> из
    ///   <see cref="ClaimsIdentity" />.
    /// </summary>
    /// <param name="principal">Ссылка на объект <see cref="ClaimsPrincipal" />.</param>
    /// <returns>Значение утверждения о внешней системе.</returns>
    /// <exception cref="InvalidOperationException">Возникает если утверждение не найдено.</exception>
    public static string GetExtSystemId(this ClaimsPrincipal principal)
    {
      Claim? claim = principal.FindFirst(OtpJwtClaimTypes.ExternalSystem);

      if (claim == null)
      {
        throw new InvalidOperationException("Missing of claim type the external_system");
      }

      return claim.Value;
    }
  }
}