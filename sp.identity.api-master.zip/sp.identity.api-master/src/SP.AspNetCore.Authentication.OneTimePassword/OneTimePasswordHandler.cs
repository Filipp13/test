using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using IdentityModel;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;
using SP.OnlineBank.Rcas.Contracts;
using SP.OnlineBank.Rcas.Contracts.Authentication;
using SP.OnlineBank.Rcas.Contracts.Common;
using ViennaNET.Kernel.Domain.ValueObjects;
using IRcasAuthenticationService = SP.OnlineBank.Rcas.SoapClient.IAuthenticationService;
using IRcasProfileService = SP.OnlineBank.Rcas.SoapClient.IProfileService;

// ReSharper disable ClassNeverInstantiated.Global

namespace SP.AspNetCore.Authentication.OneTimePassword
{
  /// <summary>
  ///   Аутентифицирует запрос, используя одноразовый пароль, службу аутентификации и службу профилей платформы онлайн банка.
  /// </summary>
  public class OneTimePasswordHandler : AuthenticationHandler<OneTimePasswordSchemeOptions>
  {
    private const string DefaultExtSystem = "MWS";
    private const string OuterParameterPrefix = "outer";
    private const string PUSHOTP = "PUSHOTP";
    private const string SMSOTP = "SMSOTP";
    private const long DefaultAmount = 0;

    private readonly NameValueType _defaultOuterValue = new("outer.fake", string.Empty);

    public OneTimePasswordHandler(
      IOptionsMonitor<OneTimePasswordSchemeOptions> options,
      ILoggerFactory logger,
      UrlEncoder encoder,
      ISystemClock clock,
      IRcasProfileService profileService,
      IRcasAuthenticationService authenticationService) : base(options, logger, encoder, clock)
    {
      ProfileService = profileService;
      AuthenticationService = authenticationService;
    }

    private IRcasProfileService ProfileService { get; }
    private IRcasAuthenticationService AuthenticationService { get; }

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
      // если значение одного из обязательных параметров не представлено, продолжать процесс не возможно.
      // при этом мы не можем утверждать что произошёл сбой аутентификации.
      if (!Request.HasFormContentType ||
          !Request.Form.TryGetValue("confirmation_method", out StringValues method) ||
          !Request.Form.TryGetValue("username", out StringValues user) ||
          !Request.Form.TryGetValue("operation_type_id", out StringValues operationTypeId) ||
          !Request.Form.TryGetValue("request_id", out StringValues requestId) ||
          StringValues.IsNullOrEmpty(method) ||
          StringValues.IsNullOrEmpty(user) ||
          StringValues.IsNullOrEmpty(operationTypeId) ||
          StringValues.IsNullOrEmpty(requestId))
      {
        return Task.FromResult(AuthenticateResult.NoResult());
      }

      return method.ToString() switch
      {
        PUSHOTP when !Request.Form.TryGetValue(OtpJwtClaimTypes.RcasId, out _) =>
          SendPush(new CustomerNumber(user.ToString()), operationTypeId, requestId),
        PUSHOTP when Request.Form.TryGetValue(OtpJwtClaimTypes.RcasId, out StringValues rcasId) =>
          ValidatePushCode(new CustomerNumber(user.ToString()), operationTypeId, requestId, rcasId),
        SMSOTP when !Request.Form.TryGetValue(OtpJwtClaimTypes.RcasId, out StringValues rcasId) ||
                    string.IsNullOrEmpty(rcasId) =>
          SendSms(new CustomerNumber(user.ToString()), operationTypeId, requestId),
        SMSOTP when Request.Form.TryGetValue(OtpJwtClaimTypes.RcasId, out StringValues rcasId) =>
          ValidateSmsCode(new CustomerNumber(user.ToString()), operationTypeId, requestId, rcasId),
        _ => Task.FromResult(AuthenticateResult.NoResult())
      };
    }

    private async Task<AuthenticateResult> SendPush(CustomerNumber cnum, string operationTypeId, string requestId)
    {
      var identity = new ClaimsIdentity();
      var principal = new ClaimsPrincipal(identity);
      IFormCollection form = Request.Form;
      var amount = form.TryGetValue("amount", out StringValues param) && decimal.TryParse(param, out var amountParam)
        ? amountParam
        : DefaultAmount;
      string extSystemId = form.TryGetValue(OtpJwtClaimTypes.ExternalSystem, out StringValues extSystemParam)
        ? extSystemParam
        : DefaultExtSystem;
      var outers = form.Where(pair => pair.Key.Contains(OuterParameterPrefix)).ToList();

      // если значение одного из обязательных параметров не представлено, продолжать процесс не возможно.
      if (!form.TryGetValue("push_id", out StringValues pushId) || StringValues.IsNullOrEmpty(pushId))
      {
        Logger.LogInformation("Параметр - '{ParamName}', отсутствует в запросе", nameof(pushId));
        return AuthenticateResult.NoResult();
      }

      var requestBody = new AppByPushIdRequestBody(cnum, pushId);
      var appId = await ProfileService.GetApplicationIdAsync(requestBody).ConfigureAwait(false);

      if (string.IsNullOrWhiteSpace(appId))
      {
        return AuthenticateResult.Fail(
          $"Не удалось получить идентификатор приложения по значению параметра запроса '{nameof(pushId)}'");
      }

      var request = new SendPushOTPRequestBody
      {
        CustomerId = cnum,
        ExtSystemId = extSystemId,
        OperationTypeId = operationTypeId,
        SessionId = requestId,
        ApplicationId = appId
      };

      if (outers.Any())
      {
        // Для обратной совместимости со старыми операциями!
        // Служба аутентификации онлайн банка требует передачи "outer" параметров,
        // которые использовались для подстановки в документ и тело сообщения.
        request.Ext.Values.AddRange(outers.Select(pair => new NameValueType(pair.Key, pair.Value.ToString())));
      }
      else
      {
        // Для новых операций просто подставляет "fake" параметр.
        request.Ext.Values.Add(_defaultOuterValue);
      }

      request.BuildVerificationData((long)amount, cnum);

      var rcasId = await AuthenticationService.SendPushOTPAsync(request);

      if (!rcasId.HasValue)
      {
        return AuthenticateResult.Fail(
          $"Служба аутентификации онлайн банка не вернула идентификатор запроса ('{nameof(rcasId)}').");
      }

      identity.AddClaim(new Claim(JwtClaimTypes.Subject, cnum));
      identity.AddClaim(new Claim(OtpJwtClaimTypes.RcasId, rcasId.Value.ToString()));
      identity.AddClaim(new Claim(OtpJwtClaimTypes.RcasAppId, appId));
      identity.AddClaim(new Claim(OtpJwtClaimTypes.ConfirmationMethod, PUSHOTP));
      identity.AddClaim(new Claim(JwtClaimTypes.AuthenticationMethod, "otp"));
      identity.AddClaim(new Claim(JwtClaimTypes.IdentityProvider, "online bank authorization service"));
      identity.AddClaim(new Claim(JwtClaimTypes.AuthenticationTime,
        new DateTimeOffset(DateTime.UtcNow).ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64));

      var ticket = new AuthenticationTicket(principal, OneTimePasswordDefaults.AuthenticationScheme);

      return AuthenticateResult.Success(ticket);
    }

    private async Task<AuthenticateResult> SendSms(CustomerNumber cnum, string operationTypeId, string requestId)
    {
      var identity = new ClaimsIdentity();
      var principal = new ClaimsPrincipal(identity);

      IFormCollection form = Request.Form;
      var amount = form.TryGetValue("amount", out StringValues param) && long.TryParse(param, out var value)
        ? value
        : DefaultAmount;
      string extSystemId = form.TryGetValue(OtpJwtClaimTypes.ExternalSystem, out StringValues extSystem)
        ? extSystem
        : DefaultExtSystem;
      IEnumerable<KeyValuePair<string, StringValues>> outers =
        form.Where(pair => pair.Key.Contains(OuterParameterPrefix)).ToList();

      var request = new SendSmsOTPRequestBody
      {
        CustomerId = cnum, ExtSystemId = extSystemId, OperationTypeId = operationTypeId, SessionId = requestId
      };

      if (outers.Any())
      {
        // Для обратной совместимости со старыми операциями!
        // Служба аутентификации онлайн банка требует передачи "outer" параметров,
        // которые использовались для подстановки в документ и тело сообщения.
        request.Ext.Values.AddRange(outers.Select(pair => new NameValueType(pair.Key, pair.Value.ToString())));
      }
      else
      {
        // Для новых операций просто подставляет "fake" параметр.
        request.Ext.Values.Add(_defaultOuterValue);
      }

      request.BuildVerificationData(amount, cnum);

      var rcasId = await AuthenticationService.SendSmsOtpAsync(request);

      if (!rcasId.HasValue)
      {
        return AuthenticateResult.Fail(
          $"Служба аутентификации онлайн банка не вернула идентификатор запроса ('{nameof(rcasId)}').");
      }

      identity.AddClaim(new Claim(JwtClaimTypes.Subject, cnum));
      identity.AddClaim(new Claim(OtpJwtClaimTypes.RcasId, rcasId.Value.ToString()));
      identity.AddClaim(new Claim(OtpJwtClaimTypes.ConfirmationMethod, SMSOTP));
      identity.AddClaim(new Claim(JwtClaimTypes.AuthenticationMethod, "otp"));
      identity.AddClaim(new Claim(JwtClaimTypes.IdentityProvider, "online bank authorization service"));
      identity.AddClaim(new Claim(JwtClaimTypes.AuthenticationTime,
        new DateTimeOffset(DateTime.UtcNow).ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64));

      var ticket = new AuthenticationTicket(principal, OneTimePasswordDefaults.AuthenticationScheme);

      return AuthenticateResult.Success(ticket);
    }

    private async Task<AuthenticateResult> ValidatePushCode(CustomerNumber cnum, string operationTypeId,
      string requestId, string rcasId)
    {
      var identity = new ClaimsIdentity();
      var principal = new ClaimsPrincipal(identity);

      IFormCollection form = Request.Form;
      var amount = form.TryGetValue("amount", out StringValues param) && decimal.TryParse(param, out var value)
        ? value
        : DefaultAmount;

      if (!int.TryParse(rcasId, out _))
      {
        Logger.LogInformation("Параметр запроса '{ParamName}' недействителен", nameof(rcasId));
        return AuthenticateResult.NoResult();
      }

      if (!form.TryGetValue(OtpJwtClaimTypes.RcasAppId, out StringValues appId) || StringValues.IsNullOrEmpty(appId))
      {
        Logger.LogInformation("Параметр запроса '{ParamName}' отсутствует или недействителен", nameof(appId));
        return AuthenticateResult.NoResult();
      }

      if (!form.TryGetValue(OtpJwtClaimTypes.OneTimePassword, out StringValues otpParam) ||
          !long.TryParse(otpParam, out var otp))
      {
        Logger.LogInformation("Параметр запроса '{ParamName}' отсутствует или недействителен", nameof(otp));
        return AuthenticateResult.NoResult();
      }

      if (!form.TryGetValue(OtpJwtClaimTypes.RcasSignedDocument, out StringValues document) ||
          StringValues.IsNullOrEmpty(document))
      {
        Logger.LogInformation("Параметр запроса '{ParamName}' отсутствует или недействителен", nameof(document));
        return AuthenticateResult.NoResult();
      }

      var request = new VerifyPushOTPRequestBody
      {
        CustomerId = cnum,
        ExtSystemId = "MWS",
        OperationTypeId = operationTypeId,
        SessionId = requestId,
        Amount = amount,
        ApplicationId = appId.ToString(),
        RequestId = requestId,
        RcasId = int.Parse(rcasId)
      };

      request.SignDocument(document, otp);
      request.BuildVerificationData((long)amount, cnum, otp);

      var isVerified = await AuthenticationService.VerifyPushOTPAsync(request);

      if (!isVerified)
      {
        return AuthenticateResult.Fail("Проверка одноразового пароля завершилась неудачей");
      }

      identity.AddClaim(new Claim(JwtClaimTypes.Subject, cnum));
      identity.AddClaim(new Claim(OtpJwtClaimTypes.ConfirmationMethod, PUSHOTP));
      identity.AddClaim(new Claim(JwtClaimTypes.AuthenticationMethod, "otp"));
      identity.AddClaim(new Claim(JwtClaimTypes.IdentityProvider, "online bank authorization service"));
      identity.AddClaim(new Claim(JwtClaimTypes.Scope, "operations.signed"));
      identity.AddClaim(new Claim(OtpJwtClaimTypes.RcasDocumentSignOn,
        DateTime.Now.ToString(CultureInfo.InvariantCulture)));
      identity.AddClaim(new Claim(OtpJwtClaimTypes.RcasSignedDocument, request.Document));
      identity.AddClaim(new Claim(JwtClaimTypes.AuthenticationTime,
        new DateTimeOffset(DateTime.UtcNow).ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64));

      var ticket = new AuthenticationTicket(principal, OneTimePasswordDefaults.AuthenticationScheme);

      return AuthenticateResult.Success(ticket);
    }

    private async Task<AuthenticateResult> ValidateSmsCode(CustomerNumber cnum, string operationTypeId,
      string requestId, string rcasId)
    {
      var identity = new ClaimsIdentity();
      var principal = new ClaimsPrincipal(identity);

      IFormCollection form = Request.Form;
      var amount = form.TryGetValue("amount", out StringValues param) && decimal.TryParse(param, out var value)
        ? value
        : DefaultAmount;

      if (!int.TryParse(rcasId, out _))
      {
        Logger.LogInformation("Параметр запроса '{ParamName}' недействителен", nameof(rcasId));
        return AuthenticateResult.NoResult();
      }

      if (!form.TryGetValue(OtpJwtClaimTypes.OneTimePassword, out StringValues otpParam) ||
          !long.TryParse(otpParam, out var otp))
      {
        Logger.LogInformation("Параметр запроса '{ParamName}' отсутствует или недействителен", nameof(otp));
        return AuthenticateResult.NoResult();
      }

      if (!form.TryGetValue(OtpJwtClaimTypes.RcasSignedDocument, out StringValues document) ||
          StringValues.IsNullOrEmpty(document))
      {
        Logger.LogInformation("Параметр запроса '{ParamName}' отсутствует или недействителен", nameof(document));
        return AuthenticateResult.NoResult();
      }

      var request = new VerifySmsOTPRequestBody
      {
        CustomerId = cnum,
        ExtSystemId = "MWS",
        OperationTypeId = operationTypeId,
        SessionId = requestId,
        Amount = amount,
        RequestId = requestId,
        RcasId = int.Parse(rcasId)
      };

      request.SignDocument(document, otp);
      request.BuildVerificationData((long)amount, cnum, otp);

      var isVerified = await AuthenticationService.VerifySmsOtpAsync(request);

      if (!isVerified)
      {
        return AuthenticateResult.Fail("Проверка одноразового пароля завершилась неудачей");
      }

      identity.AddClaim(new Claim(JwtClaimTypes.IdentityProvider, "online bank authorization service"));
      identity.AddClaim(new Claim(JwtClaimTypes.Subject, cnum));
      identity.AddClaim(new Claim(OtpJwtClaimTypes.ConfirmationMethod, SMSOTP));
      identity.AddClaim(new Claim(JwtClaimTypes.AuthenticationMethod, "otp"));
      identity.AddClaim(new Claim(JwtClaimTypes.Scope, "operations.signed"));
      identity.AddClaim(new Claim(OtpJwtClaimTypes.RcasDocumentSignOn,
        DateTime.Now.ToString(CultureInfo.InvariantCulture)));
      identity.AddClaim(new Claim(OtpJwtClaimTypes.RcasSignedDocument, request.Document));
      identity.AddClaim(new Claim(JwtClaimTypes.AuthenticationTime,
        new DateTimeOffset(DateTime.UtcNow).ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64));

      var ticket = new AuthenticationTicket(principal, OneTimePasswordDefaults.AuthenticationScheme);

      return AuthenticateResult.Success(ticket);
    }
  }
}