﻿using Microsoft.AspNetCore.Authentication;

namespace SP.AspNetCore.Authentication.OneTimePassword
{
  /// <summary>
  ///   Класс параметров предоставляет информацию, необходимую для управления поведением обработчика согласованной
  ///   аутентификации.
  /// </summary>
  public class OneTimePasswordSchemeOptions : AuthenticationSchemeOptions
  {
    /// <summary>
    ///   Получает наименование секции конфигурации.
    /// </summary>
    public const string ConfigurationSection = "Authentication:OneTimePassword";
  }
}