using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;
using SP.Resources.Api.HttpClient.DependencyInjection;
using HttpClientBuilderExtensions = SP.Resources.Api.HttpClient.DependencyInjection.HttpClientBuilderExtensions;

namespace SP.Resources.Api.HttpClient.Tests.DependencyInjection
{
  [TestFixture(Category = "Integration", TestOf = typeof(HttpClientBuilderExtensions))]
  public class HttpClientBuilderExtensionsTests
  {
    public void ResourcesServiceResolve()
    {
      var builder = new ConfigurationBuilder();
      var services = new ServiceCollection();

      builder.AddInMemoryCollection(new Dictionary<string, string>()
      {
        {"Endpoints:Resources:BaseAddress", "http://localhost"}
      });
      services.AddResourcesServiceClient(builder.Build());
      
      var service = services.BuildServiceProvider().GetRequiredService<IResourcesService>();
      
      Assert.IsNotNull(service);
    }
  }
}