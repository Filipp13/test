using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using SP.Resources.Api.HttpClient.Models;

namespace SP.Resources.Api.HttpClient.Tests
{
  [TestFixture(Category = "Unit", TestOf = typeof(ResourcesService))]
  public class ResourcesServiceTests
  {
    public ResourcesServiceTests()
    {
      CultureInfo.CurrentCulture = new CultureInfo("en");
    }
    
    [Test]
    public void Ctor_DoesNotThrow()
    {
      var clientMock = new Mock<System.Net.Http.HttpClient>();
      Assert.DoesNotThrow(() => _ = new ResourcesService(clientMock.Object));
    }
    
    [Test]
    public async Task GetAsync_ReturnsCultureList()
    {
      var cultures = new List<Culture>
      {
        new()
        {
          Gpc = "FD0200",
          Lpc = "SA06",
          Version = new byte[] {23, 56, 221},
          Name = "ru",
          Resources = new []
          {
            new Resource
            {
              Key = "Conditions",
              Value = "xyn",
              MediaType = "plain/text",
              Version = new byte[] { 13, 22, 0, 5}
            }
          }
        }
      };
      
      var client = GetClient((_, _) => Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
      {
        Content = new StringContent(JsonSerializer.Serialize(cultures))
      }));
      
      var service = new ResourcesService(client);

      CollectionAssert.AreEquivalent(cultures, await service.GetAsync());
    }

    [Test]
    public async Task GetAsync_ReturnsEmptyList()
    {
      var client = GetClient((_, _) => Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
      {
        Content = new StringContent("[]")
      }));
      var service = new ResourcesService(client);

      Assert.AreEqual(await service.GetAsync(), new List<Culture>());
    }

    [Test]
    public async Task GetAsync_Single_ReturnsCulture()
    {
      var culture = new Culture {Gpc = "FD0200", Lpc = "SA06"};
      
      var client = GetClient((_, _) => Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
      {
        Content = new StringContent(JsonSerializer.Serialize(culture))
      }));
      var service = new ResourcesService(client);

      Assert.IsNotNull(await service.GetAsync("FD0200", "SA06"));
    }

    [Test]
    public async Task GetASync_Single_ReturnsNull()
    {
      var client = GetClient((_, _) => Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
      {
        Content = new StringContent("")
      }));
      var service = new ResourcesService(client);

      Assert.IsNull(await service.GetAsync("FD0200", "SA06"));
    }

    private System.Net.Http.HttpClient GetClient(Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> sendAsync)
    {
      return new(new HttpMessageHandlerStub(sendAsync)) {BaseAddress = new Uri("http://localhost")};
    }
    
    public class HttpMessageHandlerStub : HttpMessageHandler
    {
      private readonly Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> _sendAsync;

      public HttpMessageHandlerStub(Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> sendAsync)
      {
        _sendAsync = sendAsync;
      }

      protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
      {
        return await _sendAsync(request, cancellationToken);
      }
    }
  }
}