using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NUnit.Framework;
using SP.Resources.Api.Infrastructure;
using SP.Resources.Api.Models;

namespace SP.Resources.Api.Tests.Infrastructure
{
  [TestFixture(Category = "Unit", TestOf = typeof(ResourcesDbContext))]
  public class ResourcesDbContextTests
  {
    [OneTimeSetUp]
    public void Setup() => Context = _provider.GetRequiredService<ResourcesDbContext>();

    public ResourcesDbContextTests()
    {
      var services = new ServiceCollection();
      services
        .AddLogging(builder =>
        {
          builder.AddSimpleConsole(options => options.IncludeScopes = true)
            .SetMinimumLevel(LogLevel.Trace)
            .AddDebug();
        })
        .AddEntityFrameworkInMemoryDatabase()
        .AddDbContext<ResourcesDbContext>(
          builder => builder.UseInMemoryDatabase("TestDB")
            .UseInternalServiceProvider(_provider)
            .EnableSensitiveDataLogging(),
          ServiceLifetime.Singleton);

      _provider = services.BuildServiceProvider(true);
    }

    [Test(Description = "Материализует сущности для проверки сопоставлений.")]
    public void Products_IsEmpty() => Assert.DoesNotThrow(() => _ = Context.Cultures.ToList());

    [Test]
    [Category("Unit")]
    public void Customers_SaveAndPublishAsync_DoesNotThrow()
    {
      var culture = new Culture {Id = 1, Name = "ru", Gpc = "FD0200", Lpc = "SA06", Version = new byte[] {23, 221, 123, 13}};
      var resource = new Resource
      {
        CultureId = 1,
        Key = "Description",
        Value = "Test resource description",
        MediaType = "text/plain",
        Version = new byte[] {23, 221, 123, 13},
        Culture = culture
      };
      var resources = new List<Resource> {resource};

      culture.Resources = resources;

      _ = Context.Cultures.Add(culture);

      Assert.DoesNotThrow(() => Context.SaveChangesAsync());
    }

#nullable disable
    private readonly ServiceProvider _provider;
    private ResourcesDbContext Context { get; set; }
#nullable restore
  }
}