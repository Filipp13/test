using NUnit.Framework;
using SP.Resources.Api.Domain;

namespace SP.Resources.Api.Tests.Domain
{
  [TestFixture(Category = "Unit", TestOf = typeof(ResourceEntityTypeConfiguration))]
  public class ResourceEntityTypeConfigurationTests
  {
    
  }
}