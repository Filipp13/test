using NUnit.Framework;
using SP.Resources.Api.Domain;

namespace SP.Resources.Api.Tests.Domain
{
  [TestFixture(Category = "Unit", TestOf = typeof(CultureEntityTypeConfiguration))]
  public class CultureEntityTypeConfigurationTests
  {
  }
}