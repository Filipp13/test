using NUnit.Framework;
using SP.Resources.Api.DependencyInjection;

namespace SP.Resources.Api.Tests.DependencyInjection
{
  [TestFixture(Category = "Unit", TestOf = typeof(UoWServiceCollectionExtensions))]
  public class UoWServiceCollectionExtensionsTests
  {
    
  }
}