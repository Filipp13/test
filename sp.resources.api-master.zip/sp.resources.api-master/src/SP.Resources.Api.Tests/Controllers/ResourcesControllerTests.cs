using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using SP.Resources.Api.Controllers;
using SP.Resources.Api.Infrastructure;
using SP.Resources.Api.Models;

namespace SP.Resources.Api.Tests.Controllers
{
  [TestFixture(Category = "Unit", TestOf = typeof(ResourcesController))]
  public class ResourcesControllerTests
  {
#nullable disable
    private readonly ServiceProvider _provider;
    private ResourcesDbContext Context { get; set; }
    private List<Culture> _cultures;
#nullable restore

    public ResourcesControllerTests()
    {
      var services = new ServiceCollection();
      services
        .AddLogging(builder =>
        {
          builder.AddSimpleConsole(options => options.IncludeScopes = true)
            .SetMinimumLevel(LogLevel.Trace)
            .AddDebug();
        })
        .AddEntityFrameworkInMemoryDatabase()
        .AddDbContext<ResourcesDbContext>(
          builder => builder.UseInMemoryDatabase("TestDB")
            .UseInternalServiceProvider(_provider)
            .EnableSensitiveDataLogging(),
          ServiceLifetime.Singleton);

      _provider = services.BuildServiceProvider(true);
    }
    
    [OneTimeSetUp]
    public void Setup()
    {
      DbContextOptions<ResourcesDbContext>?
        options = _provider.GetRequiredService<DbContextOptions<ResourcesDbContext>>();
      ILogger<ResourcesDbContext>? logger = new Mock<ILogger<ResourcesDbContext>>().Object;
      using var context = new ResourcesDbContext(options, logger);

      var culture = new Culture {Id = 1, Gpc = "FD0200", Lpc = "SA04", Name = "ru", Version = new byte[1]};
      culture.Resources = new[]
      {
        new Resource
        {
          Key = "Conditions",
          Value = "{\"blah\": \"blahblah\"}",
          MediaType = "application\\json",
          Version = new byte[0],
          Culture = null,
          CultureId = 1
        }
      };

      _cultures = new List<Culture>();
      _cultures.Add(culture);
      culture = new Culture
      {
        Id = 3,
        Gpc = "FD0200",
        Lpc = "SA80",
        Name = "en",
        Version = new byte[1]
      };
      culture.Resources = new[]
      {
        new Resource
        {
          Key = "AccrualScheme",
          Value = "{\"blah\": \"blahblah\"}",
          MediaType = "application\\json",
          Version = new byte[0],
          Culture = null,
          CultureId = 3
        }
      };
      
      _cultures.Add(culture);
      context.Cultures.AddRange(_cultures);
      context.SaveChanges();

      Context = _provider.GetRequiredService<ResourcesDbContext>();
    }
    
    [Test]
    public void Ctor_Throws_ArgumentNullException() =>
      Assert.Catch<ArgumentNullException>(() => _ = new ResourcesController(null!));

    [Test]
    public async Task GetAsync_ReturnsAllCultures()
    {
      var controller = new ResourcesController(Context);
      CollectionAssert.AreEquivalent(await controller.GetAsync(), _cultures);
    }

    [Test]
    public async Task GetSingleAsync_NoSuchCulture_ReturnsNull()
    {
      var controller = new ResourcesController(Context);
      CultureInfo.CurrentCulture = new CultureInfo("by");
      var culture = await controller.GetSingleAsync("FD0200", "SA04");
      Assert.IsNull(culture);
    }

    [Test]
    public async Task GetSingleAsync_HasCulture_ReturnsCulture()
    {
      var controller = new ResourcesController(Context);
      CultureInfo.CurrentCulture = new CultureInfo("ru");
      var culture = await controller.GetSingleAsync("FD0200", "SA04");
      Assert.AreEqual(culture, _cultures.First(c => c.Name == "ru"
                                                    && c.Gpc == "FD0200" && c.Lpc == "SA04"));
    }

    [Test]
    public async Task GetSingleAsync_NoSuchGpcLpc_ReturnsNull()
    {
      var controller = new ResourcesController(Context);
      CultureInfo.CurrentCulture = new CultureInfo("ru");
      var culture = await controller.GetSingleAsync("FD0200", "TM04");
      Assert.IsNull(culture);
    }
  }
}