using System.Collections.Generic;
using System.Threading.Tasks;
using SP.Resources.Api.HttpClient.Models;

namespace SP.Resources.Api.HttpClient
{
  public interface IResourcesService
  {
    public Task<IEnumerable<Culture?>?> GetAsync();
    public Task<Culture?> GetAsync(string gpc, string lpc);
  }
}