using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using SP.Resources.Api.HttpClient.Models;

namespace SP.Resources.Api.HttpClient
{
  public class ResourcesService : IResourcesService
  {
    private readonly System.Net.Http.HttpClient _client;
    private readonly JsonSerializerOptions _serializerOptions;

    public ResourcesService(System.Net.Http.HttpClient client)
    {
      _client = client;
      _serializerOptions = new JsonSerializerOptions {PropertyNameCaseInsensitive = true};
    }

    public async Task<IEnumerable<Culture?>?> GetAsync()
    {
     
      var json = await _client.GetStringAsync("api/resources").ConfigureAwait(false);
      
      await using var stream = new MemoryStream(Encoding.UTF8.GetBytes(json));

      return json == string.Empty
        ? default
        : await JsonSerializer.DeserializeAsync<IEnumerable<Culture>?>(stream, _serializerOptions);
    }

    public async Task<Culture?> GetAsync(string gpc, string lpc)
    {
    
      var json = await _client.GetStringAsync(
        $"api/resources/{gpc}/{lpc}").ConfigureAwait(false);
      await using var stream = new MemoryStream(Encoding.UTF8.GetBytes(json));

      return json == string.Empty
        ? default
        : await JsonSerializer.DeserializeAsync<Culture>(stream, _serializerOptions);
    }
  }
}