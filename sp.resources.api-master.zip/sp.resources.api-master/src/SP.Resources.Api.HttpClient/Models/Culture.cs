using System;
using System.Collections.Generic;
using System.Linq;

namespace SP.Resources.Api.HttpClient.Models
{
  /// <summary>
  /// Представляет сущность Культура
  /// </summary>
  public class Culture
  {
    /// <summary>
    /// Получает наименование культуры. Значение по умолчанию: "ru".
    /// </summary>
    /// <example>ru</example>
    public string? Name { get; init; }

    /// <summary>
    /// Получает или задаёт уникальный идентификатор группы продуктов в продуктовом каталоге.
    /// </summary>
    /// <example>FD0200</example>
    public string? Gpc { get; init; }
    
    /// <summary>
    /// Получает или задаёт уникальный идентификатор в продуктовом каталоге.
    /// </summary>
    /// <example>SA06</example>
    public string? Lpc { get; init; }

    /// <summary>
    ///   Получает значение, представляющее версию используемую для оптимистичной блокировки.
    /// </summary>
    public byte[]? Version { get; init; }

    /// <summary>
    /// Получает коллекцию ресурсов связанных с культурой (только для чтения).
    /// </summary>
    public IReadOnlyCollection<Resource>? Resources { get; init; }
    
    /// <inheritdoc />
    public override bool Equals(object obj)
    {
      return obj is Culture culture && Equals(culture);
    }

    private bool Equals(Culture other)
    {
      return Name == other.Name
             && Gpc == other.Gpc
             && Lpc == other.Lpc
             && Version!.SequenceEqual(other.Version!)
             && Resources!.All(r => other.Resources!.Any(r.Equals));
    }

    /// <inheritdoc />
    public override int GetHashCode()
    {
      return HashCode.Combine(Name, Gpc, Lpc, Version, Resources);
    }
  }
}