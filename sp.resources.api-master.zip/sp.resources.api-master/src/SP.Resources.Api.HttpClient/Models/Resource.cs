using System;
using System.Linq;

namespace SP.Resources.Api.HttpClient.Models
{
  /// <summary>
  /// Представляет сущность Ресурс
  /// </summary>
  public class Resource
  {
    /// <summary>
    ///   Получает путь до ресурса.
    /// </summary>
    public string? Key { get; set; }

    /// <summary>
    ///   Получает значение ресурса.
    /// </summary>
    public string? Value { get; set; }

    /// <summary>
    ///   Получает MIME-тип ресурса.
    /// </summary>
    public string? MediaType { get; set; }
    
    /// <summary>
    ///   Получает значение, представляющее версию используемую для оптимистичной блокировки.
    /// </summary>
    public byte[]? Version { get; set; }
    
    public override bool Equals(object obj)
    {
      return obj is Resource res && Equals(res);
    }

    private bool Equals(Resource other)
    {
      return Key == other.Key
             && Value == other.Value
             && MediaType == other.MediaType
             && (Version?.SequenceEqual(other.Version ?? Array.Empty<byte>()) ?? false);
    }

    /// <inheritdoc />
    public override int GetHashCode()
    {
      return HashCode.Combine(Key, Value, MediaType, Version);
    }
  }
}