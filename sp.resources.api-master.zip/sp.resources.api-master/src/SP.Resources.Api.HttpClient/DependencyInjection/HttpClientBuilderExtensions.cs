using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Polly;
using Polly.Extensions.Http;
using System.Net.Http;

namespace SP.Resources.Api.HttpClient.DependencyInjection
{
  /// <summary>
  ///   Предоставляет методы регистрации <see cref="HttpClient"/>.
  /// </summary>
  public static class HttpClientBuilderExtensions
  {
    public static IHttpClientBuilder AddResourcesServiceClient(
      this IServiceCollection services,
      IConfiguration configuration)
    {
      var options = configuration.GetSection(ResourcesServiceOptions.SectionName)
        .Get<ResourcesServiceOptions>();

      if (options is null)
      {
        throw new InvalidOperationException(
          "Unable to configure Online Bank authorization service agent. " +
          $"Configuration options from \"{ResourcesServiceOptions.SectionName}\" not found.");
      }

      services.Configure<ResourcesServiceOptions>(configuration.GetSection(ResourcesServiceOptions.SectionName));

      return services
        .AddHttpClient<IResourcesService, ResourcesService>()
        .SetHandlerLifetime(TimeSpan.FromMinutes(1))
        .AddPolicyHandler(GetRetryPolicy(options.RetryCount, options.RetryDelay))
        .AddPolicyHandler(Policy.TimeoutAsync<HttpResponseMessage>(options.TryTimeout))
        .ConfigureHttpClient(client =>
        {
          client.BaseAddress = new Uri(options.BaseAddress!);
          client.Timeout = TimeSpan.FromSeconds(options.OverallTimeout);
        });
    }

    private static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy(int retryCount, int retryDelay)
    {
      return HttpPolicyExtensions
        .HandleTransientHttpError()
        .WaitAndRetryAsync(retryCount,
          retryAttempt => TimeSpan.FromSeconds(Math.Pow(retryDelay, retryAttempt)));
    }
  }
}