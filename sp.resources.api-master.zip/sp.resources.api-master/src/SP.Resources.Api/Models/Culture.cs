﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace SP.Resources.Api.Models
{
  /// <summary>
  /// Представляет культуру, определяющую язык на котором написаны ресурсы.
  /// </summary>
  [SuppressMessage("ReSharper", "UnusedAutoPropertyAccessor.Global")]
  public sealed class Culture
  {
    /// <summary>
    /// Получает или задаёт уникальный идентификатор.
    /// </summary>
    public int Id { get; init; }

    /// <summary>
    /// Получает наименование культуры. Значение по умолчанию: "ru".
    /// </summary>
    /// <example>ru</example>
    public string Name { get; set; }

    /// <summary>
    /// Получает или задаёт уникальный идентификатор группы продуктов в продуктовом каталоге.
    /// </summary>
    /// <example>FD0200</example>
    public string Gpc { get; set; }
    
    /// <summary>
    /// Получает или задаёт уникальный идентификатор в продуктовом каталоге.
    /// </summary>
    /// <example>SA06</example>
    public string Lpc { get; set; }

    /// <summary>
    ///   Получает значение, представляющее версию используемую для оптимистичной блокировки.
    /// </summary>
    public byte[] Version { get; set; }

    /// <summary>
    /// Получает коллекцию ресурсов связанных с культурой (только для чтения).
    /// </summary>
    public IReadOnlyCollection<Resource> Resources { get; set; }

    /// <inheritdoc />
    public override bool Equals(object obj)
    {
      return obj is Culture culture && Equals(culture);
    }

    private bool Equals(Culture other)
    {
      return Id == other.Id
             && Name == other.Name
             && Gpc == other.Gpc
             && Lpc == other.Lpc
             && Version.SequenceEqual(other.Version)
             && Resources.All(r => other.Resources.Any(r.Equals));
    }

    /// <inheritdoc />
    public override int GetHashCode()
    {
      return HashCode.Combine(Id, Name, Gpc, Lpc, Version, Resources);
    }
  }
}