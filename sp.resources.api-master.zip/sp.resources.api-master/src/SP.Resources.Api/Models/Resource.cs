﻿#nullable disable
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text.Json.Serialization;

namespace SP.Resources.Api.Models
{
  /// <summary>
  ///   Инкапсулирует информацию о статических ресурсах, отображаемых клиенту на карточке продукта.
  /// </summary>
  [SuppressMessage("ReSharper", "UnusedAutoPropertyAccessor.Global")]
  [SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
  public sealed class Resource
  {
    /// <summary>
    ///   Получает путь до ресурса.
    /// </summary>
    public string Key { get; set; }

    /// <summary>
    ///   Получает значение ресурса.
    /// </summary>
    public string Value { get; set; }

    /// <summary>
    ///   Получает MIME-тип ресурса.
    /// </summary>
    public string MediaType { get; set; }
    
    /// <summary>
    ///   Получает значение, представляющее версию используемую для оптимистичной блокировки.
    /// </summary>
    public byte[] Version { get; set; }
    
    public int CultureId { get; set; }

    /// <summary>
    /// Получает или инициализирует коллекцию <see cref="Culture"/>.
    /// </summary>
    [JsonIgnore]
    public Culture Culture { get; set; }

    /// <inheritdoc />
    public override bool Equals(object obj)
    {
      return obj is Resource res && Equals(res);
    }

    private bool Equals(Resource other)
    {
      return Key == other.Key
             && Value == other.Value
             && MediaType == other.MediaType
             && Version.SequenceEqual(other.Version)
             && CultureId == other.CultureId
             && Culture.Id == other.Culture.Id;
    }

    /// <inheritdoc />
    public override int GetHashCode()
    {
      return HashCode.Combine(Key, Value, MediaType, Version, CultureId, Culture);
    }
  }
}