﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SP.Resources.Api.Infrastructure;
using SP.Resources.Api.Models;

namespace SP.Resources.Api.Controllers
{
  /// <summary>
  ///   Предоставляет Web Api для работы с ресурсом <see cref="Resource" />.
  /// </summary>
  [Route("api/[controller]")]
  [ApiController]
  [AllowAnonymous]
  [ResponseCache(CacheProfileName = "Default")]
  public class ResourcesController : ControllerBase
  {
    private readonly ResourcesDbContext _context;

    /// <summary>
    ///   Создаёт и инициализирует новый экземпляр класса <see cref="ResourcesController" />.
    /// </summary>
    /// <param name="context">Ссылка на объект <see cref="ResourcesDbContext"/>.</param>
    /// <exception cref="ArgumentNullException">Возникает, если <paramref name="context"/> = <see langword="null"/>.</exception>
    public ResourcesController(ResourcesDbContext context)
    {
      _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    /// <summary>
    ///   Получить все <see cref="Culture"/> и связанные с ними <see cref="Resource" />.
    /// </summary>
    /// <remarks>
    /// Ответ службы кашируется средствами HTTP.
    /// Заголовок Cache Control будет включать max-age = 86400
    /// </remarks>
    /// <returns>
    /// Коллекция <see cref="Culture"/>.
    /// </returns>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<Resource>), StatusCodes.Status200OK)]
    public Task<List<Culture>> GetAsync()
    {
      return _context.Cultures.Include(culture => culture.Resources).ToListAsync();
    }

    /// <summary>
    ///   Возвращает экземпляр ресурса по заданным значениям параметров.
    /// </summary>
    /// <param name="gpc">Уникальный идентификатор группы продуктов в продуктовом каталоге.</param>
    /// <param name="lpc">Уникальный идентификатор в продуктовом каталоге.</param>
    /// <returns>
    ///   Экземпляр <see cref="Culture" />, соответствующий указанному Accept-Language
    /// и <paramref name="gpc"/>, <paramref name="lpc"/>.
    /// </returns>
    [HttpGet("{gpc}/{lpc}")]
    [ProducesResponseType(typeof(Culture), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public Task<Culture> GetSingleAsync(string gpc, string lpc)
    {
      return _context.Cultures.Include(product => product.Resources)
        .SingleOrDefaultAsync(culture => culture.Name == CultureInfo.CurrentCulture.Name
                                         && culture.Gpc == gpc && culture.Lpc == lpc);
    }
  }
}