using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SP.Resources.Api.Models;

namespace SP.Resources.Api.Domain
{
  internal sealed class CultureEntityTypeConfiguration : IEntityTypeConfiguration<Culture>
  {
    public void Configure(EntityTypeBuilder<Culture> builder)
    {
      builder.ToTable("Cultures").HasKey(culture => culture.Id);
      builder.Property(culture => culture.Id);
      builder.Property(culture => culture.Name).HasMaxLength(5).IsRequired();
      builder.Property(culture => culture.Gpc).HasMaxLength(6).IsRequired();
      builder.Property(culture => culture.Lpc).HasMaxLength(4).IsRequired();
      builder.Property(product => product.Version).IsRowVersion();

      builder.HasMany(product => product.Resources)
        .WithOne(resource => resource.Culture)
        .IsRequired();
    }
  }
}