using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SP.Resources.Api.Models;

namespace SP.Resources.Api.Domain
{
  internal sealed class ResourceEntityTypeConfiguration : IEntityTypeConfiguration<Resource>
  {
    public void Configure(EntityTypeBuilder<Resource> builder)
    {
      builder.ToTable("Resources").HasKey(resource => new {resource.Key, resource.CultureId});
      builder.Property(resource => resource.Key).HasMaxLength(50).IsRequired();
      builder.Property(resource => resource.Value).IsRequired();
      builder.Property(resource => resource.MediaType).HasMaxLength(100).IsRequired();
      builder.Property(resource => resource.Version).IsRowVersion();

      builder.HasOne(resource => resource.Culture)
        .WithMany(culture => culture.Resources)
        .IsRequired();
    }
  }
}