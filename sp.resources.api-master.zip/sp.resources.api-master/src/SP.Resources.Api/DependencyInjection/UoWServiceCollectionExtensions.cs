using System;
using System.Linq;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SP.Resources.Api.Infrastructure;

namespace SP.Resources.Api.DependencyInjection
{
  internal static class UoWServiceCollectionExtensions
  {
    public static IServiceCollection AddUnitOfWork(
      this IServiceCollection services, 
      IConfiguration configuration,
      IWebHostEnvironment environment)
    {
      services
        .AddDbContext<ResourcesDbContext>(options =>
          {
            options.UseSqlServer(configuration.GetConnectionString("SP.Resources.Api"),
              sqlServerOptions =>
              {
                sqlServerOptions.EnableRetryOnFailure(15, TimeSpan.FromSeconds(30), null);
              });

            if (environment.IsDevelopment())
            {
              options.EnableSensitiveDataLogging()
                .EnableDetailedErrors();
            }
          }
        );

      return services;
    }
  }
}