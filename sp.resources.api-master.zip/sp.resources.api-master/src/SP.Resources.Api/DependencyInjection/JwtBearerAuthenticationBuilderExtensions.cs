using System;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace SP.Resources.Api.DependencyInjection
{
  internal static class JwtBearerAuthenticationBuilderExtensions
  {
    private const string ConfigurationSection = "Authentication:Bearer                                                ";

    public static AuthenticationBuilder AddJwtBearer(
      this AuthenticationBuilder builder,
      IConfiguration configuration,
      IWebHostEnvironment hostEnvironment)
    {
      if (builder == null)
      {
        throw new ArgumentNullException(nameof(builder));
      }

      if (configuration == null)
      {
        throw new ArgumentNullException(nameof(configuration));
      }

      if (hostEnvironment == null)
      {
        throw new ArgumentNullException(nameof(hostEnvironment));
      }

      builder.AddJwtBearer();
      builder.Services.Configure<JwtBearerOptions>(JwtBearerDefaults.AuthenticationScheme,
        configuration.GetSection(ConfigurationSection));

      return builder;
    }
  }
}