using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Logging;
using SP.Resources.Api.DependencyInjection;

namespace SP.Resources.Api
{
  internal class Startup
  {
    public Startup(IConfiguration configuration, IWebHostEnvironment hostEnvironment)
    {
      Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
      HostEnvironment = hostEnvironment ?? throw new ArgumentNullException(nameof(hostEnvironment));
    }

    public IConfiguration Configuration { get; }
    public IWebHostEnvironment HostEnvironment { get; }

    public void ConfigureServices(IServiceCollection services)
    {
      services
        .AddControllers(options => options.CacheProfiles.Add("Default",
          new CacheProfile
          {
            Duration = 86400,
            Location = ResponseCacheLocation.Any,
            VaryByHeader = "Accept-Language",
            VaryByQueryKeys = Array.Empty<string>()
          }))
        .AddJsonOptions(options =>
        {
          options.JsonSerializerOptions.IgnoreNullValues = true;
          options.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
        });

      services
        .AddResponseCaching()
        .AddResponseCompression()
        .AddUnitOfWork(Configuration, HostEnvironment)
        .AddHealthChecks();
    }

    public void Configure(IApplicationBuilder app)
    {
      if (HostEnvironment.IsDevelopment())
      {
        IdentityModelEventSource.ShowPII = true;

        app.UseDeveloperExceptionPage();
      }

      app.UseRouting();
      app.UseSwagger();
      app.UseRequestLocalization("en", "ru");
      app.UseSwaggerUI(uiOptions =>
      {
        uiOptions.SwaggerEndpoint($"/swagger/v1/swagger.json",
          HostEnvironment.ApplicationName);
      });
      app.UseResponseCaching();
      app.UseResponseCompression();
      app.UseEndpoints(endpoints =>
      {
        endpoints.MapControllers();
        endpoints.MapHealthChecks("/health");
      });
    }
  }
}