using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SP.Resources.Api.Domain;
using SP.Resources.Api.Models;

namespace SP.Resources.Api.Infrastructure
{
  /// <inheritdoc />
  [SuppressMessage("ReSharper", "UnusedAutoPropertyAccessor.Global")]
  public sealed class ResourcesDbContext : DbContext
  {
    private readonly ILogger<ResourcesDbContext> _logger;

    /// <summary>
    /// Инициализирует новый экземпляр класса <see cref="ResourcesDbContext"/>.
    /// </summary>
    /// <param name="options">Ссылка на объект <see cref="DbContextOptions{TContext}"/>.</param>
    /// <param name="logger">Ссылка на объект <see cref="ILogger{TCategoryName}"/>.</param>
    public ResourcesDbContext(
      DbContextOptions<ResourcesDbContext> options,
      ILogger<ResourcesDbContext> logger) : base(options)
    {
      _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <inheritdoc />
    protected override void OnModelCreating(ModelBuilder builder)
    {
      _logger.LogDebug("Model creating");

      builder.ApplyConfiguration(new CultureEntityTypeConfiguration());
      builder.ApplyConfiguration(new ResourceEntityTypeConfiguration());

      _logger.LogDebug("Entity types registered: {Types}",
        builder.Model.GetEntityTypes().Select(type => string.Join(',', type.Name)));
    }

#nullable disable
    /// <summary>
    /// Получает ссылку на объект <see cref="DbSet{TEntity}"/>,
    /// предоставляющий доступ к источнику данных о культурах и ресурсах.
    /// </summary>
    public DbSet<Culture> Cultures { get; set; }
#nullable restore
  }
}