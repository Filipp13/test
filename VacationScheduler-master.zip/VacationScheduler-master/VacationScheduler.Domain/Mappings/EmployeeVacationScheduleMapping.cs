﻿using System.Diagnostics.CodeAnalysis;
using FluentNHibernate.Mapping;
using NHibernate.Type;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;

namespace VacationScheduler.Domain.Mappings
{
    [ExcludeFromCodeCoverage]
    public class EmployeeVacationScheduleMapping : ClassMap<EmployeeVacationSchedule>
    {
        public EmployeeVacationScheduleMapping()
        {
            Table("employee_vacation_schedule");
            Id(d => d.Id).GeneratedBy.SequenceIdentity();
            Map(d => d.Status).CustomType<EnumType<ScheduleStatus>>().Column("status");
            Map(d => d.EmployeeNumber).Column("employee_number");
            Map(d => d.EmployeeLogin).Column("employee_login");
            Map(d => d.EmployeeFirstName).Column("employee_first_name");
            Map(d => d.EmployeeLastName).Column("employee_last_name");
            Map(d => d.EmployeeMiddleName).Column("employee_middle_name");
            Map(d => d.EmployeePosition).Column("employee_position");
            Map(d => d.EmployeeRegion).Column("employee_region");
            Map(d => d.EmployeeDirectorate).Column("employee_directorate");
            Map(d => d.EmployeeDivision).Column("employee_division");
            Map(d => d.EmployeeDepartment).Column("employee_department");
            Map(d => d.EmployeeGroup).Column("employee_group");
            Map(d => d.EmployeeSector).Column("employee_sector");
            Map(d => d.EmployeeEmail).Column("employee_email");
            Map(d => d.CalendarId).Column("calendar_id");
            Map(d => d.AvailableDays).Column("available_days");

            References(s => s.VacationSchedule).Column("vacation_schedule_id");

            HasMany(d => d.ScheduledPeriods)
                .KeyColumn("employee_vacation_schedule_id").Not.KeyNullable()
                .Cascade.AllDeleteOrphan();
        }
    }
}
