﻿using System.Diagnostics.CodeAnalysis;
using FluentNHibernate.Mapping;
using NHibernate.Type;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;

namespace VacationScheduler.Domain.Mappings
{
    [ExcludeFromCodeCoverage]
    public class VacationScheduleMapping : ClassMap<VacationSchedule>
    {
        public VacationScheduleMapping()
        {
            Table("vacation_schedule");
            Id(d => d.Id).GeneratedBy.SequenceIdentity();
            Map(d => d.Status).CustomType<EnumType<ScheduleStatus>>().Column("status");
            Map(d => d.Name).Column("name");
            Map(d => d.Year).Column("year");
            Map(d => d.UnitId).Column("unit_id");
            Map(d => d.UnitType).CustomType<EnumType<UnitType>>().Column("unit_type");

            HasMany(d => d.EmployeesSchedules)
                .KeyColumn("vacation_schedule_id")
                .Cascade.AllDeleteOrphan();

            HasManyToMany(t => t.EmployeesSchedulesForInformation)
                .Table("employeesschedules_for_information")
                .ParentKeyColumn("vacation_schedule_id")
                .ChildKeyColumn("employee_vacation_schedule_id")
                .Cascade.None();
            
            HasMany(a => a.ResponsibleManagers).Table("responsible_managers").KeyColumn("vacation_schedule_id").Component(m =>
            {
                m.Map(r => r.Login);
                m.Map(r => r.EmployeeNumber).Column("employee_number");
                m.Map(r => r.Email);
                m.Map(r => r.Fio);
            }).Cascade.AllDeleteOrphan();
        }
    }
}
