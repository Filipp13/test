﻿using System.Diagnostics.CodeAnalysis;
using FluentNHibernate.Mapping;
using NHibernate.Type;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;

namespace VacationScheduler.Domain.Mappings
{
    [ExcludeFromCodeCoverage]
    public class HolidayDateMapping : ClassMap<HolidayDate>
    {
        public HolidayDateMapping()
        {
            Table("holiday_dates");
            Id(d => d.Id).GeneratedBy.SequenceIdentity();
            Map(d => d.CalendarId).Column("calendar_id");
            Map(d => d.HolidayDateValue).Column("holiday_date");
            Map(d => d.CalendarName).Column("calendar_name");
            Map(d => d.CalendarDayType).CustomType<EnumType<CalendarDayType>>().Column("type_day");
            Map(d => d.UploadDate).Column("upload_date");
        }
    }
}
