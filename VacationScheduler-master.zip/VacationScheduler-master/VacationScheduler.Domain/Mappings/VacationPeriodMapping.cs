﻿using System.Diagnostics.CodeAnalysis;
using FluentNHibernate.Mapping;
using NHibernate.Type;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;

namespace VacationScheduler.Domain.Mappings
{
    [ExcludeFromCodeCoverage]
    public class VacationPeriodMapping : ClassMap<VacationPeriod>
    {
        public VacationPeriodMapping()
        {
            Table("vacation_period");
            Id(d => d.Id).GeneratedBy.SequenceIdentity();

            Map(d => d.Type).CustomType<EnumType<PeriodType>>().Column("type");
            Map(d => d.From).Column("\"from\"");
            Map(d => d.To).Column("\"to\"").Nullable();
        }
    }
}
