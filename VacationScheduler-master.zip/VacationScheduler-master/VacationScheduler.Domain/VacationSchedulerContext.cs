﻿using VacationScheduler.Domain.Entities;
using ViennaNET.Orm;

namespace VacationScheduler.Domain
{
    internal class VacationSchedulerContext : ApplicationContext
    {
        public VacationSchedulerContext()
        {
            AddEntity<VacationSchedule>();
            AddEntity<EmployeeVacationSchedule>();
            AddEntity<VacationPeriod>();
            AddEntity<HolidayDate>();
        }
    }
}
