﻿using System;
using System.Collections.Generic;
using System.Linq;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Domain.Services.UserService;

namespace VacationScheduler.Domain.Services.PermissionService
{
    public class PermissionService : IPermissionService
    {
        public IEnumerable<VacationScheduleAction> GetVacationScheduleActions(VacationSchedule schedule, IUser user)
        {
            var result = new List<VacationScheduleAction>();
            var isResponsibleManager = schedule.ResponsibleManagers.Select(m => m.Login).Contains(user.Login);

            switch (schedule.Status)
            {
                case ScheduleStatus.Formation:
                    if (isResponsibleManager)
                    {
                        result.Add(VacationScheduleAction.ToManagerApprove);
                    }
                    break;
                case ScheduleStatus.ManagerApprovement:
                    if (isResponsibleManager)
                    {
                        result.AddRange(new[] { VacationScheduleAction.ToFormation, VacationScheduleAction.ToHrApprove });
                    }
                    break;
                case ScheduleStatus.HrApprovement:
                    if (user.IsHrForVacationSchedule(schedule))
                    {
                        result.Add(VacationScheduleAction.Approve);
                    }
                    break;
                case ScheduleStatus.Approved:
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }

            return result;
        }

        public IEnumerable<EmployeeScheduleAction> GetEmployeeScheduleActions(EmployeeVacationSchedule employeeSchedule, IUser user)
        {
            var isOwnSchedule = employeeSchedule.EmployeeLogin == user.Login;

            var result = Enumerable.Empty<EmployeeScheduleAction>();

            if (isOwnSchedule && employeeSchedule.VacationSchedule.Status == ScheduleStatus.Formation)
            {
                result = result.Append(EmployeeScheduleAction.Edit);
            }

            var isResponsibleManager = employeeSchedule.VacationSchedule.ResponsibleManagers.Any(m => m.Login == user.Login);

            if (isResponsibleManager && employeeSchedule.VacationSchedule.Status == ScheduleStatus.ManagerApprovement)
            {
                result = result.Append(EmployeeScheduleAction.Edit);
            }

            if (user.IsHrForEmployee(employeeSchedule.EmployeeNumber) && employeeSchedule.VacationSchedule.Status == ScheduleStatus.HrApprovement)
            {
                result = result.Append(EmployeeScheduleAction.Edit);
            }

            return result.Distinct();
        }
    }
}
