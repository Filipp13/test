﻿using System.Collections.Generic;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Services.UserService;

namespace VacationScheduler.Domain.Services.PermissionService
{
    public interface IPermissionService
    {
        IEnumerable<EmployeeScheduleAction> GetEmployeeScheduleActions(EmployeeVacationSchedule employeeSchedule, IUser user);

        IEnumerable<VacationScheduleAction> GetVacationScheduleActions(VacationSchedule schedule, IUser user);
    }
}
