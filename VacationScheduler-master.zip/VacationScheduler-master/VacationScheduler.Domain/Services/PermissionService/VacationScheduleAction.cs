﻿namespace VacationScheduler.Domain.Services.PermissionService
{
    public enum VacationScheduleAction
    {
        ToManagerApprove = 1,

        ToFormation = 2,

        ToHrApprove = 3,

        Approve = 4
    }
}
