﻿namespace VacationScheduler.Domain.Services.PermissionService
{
    public enum EmployeeScheduleAction
    {
        Edit = 1
    }
}
