﻿using System.Threading.Tasks;

namespace VacationScheduler.Domain.Services.UserService
{
    public interface IUserRepository
    {
        Task<IUser> GetUserAsync(string login);
        
        Task<IUser> GetCurrentUserAsync();
    }
}
