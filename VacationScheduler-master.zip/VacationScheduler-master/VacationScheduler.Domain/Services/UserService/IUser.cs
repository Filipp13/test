﻿using System.Collections.Generic;
using VacationScheduler.Domain.Entities;

namespace VacationScheduler.Domain.Services.UserService
{
    public interface IUser
    {
        string Login { get; }
        
        bool IsHr { get; }

        bool IsHrForEmployee(string employeeNumber);

        IEnumerable<string> GetEmployeeNumbersWhereHr();

        bool IsHrForVacationSchedule(VacationSchedule schedule);
    }
}
