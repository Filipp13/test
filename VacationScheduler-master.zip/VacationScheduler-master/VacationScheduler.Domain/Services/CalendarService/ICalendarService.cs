﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace VacationScheduler.Domain.Services.CalendarService
{
    public interface ICalendarService
    {
        bool IsHoliday(DateTime date, int calendarId);

        bool IsWorkingDay(DateTime date, int calendarId);

        Task<List<CalendarDate>> GetHolidayDatesAsync(int year, CancellationToken cancellationToken);
    }
}
