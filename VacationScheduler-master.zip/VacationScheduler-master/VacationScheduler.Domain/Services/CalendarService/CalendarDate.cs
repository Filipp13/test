﻿using System;

namespace VacationScheduler.Domain.Services.CalendarService
{
    public class CalendarDate
    {
        public int CalendarId { get; set; }

        public DateTime Date { get; set; }
    }
}
