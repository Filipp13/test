﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace VacationScheduler.Domain.Exceptions
{
    [Serializable]
    public class EmployeeVacationScheduleValidationErrorException : Exception
    {
        public EmployeeVacationScheduleValidationErrorException(string message) : base(message)
        {
        }

        [ExcludeFromCodeCoverage]
        protected EmployeeVacationScheduleValidationErrorException([NotNull] SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
