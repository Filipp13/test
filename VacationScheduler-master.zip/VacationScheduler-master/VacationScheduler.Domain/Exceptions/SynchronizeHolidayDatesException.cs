﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace VacationScheduler.Domain.Exceptions
{
    [Serializable]
    public class SynchronizeHolidayDatesException : Exception
    {
        public SynchronizeHolidayDatesException(string message) : base(message)
        {
        }

        [ExcludeFromCodeCoverage]
        protected SynchronizeHolidayDatesException([NotNull] SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
