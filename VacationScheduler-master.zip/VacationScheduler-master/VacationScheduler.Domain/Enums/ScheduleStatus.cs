﻿namespace VacationScheduler.Domain.Enums
{
    public enum ScheduleStatus
    {
        Formation = 0,

        ManagerApprovement = 1,

        HrApprovement = 2,

        Approved = 3
    }
}
