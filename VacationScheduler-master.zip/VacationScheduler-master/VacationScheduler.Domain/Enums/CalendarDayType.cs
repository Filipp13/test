﻿namespace VacationScheduler.Domain.Enums
{
    public enum CalendarDayType
    {
        /// <summary>
        /// Выходной день
        /// </summary>
        Dayoff = 0,

        /// <summary>
        /// Праздничный день
        /// </summary>
        Holiday = 1
    }
}
