﻿namespace VacationScheduler.Domain.Enums
{
    public enum UnitType
    {
        Department = 0,

        Team = 1
    }
}
