﻿namespace VacationScheduler.Domain.Enums
{
    public enum PeriodType
    {
        TwoWeeks = 0,

        OneWeek = 1,

        ByDays = 2
    }
}
