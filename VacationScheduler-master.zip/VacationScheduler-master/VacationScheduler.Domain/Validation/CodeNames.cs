﻿namespace VacationScheduler.Domain.Validation
{
    public static class CodeNames
    {
        public const string AvailableDaysNotSpent = "AvailableDaysNotSpent";

        public const string AvailableDaysExceeded = "AvailableDaysExceeded";

        public const string VacationPeriodsIntersect = "VacationPeriodsIntersect";

        public const string VacationPeriodsFromGreaterThanTo = "VacationPeriodsFromGreaterThanTo";

        public const string VacationPeriodsYearMismatch = "VacationPeriodsYearMismatch";
        
        public const string VacationPeriodShouldNotStartFromHoliday = "VacationPeriodShouldNotStartFromHoliday";
        
        public const string VacationPeriodShouldHaveAtLeastOneWorkday = "VacationPeriodShouldHaveAtLeastOneWorkday";
    }
}
