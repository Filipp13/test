﻿using System.Linq;
using VacationScheduler.Domain.Dto;
using VacationScheduler.Domain.Services.CalendarService;
using ViennaNET.Validation.Rules.FluentRule;

namespace VacationScheduler.Domain.Validation.Applications.Rules
{
    public class UpdateEmployeeScheduleRule : BaseFluentRule<UpdateEmployeeScheduleDto>
    {
        private const string InternalCode = "UpdateEmployeeScheduleRule";

        public UpdateEmployeeScheduleRule(VacationPeriodsRule vacationPeriodsRule, ICalendarService calendarService) :
            base(InternalCode)
        {
            ForProperty(x => x).Must((employeeScheduleDto, _) =>
            {
                var daysPlannedCount = employeeScheduleDto.VacationPeriodDtos
                    .SelectMany(v => v.VacationPeriod.GetDatesOfPeriod())
                    .Count();

                return employeeScheduleDto.EmployeeVacationSchedule.AvailableDays <= daysPlannedCount;
            }).WithErrorMessage(CodeNames.AvailableDaysNotSpent, "Запланировано недостаточное количество дней отпуска");

            ForProperty(x => x).Must((employeeScheduleDto, _) =>
            {
                var daysPlannedCount = employeeScheduleDto.VacationPeriodDtos
                    .SelectMany(v => v.VacationPeriod.GetDatesOfPeriod())
                    .Count();

                return employeeScheduleDto.EmployeeVacationSchedule.AvailableDays >= daysPlannedCount;
            }).WithErrorMessage(CodeNames.AvailableDaysExceeded, "Запланировано слишком много дней отпуска");

            ForProperty(x => x.VacationPeriodDtos)
                .UseRule(vacationPeriodsRule);

            ForProperty(x => x)
                .Must((x, _) =>
                {
                    var periods = x.VacationPeriodDtos.Select(p => p.VacationPeriod).ToList();

                    return periods.All(p =>
                        !calendarService.IsHoliday(p.From, x.EmployeeVacationSchedule.CalendarId));
                }).WithErrorMessage(CodeNames.VacationPeriodShouldNotStartFromHoliday,
                    "Период не должен начинаться с выходного дня");

            ForProperty(x => x)
                .Must((x, _) =>
                {
                    var periods = x.VacationPeriodDtos.Select(p => p.VacationPeriod).ToList();

                    return periods.All(p =>
                        p.GetDatesOfPeriod().Any(date =>
                            calendarService.IsWorkingDay(date, x.EmployeeVacationSchedule.CalendarId)));
                }).WithErrorMessage(CodeNames.VacationPeriodShouldHaveAtLeastOneWorkday,
                    "Период не должен состоять только из выходных дней");
        }
    }
}
