﻿using System.Collections.Generic;
using System.Linq;
using VacationScheduler.Domain.Dto;
using VacationScheduler.Domain.Entities;
using ViennaNET.Validation.Rules.FluentRule;

namespace VacationScheduler.Domain.Validation.Applications.Rules
{
    public class VacationPeriodsRule : BaseFluentRule<List<VacationPeriodDto>>
    {
        private const string InternalCode = "VacationPeriodsRule";

        public VacationPeriodsRule() : base(InternalCode)
        {
            ForProperty(x => x)
                .Must((x, _) => x.TrueForAll(y =>
                    y.VacationPeriod.From.Year == y.ScheduleYear && y.VacationPeriod.To.Year == y.ScheduleYear))
                .WithErrorMessage(CodeNames.VacationPeriodsYearMismatch,
                    "Периоды должны находиться в пределах года, на который формируется график отпусков");

            ForProperty(x => x)
                .Must((x, _) => x.TrueForAll(y => y.VacationPeriod.From <= y.VacationPeriod.To))
                .WithErrorMessage(CodeNames.VacationPeriodsFromGreaterThanTo,
                    "Конец периода не может быть меньше начала периода");

            ForProperty(x => x)
                .Must((x, _) =>
                {
                    var periods = x.Select(p => p.VacationPeriod).ToList();

                    return periods.All(p1 =>
                        periods.Except(new[] { p1 }).All(p2 => !AreIntersectingPeriods(p1, p2))
                    );
                }).WithErrorMessage(CodeNames.VacationPeriodsIntersect, "Периоды не должны пересекаться");
        }

        private static bool AreIntersectingPeriods(VacationPeriod p1, VacationPeriod p2) =>
            (p1.From.Date <= p2.To.Date && p1.To.Date >= p2.From.Date)
            || (p2.From.Date <= p1.To.Date && p2.To.Date >= p1.From.Date);
    }
}
