﻿using VacationScheduler.Domain.Dto;
using VacationScheduler.Domain.Validation.Applications.Rules;
using ViennaNET.Validation.Validators;

namespace VacationScheduler.Domain.Validation.Applications
{
    public class UpdateEmployeeScheduleRuleSet : BaseValidationRuleSet<UpdateEmployeeScheduleDto>,
        IUpdateEmployeeScheduleRuleSet
    {
        public UpdateEmployeeScheduleRuleSet(UpdateEmployeeScheduleRule updateEmployeeScheduleRule)
        {
            SetRule(updateEmployeeScheduleRule);
        }
    }
}
