using VacationScheduler.Domain.Dto;
using ViennaNET.Validation.Validators;

namespace VacationScheduler.Domain.Validation.Applications
{
    public interface IUpdateEmployeeScheduleRuleSet : IValidationRuleSet<UpdateEmployeeScheduleDto>
    {
    }
}
