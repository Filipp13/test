﻿using SimpleInjector;
using SimpleInjector.Packaging;
using VacationScheduler.Domain.Services.PermissionService;
using VacationScheduler.Domain.Validation.Applications;
using VacationScheduler.Domain.Validation.Applications.Rules;
using ViennaNET.Orm.Seedwork;
using ViennaNET.Validation.Validators;

namespace VacationScheduler.Domain
{
    public class DomainPackage : IPackage
    {
        public void RegisterServices(Container container)
        {
            container.Collection.Append<IBoundedContext, VacationSchedulerContext>(Lifestyle.Singleton);
            container.RegisterSingleton<IValidator, Validator>();
            container.RegisterSingleton<UpdateEmployeeScheduleRule>();
            container.RegisterSingleton<VacationPeriodsRule>();
            container.RegisterSingleton<IUpdateEmployeeScheduleRuleSet, UpdateEmployeeScheduleRuleSet>();
            container.RegisterSingleton<IPermissionService, PermissionService>();
        }
    }
}
