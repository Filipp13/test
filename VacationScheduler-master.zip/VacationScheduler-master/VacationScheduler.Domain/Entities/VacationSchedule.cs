﻿using System.Collections.Generic;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Domain.ValueObjects;
using ViennaNET.Orm.Seedwork;

namespace VacationScheduler.Domain.Entities
{
    public class VacationSchedule : IEntityKey<int>
    {
        public virtual int Id { get; set; }

        public virtual ScheduleStatus Status { get; set; }

        public virtual string Name { get; set; }

        public virtual int Year { get; set; }

        public virtual int UnitId { get; set; }

        public virtual UnitType UnitType { get; set; }

        public virtual ISet<EmployeeVacationSchedule> EmployeesSchedules { get; set; } = new HashSet<EmployeeVacationSchedule>();

        public virtual ISet<EmployeeVacationSchedule> EmployeesSchedulesForInformation { get; set; } = new HashSet<EmployeeVacationSchedule>();

        public virtual ISet<Manager> ResponsibleManagers { get; set; } = new HashSet<Manager>();

        public virtual void SetStatusFormation() => SetStatus(ScheduleStatus.Formation);

        public virtual void SetStatusToManagerApprove() => SetStatus(ScheduleStatus.ManagerApprovement);

        public virtual void SetStatusToHrApprove() => SetStatus(ScheduleStatus.HrApprovement);

        public virtual void SetStatusApprove() => SetStatus(ScheduleStatus.Approved);

        private void SetStatus(ScheduleStatus status) => Status = status;
    }
}
