﻿using System.Collections.Generic;
using VacationScheduler.Domain.Enums;
using ViennaNET.Orm.Seedwork;

namespace VacationScheduler.Domain.Entities
{
    public class EmployeeVacationSchedule : IEntityKey<int>
    {
        public virtual int Id { get; set; }

        public virtual VacationSchedule VacationSchedule { get; set; }

        public virtual ScheduleStatus Status { get; set; }

        public virtual string EmployeeNumber { get; set; }

        public virtual string? EmployeeLogin { get; set; }

        public virtual string EmployeeFirstName { get; set; }

        public virtual string EmployeeLastName { get; set; }

        public virtual string? EmployeeMiddleName { get; set; }

        public virtual string EmployeePosition { get; set; }

        public virtual int CalendarId { get; set; }

        public virtual int AvailableDays { get; set; }

        public virtual string? EmployeeRegion { get; set; }

        public virtual string? EmployeeDirectorate { get; set; }

        public virtual string? EmployeeDivision { get; set; }

        public virtual string? EmployeeDepartment { get; set; }

        public virtual string? EmployeeGroup { get; set; }

        public virtual string? EmployeeSector { get; set; }

        public virtual string? EmployeeEmail { get; set; }

        public virtual string Fio => $"{EmployeeLastName} {EmployeeFirstName} {EmployeeMiddleName}".Trim();

        public virtual ISet<VacationPeriod> ScheduledPeriods { get; set; } = new HashSet<VacationPeriod>();
    }
}
