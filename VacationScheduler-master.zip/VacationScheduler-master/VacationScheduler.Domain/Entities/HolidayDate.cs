﻿using System;
using VacationScheduler.Domain.Enums;
using ViennaNET.Orm.Seedwork;

namespace VacationScheduler.Domain.Entities
{
    public class HolidayDate : IEntityKey<int>
    {
        public virtual int Id { get; set; }

        public virtual int CalendarId { get; set; }

        public virtual DateTime HolidayDateValue { get; set; }

        public virtual CalendarDayType CalendarDayType { get; set; }
        
        public virtual string CalendarName { get; set; }

        public virtual DateTime UploadDate { get; set; }
    }
}
