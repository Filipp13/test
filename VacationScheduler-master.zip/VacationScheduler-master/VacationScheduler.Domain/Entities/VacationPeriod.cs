﻿using System;
using System.Collections.Generic;
using VacationScheduler.Domain.Enums;
using ViennaNET.Orm.Seedwork;

namespace VacationScheduler.Domain.Entities
{
    public class VacationPeriod : IEntityKey<int>
    {
        public virtual int Id { get; }

        public virtual PeriodType Type { get; set; }

        public virtual DateTime From { get; set; }

        public virtual DateTime To { get; set; }

        public virtual IEnumerable<DateTime> GetDatesOfPeriod()
        {
            for (var currentDate = From.Date; currentDate <= To; currentDate = currentDate.AddDays(1))
            {
                yield return currentDate;
            }
        }
    }
}
