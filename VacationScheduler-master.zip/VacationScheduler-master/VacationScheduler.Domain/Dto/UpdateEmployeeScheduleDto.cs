﻿using System.Collections.Generic;
using VacationScheduler.Domain.Entities;

namespace VacationScheduler.Domain.Dto
{
    public class UpdateEmployeeScheduleDto
    {
        public EmployeeVacationSchedule EmployeeVacationSchedule { get; set; }
        
        public List<VacationPeriodDto> VacationPeriodDtos { get; set; }
    }
}
