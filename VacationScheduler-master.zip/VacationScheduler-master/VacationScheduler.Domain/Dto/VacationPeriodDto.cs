﻿using VacationScheduler.Domain.Entities;

namespace VacationScheduler.Domain.Dto
{
    public class VacationPeriodDto
    {
        public VacationPeriod VacationPeriod { get; set; }

        public int ScheduleYear { get; set; }
    }
}
