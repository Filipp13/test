﻿using System;

namespace VacationScheduler.Domain.ValueObjects
{
    public class Manager
    {
        public string Login { get; set; }
        
        public string EmployeeNumber { get; set; }
        
        public string Fio { get; set; }
        
        public string Email { get; set; }
        
        protected bool Equals(Manager other)
        {
            return Login == other.Login && EmployeeNumber == other.EmployeeNumber && Fio == other.Fio && Email == other.Email;
        }

        public override bool Equals(object? obj)
        {
            if (ReferenceEquals(null, obj))
            {
                return false;
            }

            if (ReferenceEquals(this, obj))
            {
                return true;
            }

            if (obj.GetType() != GetType())
            {
                return false;
            }

            return Equals((Manager)obj);
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Login, EmployeeNumber, Fio, Email);
        }
    }
}
