﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Threading.Tasks;
using HrManagerPermissions.Client.Dto;

namespace HrManagerPermissions.Client
{
    [ExcludeFromCodeCoverage]
    public class HrManagerPermissionsClient : IHrManagerPermissionsClient
    {
        private const string ClientName = "hr.managerpermissions.api";
        private readonly HttpClient _client;

        public HrManagerPermissionsClient(IHttpClientFactory clientFactory)
        {
            _client = clientFactory.CreateClient(ClientName);
        }

        public async Task<IList<HrPermissionDto>> GetHrUserPermissionsAsync(string login)
        {
            var url = $"employees/{login}/hrUserPermissions";

            var response = await _client.GetAsync(url);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsAsync<List<HrPermissionDto>>();
        }
    }
}
