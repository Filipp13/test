﻿namespace HrManagerPermissions.Client.Dto
{
    public sealed class HrPermissionDto
    {
        public string EmployeeNumber { get; set; }
    }
}
