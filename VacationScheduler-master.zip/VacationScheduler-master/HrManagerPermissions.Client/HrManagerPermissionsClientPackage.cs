﻿using SimpleInjector;
using SimpleInjector.Packaging;

namespace HrManagerPermissions.Client
{
    public class HrManagerPermissionsClientPackage : IPackage
    {
        public void RegisterServices(Container container)
        {
            container.Register<IHrManagerPermissionsClient, HrManagerPermissionsClient>(Lifestyle.Singleton);
        }
    }
}
