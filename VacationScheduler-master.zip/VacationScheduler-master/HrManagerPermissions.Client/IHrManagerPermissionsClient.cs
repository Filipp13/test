﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HrManagerPermissions.Client.Dto;

namespace HrManagerPermissions.Client
{
    public interface IHrManagerPermissionsClient
    {
        Task<IList<HrPermissionDto>> GetHrUserPermissionsAsync(string login);
    }
}
