﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Threading.Tasks;
using CnB.HRIntegrationService.Client.Dto;

namespace CnB.HRIntegrationService.Client
{
    [ExcludeFromCodeCoverage]
    public class HrIntegrationServiceClient : IHrIntegrationServiceClient
    {
        private const string ClientName = "cnb.hrintegrationservice.api";
        private readonly HttpClient _client;

        public HrIntegrationServiceClient(IHttpClientFactory clientFactory)
        {
            _client = clientFactory.CreateClient(ClientName);
        }

        public async Task<IList<EmployeeDto>> GetEmployees()
        {
            var url = "api/Employee";

            var response = await _client.GetAsync(url);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsAsync<List<EmployeeDto>>();
        }


        public async Task<IList<DepartmentDto>> GetDepartments()
        {
            var url = "api/Department";

            var response = await _client.GetAsync(url);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsAsync<List<DepartmentDto>>();
        }
    }
}
