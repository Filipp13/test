﻿using System.Diagnostics.CodeAnalysis;
using SimpleInjector;
using SimpleInjector.Packaging;

namespace CnB.HRIntegrationService.Client
{
    [ExcludeFromCodeCoverage]
    public class ClientPackage : IPackage
    {
        public void RegisterServices(Container container)
        {
            container.Register<IHrIntegrationServiceClient, HrIntegrationServiceClient>(Lifestyle.Singleton);
        }
    }
}
