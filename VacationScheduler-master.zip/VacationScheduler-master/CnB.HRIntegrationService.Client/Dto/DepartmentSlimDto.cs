﻿namespace CnB.HRIntegrationService.Client.Dto
{
    public class DepartmentSlimDto
    {
        public int Id { get; set; }
    }
}
