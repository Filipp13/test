﻿using System.Diagnostics.CodeAnalysis;

namespace CnB.HRIntegrationService.Client.Dto
{
    [ExcludeFromCodeCoverage]
    public sealed class EmployeeDto
    {
        /// <summary>
        /// Табельный номер
        /// </summary>
        public string Id { get; set; }

        public DepartmentSlimDto Department { get; set; }

        /// <summary>
        /// Логин учётной записи в AD
        /// </summary>
        public string? Login { get; set; }

        /// <summary>
        /// Уникальный идентификатор пользователя в Boss Kadrovik	
        /// </summary>
        public int EmployeeId { get; set; }

        /// <summary>
        /// Фамилия на русском
        /// </summary>
        public string LastNameRus { get; set; }

        /// <summary>
        /// Имя на русском
        /// </summary>
        public string FirstNameRus { get; set; }

        /// <summary>
        /// Отчество на русском
        /// </summary>
        public string? MiddleNameRus { get; set; }

        /// <summary>
        /// Должность (рус.)
        /// </summary>
        public string Position { get; set; }

        /// <summary>
        /// Регион (рус.) Level - 1
        /// </summary>
        public string? RegionRus { get; set; }

        /// <summary>
        /// Дирекция (рус.) Level - 2
        /// </summary>
        public string? DirectorateRus { get; set; }

        /// <summary>
        /// Дивизион (рус.) Level - 3
        /// </summary>
        public string? DivisionRus { get; set; }

        /// <summary>
        /// Департамент (рус.) Level - 4
        /// </summary>
        public string? DepartmentRus { get; set; }

        /// <summary>
        /// Группа (рус.) Level - 5
        /// </summary>
        public string? GroupRus { get; set; }

        /// <summary>
        /// Сектор (рус.) Level - 6
        /// </summary>
        public string? SectorRus { get; set; }

        /// <summary>
        /// Адрес электронной почты
        /// </summary>
        public string? Email { get; set; }
    }
}
