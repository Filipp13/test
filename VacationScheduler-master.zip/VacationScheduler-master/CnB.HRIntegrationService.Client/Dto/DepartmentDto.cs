﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace CnB.HRIntegrationService.Client.Dto
{
    [ExcludeFromCodeCoverage]
    public sealed class DepartmentDto
    {
        public int Id { get; set; }

        public string Name { get; set; }
        
        public List<DepartmentDto> Children { get; set; }
        
        public EmployeeSlimDto? AdministrativeHead { get; set; }

        public List<EmployeeSlimDto>? OtherManagerEmployees { get; set; }

        public int ExtraDays { get; set; }
    }
}
