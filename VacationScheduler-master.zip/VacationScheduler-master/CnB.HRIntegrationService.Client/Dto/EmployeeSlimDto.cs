﻿namespace CnB.HRIntegrationService.Client.Dto
{
    /// <summary>
    ///     Сотрудник
    /// </summary>
    public class EmployeeSlimDto
    {
        /// <summary>
        ///     Идентификатор
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        ///     ФИО
        /// </summary>
        public string Fio { get; set; }

        /// <summary>
        ///     Логин
        /// </summary>
        public string? Login { get; set; }

        /// <summary>
        ///     Адрес электронной почты
        /// </summary>
        public string? Email { get; set; }
    }
}
