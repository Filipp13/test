﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CnB.HRIntegrationService.Client.Dto;

namespace CnB.HRIntegrationService.Client
{
    public interface IHrIntegrationServiceClient
    {
        /// <summary>
        /// Получение всех актуальных сотрудников
        /// </summary>
        /// <returns></returns>
        Task<IList<EmployeeDto>> GetEmployees();
        
        /// <summary>
        ///     Получение списка всех департаментов
        /// </summary>
        Task<IList<DepartmentDto>> GetDepartments();
    }
}
