﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Moq;
using NHibernate.Linq;
using NUnit.Framework;
using VacationScheduler.Application.Commands.SynchronizeHolidayDates;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Exceptions;
using VacationScheduler.Tests.EntityFactories;
using ViennaNET.Orm.Application;
using ViennaNET.TestUtils.Orm;

namespace VacationScheduler.Tests.ApplicationCommands
{
    [TestFixture]
    public class SynchronizeHolidayDatesCommandHandlerTests
    {
        private const string DefaultSetCalendarName = "DefaultSetCalendarName";
        private const int DefaultSetCalendarId = 3;

        private static IEntityFactoryService CreateFactoryServiceStubWithSomeData(
            List<HolidayDate>? externalHolidayDates = null)
        {
            if (externalHolidayDates == null)
            {
                externalHolidayDates = new List<HolidayDate>();
                var holidayDate1 = HolidayDateBuilder.Create()
                    .SetId(1)
                    .SetCalendarId(1)
                    .SetCalendarName("SetCalendarName")
                    .SetUploadDate(DateTime.Today)
                    .SetHolidayDateValue(DateTime.Today)
                    .Build();

                externalHolidayDates.Add(holidayDate1);

                var holidayDate2 = HolidayDateBuilder.Create()
                    .SetId(2)
                    .SetCalendarId(2)
                    .SetCalendarName("SetCalendarName")
                    .SetUploadDate(DateTime.Today)
                    .SetHolidayDateValue(DateTime.Today)
                    .Build();

                externalHolidayDates.Add(holidayDate2);
                return CreateFactoryServiceStub(externalHolidayDates);
            }

            return CreateFactoryServiceStub(externalHolidayDates);
        }

        private static IEntityFactoryService CreateFactoryServiceStub(
            IEnumerable<HolidayDate>? externalHolidayDate = null)
        {
            return EntityFactoryServiceStubBuilder.Create()
                .WithRepository(
                    EntityRepositoryStub.Create<HolidayDate, int>(
                        externalHolidayDate ?? new HolidayDate[] { }))
                .Build();
        }

        private static SynchronizeHolidayDatesCommandHandler CreateHandler(IEntityFactoryService entityFactoryService,
            List<HolidayDateFormBoss> responses, bool validMoq = true)
        {
            var getResponsesFormBoss = new Mock<ISynchronizeHolidayDatesService>(MockBehavior.Strict);

            if (validMoq)
            {
                getResponsesFormBoss
                    .Setup(e => e.GetResponsesFormBossAsync())
                    .ReturnsAsync(responses);
            }
            else
            {
                getResponsesFormBoss
                    .Setup(e => e.GetResponsesFormBossAsync())
                    .Throws(new Exception("Moq Exception"));
            }

            var loggerMock = new Mock<ILogger<SynchronizeHolidayDatesCommandHandler>>();

            return new SynchronizeHolidayDatesCommandHandler(entityFactoryService, getResponsesFormBoss.Object,
                loggerMock.Object);
        }

        [Test]
        public async Task
            Handle_Existing_Any_HolidayDates_New_HolidayDate_Is_Empty_HolidayDate_Should_Clean_HolidayDates()
        {
            // Arrange
            var entityFactoryService = CreateFactoryServiceStubWithSomeData();
            var holidayDateRepository = entityFactoryService.Create<HolidayDate>();
            var existingHolidayDates = await holidayDateRepository.Query().ToListAsync();

            // Act
            var responses = new List<HolidayDateFormBoss>();

            var handler = CreateHandler(entityFactoryService, responses);
            await handler.HandleAsync(new SynchronizeHolidayDatesCommand(), CancellationToken.None);
            var newHolidayDates = await holidayDateRepository.Query().ToListAsync();

            // Assert
            Assert.That(existingHolidayDates, Is.Not.Empty);
            Assert.That(newHolidayDates, Is.Empty);
        }

        [Test]
        public async Task
            Handle_Existing_Any_HolidayDates_New_HolidayDate_Is_Single_And_Not_Empty_HolidayDate_Should_Single_HolidayDate()
        {
            // Arrange
            var entityFactoryService = CreateFactoryServiceStubWithSomeData();
            var holidayDateRepository = entityFactoryService.Create<HolidayDate>();
            var existingHolidayDates = await holidayDateRepository.Query().ToListAsync();

            // Act
            var responses = new List<HolidayDateFormBoss>();
            var holidayDate = ResponseFormBossBuilder.Create()
                .SetCalendarId(DefaultSetCalendarId)
                .SetCalendarName(DefaultSetCalendarName)
                .SetHolidayDateValue(DateTime.Today)
                .Build();
            responses.Add(holidayDate);

            var handler = CreateHandler(entityFactoryService, responses);
            await handler.HandleAsync(new SynchronizeHolidayDatesCommand(), CancellationToken.None);
            var newHolidayDates = await holidayDateRepository.Query().ToListAsync();
            var newHolidayDate = newHolidayDates.Single();

            // Assert
            Assert.That(existingHolidayDates, Is.Not.Empty);
            Assert.That(newHolidayDates, Is.Not.Empty);
            Assert.That(newHolidayDates, Has.One.Items);
            Assert.That(newHolidayDate.CalendarId, Is.EqualTo(DefaultSetCalendarId));
            Assert.That(newHolidayDate.CalendarName, Is.EqualTo(DefaultSetCalendarName));
            Assert.That(newHolidayDate.HolidayDateValue, Is.EqualTo(DateTime.Today));
            Assert.That(newHolidayDate.UploadDate.Date, Is.EqualTo(DateTime.Today));
        }

        [Test]
        public async Task
            Handle_Existing_Any_HolidayDates_New_HolidayDate_Is_Any_And_Not_Empty_HolidayDate_Should_Any_HolidayDate()
        {
            // Arrange
            var entityFactoryService = CreateFactoryServiceStubWithSomeData();
            var holidayDateRepository = entityFactoryService.Create<HolidayDate>();
            var existingHolidayDates = await holidayDateRepository.Query().ToListAsync();

            // Act
            var responses = new List<HolidayDateFormBoss>();
            var holidayDate = ResponseFormBossBuilder.Create()
                .SetCalendarId(DefaultSetCalendarId)
                .SetCalendarName(DefaultSetCalendarName)
                .SetHolidayDateValue(DateTime.Today)
                .Build();

            var holidayDate2 = ResponseFormBossBuilder.Create()
                .SetCalendarId(DefaultSetCalendarId)
                .SetCalendarName(DefaultSetCalendarName)
                .SetHolidayDateValue(DateTime.Today)
                .Build();
            responses.Add(holidayDate);
            responses.Add(holidayDate2);

            var handler = CreateHandler(entityFactoryService, responses);
            await handler.HandleAsync(new SynchronizeHolidayDatesCommand(), CancellationToken.None);
            var newHolidayDates = await holidayDateRepository.Query().ToListAsync();

            // Assert
            Assert.That(existingHolidayDates, Is.Not.Empty);
            Assert.That(newHolidayDates, Is.Not.Empty);
            foreach (var item in newHolidayDates)
            {
                Assert.That(item.CalendarId, Is.EqualTo(DefaultSetCalendarId));
                Assert.That(item.CalendarName, Is.EqualTo(DefaultSetCalendarName));
                Assert.That(item.HolidayDateValue, Is.EqualTo(DateTime.Today));
                Assert.That(item.UploadDate.Date, Is.EqualTo(DateTime.Today));
            }
        }

        [Test]
        public void
            Handle_WhenSynchronizeHolidayDatesServiceThrowException_ShouldThrowException()
        {
            // Arrange
            var entityFactoryService = CreateFactoryServiceStubWithSomeData();
            var holidayDateRepository = entityFactoryService.Create<HolidayDate>();

            // Act
            var responses = new List<HolidayDateFormBoss>();
            var handler = CreateHandler(entityFactoryService, responses, false);

            // Act
            async Task Act()
            {
                await handler.HandleAsync(new SynchronizeHolidayDatesCommand(), CancellationToken.None);
            }

            // Assert
            var exception = Assert.ThrowsAsync<SynchronizeHolidayDatesException>(Act);
            Assert.That(exception.Message,
                Does.Contain("Во время загрузки праздничных дней из БОСС произошла ошибка"));
        }
    }
}
