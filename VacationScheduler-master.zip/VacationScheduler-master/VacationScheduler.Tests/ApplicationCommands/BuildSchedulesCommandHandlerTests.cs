﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using CnB.HRIntegrationService.Client.Dto;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using NUnit.Framework;
using VacationScheduler.Api.ServicesImplementations.BuildSchedulesExternalContext;
using VacationScheduler.Application.Commands.BuildSchedules;
using VacationScheduler.Application.Commands.BuildSchedules.ExternalContext;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Tests.EntityFactories;
using ViennaNET.Orm.Seedwork;
using ViennaNET.TestUtils.Orm;

namespace VacationScheduler.Tests.ApplicationCommands
{
    [TestFixture]
    class BuildSchedulesCommandHandlerTests
    {
        private const int AvailableDays = 28;
        private const int ScheduleYear = 2007;

        private readonly EmployeeSlimDto _manager1 = new EmployeeSlimDto()
        {
            Id = "111111", Email = "man1@raif.ru", Fio = "Man Ager First", Login = "ruaman1"
        };
        private readonly EmployeeDto _manager1Employee = EmployeeDtoBuilder.Create()
            .SetEmployeeNumber("111111")
            .SetLogin("ruaman1")
            .SetLastNameRus("Man")
            .SetFirstNameRus("Ager")
            .SetMiddleNameRus("First")
            .SetEmail("man1@raif.ru")
            .SetDepartmentId(1)
            .Build();
        
        private readonly EmployeeSlimDto _manager2 = new EmployeeSlimDto()
        {
            Id = "222222", Email = "man2@raif.ru", Fio = "Man Ager Second", Login = "ruaman2"
        };
        private readonly EmployeeDto _manager2Employee = EmployeeDtoBuilder.Create()
            .SetEmployeeNumber("222222")
            .SetLogin("ruaman2")
            .SetLastNameRus("Man")
            .SetFirstNameRus("Ager")
            .SetMiddleNameRus(null)
            .SetEmail("man2@raif.ru")
            .SetDepartmentId(1)
            .Build();
        
        private static BuildSchedulesCommandHandler CreateHandler(IEntityRepository<VacationSchedule> repository, ICollection<DepartmentDto> departments, ICollection<EmployeeDto> employeeDtos,
            ICollection<Team>? teams = null)
        {
            var externalContextProvider = new ExternalContext(departments, employeeDtos, teams ?? new List<Team>());
            var externalContextProviderMock = new Mock<IExternalContextProvider>(MockBehavior.Strict);
            externalContextProviderMock
                .Setup(e => e.GetExternalContextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(externalContextProvider);
            
            var entityFactoryService = EntityFactoryServiceStubBuilder.Create()
                .WithRepository(repository)
                .Build();
            return new BuildSchedulesCommandHandler(externalContextProviderMock.Object, entityFactoryService,
                new NullLogger<BuildSchedulesCommandHandler>());
        }

        private static void AssertEmployeeVacationsScheduleEqualsEmployeeDto(
            EmployeeVacationSchedule employeeVacationSchedule, EmployeeDto employeeDto, int extraDays = 0)
        {
            Assert.Multiple(() =>
            {
                Assert.That(employeeVacationSchedule.Status, Is.EqualTo(ScheduleStatus.Formation));
                Assert.That(employeeVacationSchedule.EmployeeNumber, Is.EqualTo(employeeDto.Id));
                Assert.That(employeeVacationSchedule.EmployeeLogin, Is.EqualTo(employeeDto.Login));
                Assert.That(employeeVacationSchedule.EmployeeFirstName, Is.EqualTo(employeeDto.FirstNameRus));
                Assert.That(employeeVacationSchedule.EmployeeLastName, Is.EqualTo(employeeDto.LastNameRus));
                Assert.That(employeeVacationSchedule.EmployeeMiddleName, Is.EqualTo(employeeDto.MiddleNameRus));
                Assert.That(employeeVacationSchedule.EmployeePosition, Is.EqualTo(employeeDto.Position));
                Assert.That(employeeVacationSchedule.AvailableDays, Is.EqualTo(AvailableDays + extraDays));
                Assert.That(employeeVacationSchedule.EmployeeRegion, Is.EqualTo(employeeDto.RegionRus));
                Assert.That(employeeVacationSchedule.EmployeeDirectorate, Is.EqualTo(employeeDto.DirectorateRus));
                Assert.That(employeeVacationSchedule.EmployeeDivision, Is.EqualTo(employeeDto.DivisionRus));
                Assert.That(employeeVacationSchedule.EmployeeDepartment, Is.EqualTo(employeeDto.DepartmentRus));
                Assert.That(employeeVacationSchedule.EmployeeGroup, Is.EqualTo(employeeDto.GroupRus));
                Assert.That(employeeVacationSchedule.EmployeeSector, Is.EqualTo(employeeDto.SectorRus));
                Assert.That(employeeVacationSchedule.EmployeeEmail, Is.EqualTo(employeeDto.Email));
                Assert.That(employeeVacationSchedule.ScheduledPeriods, Is.Empty);
            });
        }

        [TestCase(0)]
        [TestCase(1)]
        public async Task Handle_ShouldCorrectlyMapSchedulesForLinearEmployees(int extraDays)
        {
            // Arrange
            var departmentDto = DepartmentDtoBuilder.Create().SetExtraDays(extraDays).BuildSimple(1);
            var employeeDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var vacationScheduleRepository = EntityRepositoryStub.Create(new VacationSchedule[0]);
            
            var handler = CreateHandler(vacationScheduleRepository, new[] {departmentDto},
                new[] {employeeDto});

            // Act
            await handler.HandleAsync(new BuildSchedulesCommand { ScheduleYear = ScheduleYear }, CancellationToken.None);

            // Assert
            var vacationSchedule = vacationScheduleRepository.Query().Single();
            Assert.That(vacationSchedule.UnitId, Is.EqualTo(departmentDto.Id));
            Assert.That(vacationSchedule.Name, Is.EqualTo($"График отпусков \"{departmentDto.Name}\""));
            Assert.That(vacationSchedule.Status, Is.EqualTo(ScheduleStatus.Formation));
            Assert.That(vacationSchedule.UnitType, Is.EqualTo(UnitType.Department));
            Assert.That(vacationSchedule.Year, Is.EqualTo(ScheduleYear));

            var employeeVacationSchedule = vacationSchedule.EmployeesSchedules.Single();
            AssertEmployeeVacationsScheduleEqualsEmployeeDto(employeeVacationSchedule, employeeDto, extraDays);
        }

        [Test]
        public async Task Handle_ShouldAddTeamScheduleWithTeamMembers()
        {
            // Arrange
            var departmentDto = DepartmentDtoBuilder.Create().BuildSimple(1);
            var teamMember1 = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var teamMember2 = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(2);
            var teamDto = ProviderTeamBuilder.Create(123)
                .WithMembers(teamMember1.Id, teamMember2.Id)
                .Build();
            var vacationScheduleRepository = EntityRepositoryStub.Create(new VacationSchedule[0]);

            var handler = CreateHandler(vacationScheduleRepository, new[] {departmentDto},
                new[] {teamMember1, teamMember2}, new [] {teamDto});

            // Act
            await handler.HandleAsync(new BuildSchedulesCommand {ScheduleYear = ScheduleYear}, CancellationToken.None);

            // Assert
            var allSchedules = vacationScheduleRepository.Query().ToList();
            var departmentSchedule =
                allSchedules.SingleOrDefault(vs => vs.UnitId == departmentDto.Id && vs.UnitType == UnitType.Department);
            Assert.That(departmentSchedule, Is.Null, "Empty department schedule should be skipped");
            
            var teamSchedule =
                allSchedules.SingleOrDefault(vs => vs.UnitId == teamDto.Id && vs.UnitType == UnitType.Team);
            Assert.That(teamSchedule, Is.Not.Null);
            Assert.That(teamSchedule.Name, Is.EqualTo($"График отпусков команды \"{teamDto.Name}\""));
            Assert.That(teamSchedule.Year, Is.EqualTo(ScheduleYear));
            Assert.That(teamSchedule.EmployeesSchedulesForInformation, Is.Empty);
            
            Assert.That(teamSchedule.EmployeesSchedules.Count, Is.EqualTo(2));
            var team1MemberSchedule = teamSchedule.EmployeesSchedules.Single(es => es.EmployeeNumber == teamMember1.Id);
            var team2MemberSchedule = teamSchedule.EmployeesSchedules.Single(es => es.EmployeeNumber == teamMember2.Id);
            AssertEmployeeVacationsScheduleEqualsEmployeeDto(team1MemberSchedule, teamMember1);
            AssertEmployeeVacationsScheduleEqualsEmployeeDto(team2MemberSchedule, teamMember2);
        }

        [Test]
        public async Task Handle_ShouldAddOTSScheduleToTheirDepartmentAndAddAsInformationalSchedulesToTeams()
        {
            // Arrange
            var departmentDto = DepartmentDtoBuilder.Create().BuildSimple(1);
            var ownerDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var techLeadDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(2);
            var scrumMasterDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(3);
            var team1Dto = ProviderTeamBuilder.Create(1)
                .WithMembers(ownerDto.Id, techLeadDto.Id)
                .WithOwners(ownerDto.Id)
                .WithTechLeads(techLeadDto.Id)
                .WithScrumMasters(scrumMasterDto.Id)
                .Build();
            var team2Dto = ProviderTeamBuilder.Create(2)
                .WithMembers(techLeadDto.Id, scrumMasterDto.Id)
                .WithOwners(ownerDto.Id)
                .WithTechLeads(techLeadDto.Id)
                .WithScrumMasters(scrumMasterDto.Id)
                .Build();
            var vacationScheduleRepository = EntityRepositoryStub.Create(new VacationSchedule[0]);

            var handler = CreateHandler(vacationScheduleRepository, new[] {departmentDto},
                new[] {ownerDto, techLeadDto, scrumMasterDto}, new[] {team1Dto, team2Dto});

            // Act
            await handler.HandleAsync(new BuildSchedulesCommand {ScheduleYear = ScheduleYear}, CancellationToken.None);

            // Assert
            var allSchedules = vacationScheduleRepository.Query().ToList();

            var team1Schedule =
                allSchedules.SingleOrDefault(vs => vs.UnitId == team1Dto.Id && vs.UnitType == UnitType.Team);
            Assert.That(team1Schedule, Is.Not.Null);
            Assert.That(team1Schedule.EmployeesSchedules, Is.Empty, "OTS Should be excluded from team members list");
            Assert.That(team1Schedule.ResponsibleManagers.Select(m => m.EmployeeNumber),
                Is.EquivalentTo(new[] {ownerDto.Id, techLeadDto.Id, scrumMasterDto.Id}),
                "OTS Should be added to responsible managers");
            Assert.That(team1Schedule.EmployeesSchedulesForInformation.Count, Is.EqualTo(3),
                "OTS should be present in EmployeesSchedulesForInformation set");
            var ownerSchedule = team1Schedule.EmployeesSchedulesForInformation.Single(es => es.EmployeeNumber == ownerDto.Id);
            var techLeadSchedule = team1Schedule.EmployeesSchedulesForInformation.Single(es => es.EmployeeNumber == techLeadDto.Id);
            var scrumMasterSchedule =
                team1Schedule.EmployeesSchedulesForInformation.Single(es => es.EmployeeNumber == scrumMasterDto.Id);

            AssertEmployeeVacationsScheduleEqualsEmployeeDto(ownerSchedule, ownerDto);
            AssertEmployeeVacationsScheduleEqualsEmployeeDto(techLeadSchedule, techLeadDto);
            AssertEmployeeVacationsScheduleEqualsEmployeeDto(scrumMasterSchedule, scrumMasterDto);

            var team2Schedule =
                allSchedules.SingleOrDefault(vs => vs.UnitId == team2Dto.Id && vs.UnitType == UnitType.Team);
            Assert.That(team2Schedule, Is.Not.Null);
            Assert.That(team2Schedule.EmployeesSchedules, Is.Empty);
            Assert.That(team2Schedule.EmployeesSchedulesForInformation,
                Is.EquivalentTo(team1Schedule.EmployeesSchedulesForInformation));

            var departmentSchedule =
                allSchedules.SingleOrDefault(vs => vs.UnitId == departmentDto.Id && vs.UnitType == UnitType.Department);
            Assert.That(departmentSchedule, Is.Not.Null, "Department schedule should be created for OTS");
            Assert.That(departmentSchedule.EmployeesSchedules,
                Is.EquivalentTo(team1Schedule.EmployeesSchedulesForInformation),
                "All OTS should be added to department's schedule");
            Assert.That(departmentSchedule.EmployeesSchedulesForInformation, Is.Empty,
                "No informational schedule should be added to department");
        }

        [Test]
        public async Task Handle_WhenEmployeeIsInMultipleTeams_ShouldAddToLinearAndToTeamsForInformation()
        {
            // Arrange
            var departmentDto = DepartmentDtoBuilder.Create().BuildSimple(1);
            var employeeDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var team1Dto = ProviderTeamBuilder.Create(1)
                .WithMembers(employeeDto.Id)
                .Build();
            var team2Dto = ProviderTeamBuilder.Create(2)
                .WithMembers(employeeDto.Id)
                .Build();
            var vacationScheduleRepository = EntityRepositoryStub.Create(new VacationSchedule[0]);

            var handler = CreateHandler(vacationScheduleRepository, new[] {departmentDto},
                new[] {employeeDto}, new[] {team1Dto, team2Dto});

            // Act
            await handler.HandleAsync(new BuildSchedulesCommand {ScheduleYear = ScheduleYear}, CancellationToken.None);

            // Assert
            var allSchedules = vacationScheduleRepository.Query().ToList();
            var departmentSchedule =
                allSchedules.SingleOrDefault(vs => vs.UnitId == departmentDto.Id && vs.UnitType == UnitType.Department);
            Assert.That(departmentSchedule, Is.Not.Null);
            Assert.That(departmentSchedule.EmployeesSchedules, Has.One.Items);
            var employeeSchedule = departmentSchedule.EmployeesSchedules.Single();
            AssertEmployeeVacationsScheduleEqualsEmployeeDto(employeeSchedule, employeeDto);

            var team1Schedule =
                allSchedules.SingleOrDefault(vs => vs.UnitId == team1Dto.Id && vs.UnitType == UnitType.Team);
            Assert.That(team1Schedule, Is.Not.Null);
            Assert.That(team1Schedule.EmployeesSchedules, Is.Empty, "Employee should be present in information only");
            Assert.That(team1Schedule.EmployeesSchedulesForInformation, Is.EquivalentTo(new[] {employeeSchedule}));

            var team2Schedule =
                allSchedules.SingleOrDefault(vs => vs.UnitId == team2Dto.Id && vs.UnitType == UnitType.Team);
            Assert.That(team2Schedule, Is.Not.Null);
            Assert.That(team2Schedule.EmployeesSchedules, Is.Empty);
            Assert.That(team2Schedule.EmployeesSchedulesForInformation, Is.EquivalentTo(new[] {employeeSchedule}));
        }
        
        [Test]
        public async Task Handle_WhenDepartmentHasAdminHead_ShouldSetHimAsManager()
        {
            // Arrange
            var departmentDto = DepartmentDtoBuilder.Create()
                .SetAdminHead(_manager1)
                .SetFuncHeads(_manager2)
                .BuildSimple(1);
            var parentDepartmentDto = DepartmentDtoBuilder.Create()
                .SetAdminHead(null)
                .SetFuncHeads(null)
                .AddChild(departmentDto)
                .BuildSimple(2);
            var employeeDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var vacationScheduleRepository = EntityRepositoryStub.Create(new VacationSchedule[0]);
            
            var handler = CreateHandler(vacationScheduleRepository, new[] {parentDepartmentDto},
                new[] {employeeDto, _manager1Employee, _manager2Employee});

            // Act
            await handler.HandleAsync(new BuildSchedulesCommand { ScheduleYear = ScheduleYear }, CancellationToken.None);

            // Assert
            var vacationSchedule = vacationScheduleRepository.Query().Single();
            var manager = vacationSchedule.ResponsibleManagers.SingleOrDefault();
            Assert.NotNull(manager);
            Assert.That(manager!.Login, Is.EqualTo(_manager1.Login));
            Assert.That(manager.EmployeeNumber, Is.EqualTo(_manager1.Id));
            Assert.That(manager.Email, Is.EqualTo(_manager1.Email));
            Assert.That(manager.Fio,
                Is.EqualTo(
                    $"{_manager1Employee.LastNameRus} {_manager1Employee.FirstNameRus} {_manager1Employee.MiddleNameRus}"));
        }
        
        [Test]
        public async Task Handle_WhenDepartmentHasNoAdminHead_ShouldSetFuncAsManagers()
        {
            // Arrange
            var departmentDto = DepartmentDtoBuilder.Create()
                .SetAdminHead(null)
                .SetFuncHeads(_manager1, _manager2)
                .BuildSimple(1);
            var parentDepartmentDto = DepartmentDtoBuilder.Create()
                .SetAdminHead(null)
                .SetFuncHeads(null)
                .AddChild(departmentDto)
                .BuildSimple(2);
            var employeeDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var vacationScheduleRepository = EntityRepositoryStub.Create(new VacationSchedule[0]);
            
            var handler = CreateHandler(vacationScheduleRepository, new[] {parentDepartmentDto},
                new[] {employeeDto, _manager1Employee, _manager2Employee});

            // Act
            await handler.HandleAsync(new BuildSchedulesCommand { ScheduleYear = ScheduleYear }, CancellationToken.None);

            // Assert
            var vacationSchedule = vacationScheduleRepository.Query().Single();
            var managerIds = vacationSchedule.ResponsibleManagers.Select(m => m.EmployeeNumber);
            Assert.That(managerIds, Is.EquivalentTo(new[] {_manager1.Id, _manager2.Id}));
        }
        
        [Test]
        public async Task Handle_WhenDepartmentHasNoHeads_ShouldSetAdminHeadFromParentAsManager()
        {
            // Arrange
            var departmentDto = DepartmentDtoBuilder.Create()
                .SetAdminHead(null)
                .SetFuncHeads(null)
                .BuildSimple(1);
            var parentDepartmentDto = DepartmentDtoBuilder.Create()
                .SetAdminHead(_manager1)
                .SetFuncHeads(_manager2)
                .AddChild(departmentDto)
                .BuildSimple(2);
            var employeeDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var vacationScheduleRepository = EntityRepositoryStub.Create(new VacationSchedule[0]);
            
            var handler = CreateHandler(vacationScheduleRepository, new[] {parentDepartmentDto},
                new[] {employeeDto, _manager1Employee, _manager2Employee});

            // Act
            await handler.HandleAsync(new BuildSchedulesCommand { ScheduleYear = ScheduleYear }, CancellationToken.None);

            // Assert
            var vacationSchedule = vacationScheduleRepository.Query().Single();
            var manager = vacationSchedule.ResponsibleManagers.SingleOrDefault();
            Assert.NotNull(manager);
            Assert.That(manager!.Login, Is.EqualTo(_manager1.Login));
            Assert.That(manager.EmployeeNumber, Is.EqualTo(_manager1.Id));
            Assert.That(manager.Email, Is.EqualTo(_manager1.Email));
            Assert.That(manager.Fio,
                Is.EqualTo(
                    $"{_manager1Employee.LastNameRus} {_manager1Employee.FirstNameRus} {_manager1Employee.MiddleNameRus}"));
        }

        [Test]
        public async Task Handle_WhenDepartmentHasNoHeads_AndParentHasNoAdmin_ShouldSetFuncHeadsFromParentAsManagers()
        {
            // Arrange
            var departmentDto = DepartmentDtoBuilder.Create()
                .SetAdminHead(null)
                .SetFuncHeads(null)
                .BuildSimple(1);
            var parentDepartmentDto = DepartmentDtoBuilder.Create()
                .SetAdminHead(null)
                .SetFuncHeads(_manager2, _manager1)
                .AddChild(departmentDto)
                .BuildSimple(2);
            var employeeDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var vacationScheduleRepository = EntityRepositoryStub.Create(new VacationSchedule[0]);
            
            var handler = CreateHandler(vacationScheduleRepository, new[] {parentDepartmentDto},
                new[] {employeeDto, _manager1Employee, _manager2Employee});

            // Act
            await handler.HandleAsync(new BuildSchedulesCommand { ScheduleYear = ScheduleYear }, CancellationToken.None);

            // Assert
            var vacationSchedule = vacationScheduleRepository.Query().Single();
            var managerIds = vacationSchedule.ResponsibleManagers.Select(m => m.EmployeeNumber);
            Assert.That(managerIds, Is.EquivalentTo(new[] {_manager1.Id, _manager2.Id}));
        }
    }
}
