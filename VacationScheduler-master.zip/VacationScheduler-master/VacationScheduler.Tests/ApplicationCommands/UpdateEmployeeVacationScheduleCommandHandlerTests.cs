﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using VacationScheduler.Application.Commands.UpdateEmployeeVacationSchedule;
using VacationScheduler.Application.Exceptions;
using VacationScheduler.Domain.Dto;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Domain.Exceptions;
using VacationScheduler.Domain.Services.PermissionService;
using VacationScheduler.Domain.Services.UserService;
using VacationScheduler.Domain.Validation.Applications;
using VacationScheduler.Tests.EntityFactories;
using VacationScheduler.Tests.Stubs;
using ViennaNET.Orm.Application;
using ViennaNET.TestUtils.Orm;
using ViennaNET.Validation.Rules;
using ViennaNET.Validation.Rules.ValidationResults;
using ViennaNET.Validation.Rules.ValidationResults.RuleMessages;
using ViennaNET.Validation.Validators;

namespace VacationScheduler.Tests.ApplicationCommands
{
    [TestFixture]
    public class UpdateEmployeeVacationScheduleCommandHandlerTests
    {
        private static readonly IUser currentUser = UserBuilder.Create().WithLogin("rualogin").Build();
        private static readonly DateTime today = DateTime.Today;
        private static readonly VacationPeriod period = new VacationPeriod { From = today, To = today, Type = PeriodType.ByDays };
        private static readonly EmployeeVacationSchedule employeeSchedule = new EmployeeVacationSchedule
        {
            ScheduledPeriods = new HashSet<VacationPeriod>
            {
                period
            },
            Id = 1
        };
        private static readonly EmployeeVacationSchedule secondEmployeeSchedule = new EmployeeVacationSchedule
        {
            ScheduledPeriods = new HashSet<VacationPeriod>
            {
                period
            },
            Id = 2
        };
        private static readonly EmployeeVacationSchedule employeeScheduleNoPeriods = new EmployeeVacationSchedule
        {
            ScheduledPeriods = new HashSet<VacationPeriod>(),
            Id = 3
        };

        public static IValidator CreateIValidator(bool isValid = true)
        {
            var validator = new Mock<IValidator>(MockBehavior.Strict);
            ValidationResult res;
            if (isValid)
            {
                res = new ValidationResult();
            }
            else
            {
                var identity = new RuleIdentity("Mock");
                var ruleValidationResult = new RuleValidationResult(identity);
                ruleValidationResult.Messages.Add(
                    new ErrorRuleMessage(new MessageIdentity("Mock"), "ValidationErrorText"));
                res = new ValidationResult { Results = { ruleValidationResult } };
            }

            validator.Setup(v => v.Validate(
                    It.IsAny<IValidationRuleSet<UpdateEmployeeScheduleDto>>(),
                    It.IsAny<UpdateEmployeeScheduleDto>(), It.IsAny<ValidationContext>()))
                .Returns(res);

            return validator.Object;
        }

        private static UpdateEmployeeVacationScheduleCommandHandler CreateHandler(
            IEnumerable<VacationSchedule>? vacationSchedules = null)
        {
            var entityFactoryService = EntityFactoryServiceStubBuilder.Create()
                .WithRepository(EntityRepositoryStub.Create(vacationSchedules ?? new List<VacationSchedule>()))
                .Build();

            return new UpdateEmployeeVacationScheduleCommandHandler(entityFactoryService, CreateIValidator(true),
                Mock.Of<IUpdateEmployeeScheduleRuleSet>(), Mock.Of<IUserRepository>(), Mock.Of<IPermissionService>());
        }

        private static UpdateEmployeeVacationScheduleCommandHandler CreateHandler(
            IEntityFactoryService entityFactoryService, bool isValidatorValid = true, bool hasEditPermission = true)
        {
            var allEmployeeSchedules = entityFactoryService.Create<VacationSchedule>()
                .Query()
                .SelectMany(vs => vs.EmployeesSchedules);

            var permissionServiceBuilder = PermissionServiceStubBuilder.Create();
            var actions = hasEditPermission
                ? new[] { EmployeeScheduleAction.Edit }
                : Array.Empty<EmployeeScheduleAction>();
            foreach (var es in allEmployeeSchedules)
            {
                permissionServiceBuilder.WithEmployeeScheduleActions(es, currentUser, actions);
            }

            return new UpdateEmployeeVacationScheduleCommandHandler(entityFactoryService,
                CreateIValidator(isValidatorValid), Mock.Of<IUpdateEmployeeScheduleRuleSet>(),
                UserRepositoryBuilder.CreateRepositoryWithCurrentUser(currentUser), permissionServiceBuilder.Build());
        }

        private static IEntityFactoryService CreateFactoryService(
            IReadOnlyCollection<VacationSchedule> vacationSchedules)
        {
            var employeeVacationSchedules = vacationSchedules.SelectMany(v => v.EmployeesSchedules).ToList();
            var periods = employeeVacationSchedules.SelectMany(s => s.ScheduledPeriods);
            var entityFactoryService = EntityFactoryServiceStubBuilder.Create()
                .WithRepository(EntityRepositoryStub.Create(vacationSchedules))
                .WithRepository(EntityRepositoryStub.Create(employeeVacationSchedules))
                .WithRepository(EntityRepositoryStub.Create(periods))
                .Build();
            return entityFactoryService;
        }

        [Test]
        public void HandleAsync_WhenScheduleNotExist_ShouldThrow()
        {
            // Arrange
            var handler = CreateHandler();

            // Act
            // Assert
            var ex = Assert.ThrowsAsync<DbObjectNotFoundException>(async () =>
                await handler.HandleAsync(new UpdateEmployeeVacationScheduleCommand { VacationScheduleId = 1 },
                    CancellationToken.None));

            Assert.That(ex.Message, Is.EqualTo("Не найден график отпусков с Id = 1"));
        }

        [Test]
        public void HandleAsync_WhenEmployeeScheduleNotExist_ShouldThrow()
        {
            // Arrange
            var schedule = new VacationSchedule();
            var handler = CreateHandler(new[] { schedule });

            // Act
            // Assert
            var ex = Assert.ThrowsAsync<DbObjectNotFoundException>(async () =>
                await handler.HandleAsync(
                    new UpdateEmployeeVacationScheduleCommand
                    {
                        VacationScheduleId = schedule.Id, EmployeeVacationScheduleId = 404
                    },
                    CancellationToken.None));

            Assert.That(ex.Message, Is.EqualTo($"Не найден график отпусков сотрудника с Id = 404"));
        }
        
        [Test]
        public void HandleAsync_WhenUserHasNoPermissionToEdit_ShouldThrow()
        {
            // Arrange
            var vacationSchedule = new VacationSchedule
            {
                EmployeesSchedules = new HashSet<EmployeeVacationSchedule> { employeeSchedule, secondEmployeeSchedule }
            };
            
            var entityFactoryService = CreateFactoryService(new[] { vacationSchedule });
            var handler = CreateHandler(entityFactoryService, hasEditPermission: false);

            // Act
            async Task Act()
            {
                await handler.HandleAsync(
                    new UpdateEmployeeVacationScheduleCommand { EmployeeVacationScheduleId = employeeSchedule.Id },
                    CancellationToken.None);
            }
            // Assert
            var ex = Assert.ThrowsAsync<PermissionException>(Act);
            Assert.That(ex.Message,
                Contains.Substring(
                    $"User {currentUser.Login} has no permission to update schedule for employee {employeeSchedule.EmployeeNumber}"));
        }

        [Test]
        public void HandleAsync_WhenScheduleIsNotValid_ShouldThrow()
        {
            // Arrange
            var vacationSchedule = new VacationSchedule
            {
                EmployeesSchedules = new HashSet<EmployeeVacationSchedule> { employeeSchedule, secondEmployeeSchedule }
            };
            
            var entityFactoryService = CreateFactoryService(new[] { vacationSchedule });
            var handler = CreateHandler(entityFactoryService, false);

            // Act
            // Assert
            var ex = Assert.ThrowsAsync<EmployeeVacationScheduleValidationErrorException>(async () =>
                await handler.HandleAsync(
                    new UpdateEmployeeVacationScheduleCommand
                    {
                        EmployeeVacationScheduleId = employeeSchedule.Id,
                        ScheduledPeriods = new List<VacationPeriod>()
                    },
                    CancellationToken.None));

            Assert.That(ex.Message, Is.EqualTo("ValidationErrorText"));
        }

        [Test]
        public async Task HandleAsync_WhenScheduleHasPeriods_ShouldClear()
        {
            // Arrange
            var vacationSchedule = new VacationSchedule
            {
                EmployeesSchedules = new HashSet<EmployeeVacationSchedule> { employeeSchedule, secondEmployeeSchedule }
            };

            var command = new UpdateEmployeeVacationScheduleCommand
            {
                EmployeeVacationScheduleId = employeeSchedule.Id,
                VacationScheduleId = vacationSchedule.Id,
                ScheduledPeriods = new List<VacationPeriod>()
            };
            var entityFactoryService = CreateFactoryService(new[] { vacationSchedule });
            var handler = CreateHandler(entityFactoryService);

            // Act
            await handler.HandleAsync(command, CancellationToken.None);

            // Assert
            Assert.That(employeeSchedule.ScheduledPeriods, Is.Empty);
        }

        [Test]
        public async Task HandleAsync_WhenScheduleHasNoPeriods_ShouldAdd()
        {
            // Arrange
            var existingVacationSchedule = new VacationSchedule
            {
                EmployeesSchedules = new HashSet<EmployeeVacationSchedule> { employeeScheduleNoPeriods }
            };
            var command = new UpdateEmployeeVacationScheduleCommand
            {
                EmployeeVacationScheduleId = employeeScheduleNoPeriods.Id,
                VacationScheduleId = existingVacationSchedule.Id,
                ScheduledPeriods = new List<VacationPeriod> { period }
            };
            var entityFactoryService = CreateFactoryService(new[] { existingVacationSchedule });
            var handler = CreateHandler(entityFactoryService);

            // Act
            await handler.HandleAsync(command, CancellationToken.None);

            // Assert
            var employeeVacationSchedule = existingVacationSchedule.EmployeesSchedules.Single();
            Assert.That(employeeVacationSchedule, Is.Not.Null);
            Assert.That(employeeVacationSchedule.ScheduledPeriods, Is.Not.Empty);
            var scheduledPeriod = employeeVacationSchedule.ScheduledPeriods.Single();
            Assert.That(scheduledPeriod.From, Is.EqualTo(period.From));
            Assert.That(scheduledPeriod.To, Is.EqualTo(period.To));
            Assert.That(scheduledPeriod.Type, Is.EqualTo(period.Type));
        }

        [Test]
        public async Task HandleAsync_WhenScheduleHasPeriod_ShouldChange()
        {
            // Arrange
            var existingVacationSchedule = new VacationSchedule
            {
                EmployeesSchedules = new HashSet<EmployeeVacationSchedule> { employeeSchedule }
            };
            var newPeriod =
                new VacationPeriod { From = today.AddDays(-1), To = today.AddDays(1), Type = PeriodType.OneWeek };
            var command = new UpdateEmployeeVacationScheduleCommand
            {
                EmployeeVacationScheduleId = employeeSchedule.Id,
                VacationScheduleId = existingVacationSchedule.Id,
                ScheduledPeriods = new List<VacationPeriod> { newPeriod }
            };
            var entityFactoryService = CreateFactoryService(new[] { existingVacationSchedule });
            var handler = CreateHandler(entityFactoryService);

            // Act
            await handler.HandleAsync(command, CancellationToken.None);

            // Assert
            var employeeVacationSchedule = existingVacationSchedule.EmployeesSchedules.Single();
            var scheduledPeriod = employeeVacationSchedule.ScheduledPeriods.Single();
            Assert.That(scheduledPeriod.From, Is.EqualTo(newPeriod.From));
            Assert.That(scheduledPeriod.To, Is.EqualTo(newPeriod.To));
            Assert.That(scheduledPeriod.Type, Is.EqualTo(newPeriod.Type));
        }
    }
}
