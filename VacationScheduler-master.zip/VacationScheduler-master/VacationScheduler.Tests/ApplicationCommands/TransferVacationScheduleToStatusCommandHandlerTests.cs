﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using NUnit.Framework;
using VacationScheduler.Application.Commands.TransferVacationScheduleToStatusCommand;
using VacationScheduler.Application.Exceptions;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Domain.Services.PermissionService;
using VacationScheduler.Tests.EntityFactories;
using ViennaNET.Orm.Application;
using ViennaNET.TestUtils.Orm;
using ViennaNET.Utils;
// ReSharper disable StringLiteralTypo

namespace VacationScheduler.Tests.ApplicationCommands
{
    [TestFixture]
    public class TransferVacationScheduleToStatusCommandHandlerTests
    {
        private static VacationSchedule CreateVacationSchedule(ScheduleStatus status)
        {
            return VacationScheduleBuilder.Create().SetStatus(status).Build();
        }

        private static IEntityFactoryService CreateFactoryServiceStub(VacationSchedule? vacationSchedule = null)
        {
            return EntityFactoryServiceStubBuilder.Create()
                .WithRepository(EntityRepositoryStub.Create<VacationSchedule, int>(vacationSchedule.Return(schedule => new[] { schedule }) ?? new VacationSchedule[] { }))
                .Build();
        }

        private static TransferVacationScheduleToStatusCommand CreateCommand(int applicationId, ScheduleStatus status)
        {
            return new TransferVacationScheduleToStatusCommand { VacationScheduleId = applicationId, DesiredStatus = status };
        }

        private static TransferVacationScheduleToStatusCommandHandler CreateHandler(IEntityFactoryService entityFactoryService, IEnumerable<VacationScheduleAction>? actions = null)
        {
            var user = UserBuilder.Create().Build();
            var userRepository = UserRepositoryBuilder.CreateRepositoryWithCurrentUser(user);

            var permissionServiceMock = new Mock<IPermissionService>(MockBehavior.Strict);
            permissionServiceMock.Setup(p => p.GetVacationScheduleActions(It.IsAny<VacationSchedule>(), user))
                .Returns(actions ?? new List<VacationScheduleAction>());
            
            return new TransferVacationScheduleToStatusCommandHandler(entityFactoryService, permissionServiceMock.Object, userRepository, new NullLogger<TransferVacationScheduleToStatusCommandHandler>());
        }


        private static readonly List<(VacationScheduleAction action, ScheduleStatus statusFrom, ScheduleStatus statusTo)>
            allowedActionsForStatusTransfers = new List<(VacationScheduleAction action, ScheduleStatus statusFrom, ScheduleStatus statusTo)>()
            {
                (VacationScheduleAction.ToManagerApprove, ScheduleStatus.Formation, ScheduleStatus.ManagerApprovement),
                (VacationScheduleAction.ToHrApprove, ScheduleStatus.ManagerApprovement, ScheduleStatus.HrApprovement),
                (VacationScheduleAction.Approve, ScheduleStatus.HrApprovement, ScheduleStatus.Approved),
                (VacationScheduleAction.ToFormation,ScheduleStatus.ManagerApprovement,ScheduleStatus.Formation)
            };


        private static IEnumerable<(ScheduleStatus statusFrom, ScheduleStatus statusTo)> GetAllPossibleStatusPairs()
        {
            var allStatuses = Enum.GetValues(typeof(ScheduleStatus)).OfType<ScheduleStatus>().ToArray();

            return allStatuses.SelectMany(from => allStatuses.Select(to => (from, to)));
        }


        [TestCaseSource(nameof(allowedActionsForStatusTransfers))]
        public async Task Handle_UserHasPermission_AndCorrectTransferRequested_ShouldChangeStatus((VacationScheduleAction action, ScheduleStatus statusFrom, ScheduleStatus statusTo) allowedAction)
        {
            // Arrange
            var (action, statusFrom, statusTo) = allowedAction;
            var vacationSchedule = CreateVacationSchedule(statusFrom);
            var entityFactoryService = CreateFactoryServiceStub(vacationSchedule);
            var transferVacationScheduleToStatusCommand = CreateCommand(vacationSchedule.Id, statusTo);
            var handler = CreateHandler(entityFactoryService, new[] { action });

            // Act
            await handler.HandleAsync(transferVacationScheduleToStatusCommand, CancellationToken.None);

            // Assert
            Assert.That(vacationSchedule.Status, Is.EqualTo(statusTo));
        }

        [TestCaseSource(nameof(allowedActionsForStatusTransfers))]
        public void Handle_CorrectTransferRequested_ButUserHasNoPermission_ShouldThrow((VacationScheduleAction action, ScheduleStatus statusFrom, ScheduleStatus statusTo) allowedAction)
        {
            // Arrange
            var noActionsAllowed = new VacationScheduleAction[0];
            var (_, statusFrom, statusTo) = allowedAction;
            var vacationSchedule = CreateVacationSchedule(statusFrom);
            var entityFactoryService = CreateFactoryServiceStub(vacationSchedule);
            var transferSickLeaveToStatusCommand = CreateCommand(vacationSchedule.Id, statusTo);
            var handler = CreateHandler(entityFactoryService, noActionsAllowed);

            // Act
            async Task Act()
            {
                await handler.HandleAsync(transferSickLeaveToStatusCommand, CancellationToken.None);
            }

            // Assert
            var exception = Assert.ThrowsAsync<PermissionException>(Act);
            Assert.That(exception.Message,
                Contains.Substring($"Нет прав для операции перехода графика с VacationScheduleId - {vacationSchedule.Id} из статуса {statusFrom} в статус {statusTo}"));
        }

        [TestCaseSource(nameof(GetAllPossibleStatusPairs))]
        public void Handle_UserHasFullPermissions_ButInvalidTransferRequested_ShouldThrow((ScheduleStatus statusFrom, ScheduleStatus statusTo) statusTransfer)
        {
            //skip allowed status transfers
            var (statusFrom, statusTo) = statusTransfer;
            if (allowedActionsForStatusTransfers.Any(allowed =>
                allowed.statusFrom == statusFrom && allowed.statusTo == statusTo))
            {
                Assert.Pass();
                return;
            }

            // Arrange
            VacationScheduleAction[] allActionsAllowed =
            {
                VacationScheduleAction.ToFormation, VacationScheduleAction.ToManagerApprove,
                VacationScheduleAction.ToHrApprove, VacationScheduleAction.Approve
            };

            var vacationSchedule = CreateVacationSchedule(statusFrom);
            var entityFactoryService = CreateFactoryServiceStub(vacationSchedule);
            var transferSickLeaveToStatusCommand = CreateCommand(vacationSchedule.Id, statusTo);
            var handler = CreateHandler(entityFactoryService, allActionsAllowed);

            // Act
            async Task Act()
            {
                await handler.HandleAsync(transferSickLeaveToStatusCommand, CancellationToken.None);
            }

            // Assert
            var exception = Assert.ThrowsAsync<TransferVacationScheduleException>(Act);
            Assert.That(exception.Message, Contains.Substring($"Для графика с VacationScheduleId - {vacationSchedule.Id} не разрешён переход из статуса {statusFrom} в статус {statusTo}"));
        }

        [Test]
        public void Handle_VacationScheduleNotFound_ShouldThrowVacationScheduleNotFoundException()
        {
            // Arrange
            var notExistingApplicationId = 404;
            var entityFactoryService = CreateFactoryServiceStub();
            var transferSickLeaveToStatusCommand = CreateCommand(notExistingApplicationId, ScheduleStatus.Approved);
            var handler = CreateHandler(entityFactoryService);

            // Act
            async Task Act()
            {
                await handler.HandleAsync(transferSickLeaveToStatusCommand, CancellationToken.None);
            }

            // Assert
            var exception = Assert.ThrowsAsync<DbObjectNotFoundException>(Act);
            Assert.That(exception.Message, Contains.Substring($"График с VacationScheduleId - {notExistingApplicationId} не найден в БД"));
        }
    }
}
