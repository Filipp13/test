﻿using Moq;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Services.PermissionService;
using VacationScheduler.Domain.Services.UserService;

namespace VacationScheduler.Tests.Stubs
{
    public class PermissionServiceStubBuilder
    {
        private readonly Mock<IPermissionService>
            _permissionService = new Mock<IPermissionService>(MockBehavior.Strict);

        private PermissionServiceStubBuilder()
        {
        }

        public static PermissionServiceStubBuilder Create() => new PermissionServiceStubBuilder();

        public PermissionServiceStubBuilder WithVacationScheduleActions(VacationSchedule schedule,
            IUser user, params VacationScheduleAction[] actions)
        {
            _permissionService.Setup(p => p.GetVacationScheduleActions(schedule, user))
                .Returns(actions);

            return this;
        }

        public PermissionServiceStubBuilder WithEmployeeScheduleActions(EmployeeVacationSchedule employeeSchedule,
            IUser user, params EmployeeScheduleAction[] actions)
        {
            _permissionService.Setup(p => p.GetEmployeeScheduleActions(employeeSchedule, user))
                .Returns(actions);

            return this;
        }

        public IPermissionService Build() => _permissionService.Object;
    }
}
