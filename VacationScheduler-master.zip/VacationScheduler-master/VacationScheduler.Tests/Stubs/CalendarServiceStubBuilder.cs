﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using VacationScheduler.Domain.Services.CalendarService;

namespace VacationScheduler.Tests.Stubs
{
    public class CalendarServiceStubBuilder
    {
        private readonly Dictionary<int, ICollection<DateTime>> _holidays = new Dictionary<int, ICollection<DateTime>>();
        private readonly Dictionary<int, ICollection<DateTime>> _dayOffs = new Dictionary<int, ICollection<DateTime>>();
        
        private CalendarServiceStubBuilder()
        {
        }

        public static CalendarServiceStubBuilder Create() => new CalendarServiceStubBuilder();

        public ICalendarService Build() => new CalendarServiceStub(_holidays, _dayOffs);

        public CalendarServiceStubBuilder WithHolidays(int calendarId, params DateTime[] dates)
        {
            _holidays.Add(calendarId, dates.ToHashSet());

            return this;
        }

        public CalendarServiceStubBuilder WithDayOffs(int calendarId, params DateTime[] dates)
        {
            _dayOffs.Add(calendarId, dates.ToHashSet());

            return this;
        }

        private class CalendarServiceStub : ICalendarService
        {
            private readonly IDictionary<int, ICollection<DateTime>> _holidays;
            private readonly IDictionary<int, ICollection<DateTime>> _dayOffs;

            public CalendarServiceStub(IDictionary<int, ICollection<DateTime>> holidays, IDictionary<int, ICollection<DateTime>> dayOffs)
            {
                _holidays = holidays;
                _dayOffs = dayOffs;
            }

            public Task<List<CalendarDate>> GetHolidayDatesAsync(int year, CancellationToken cancellationToken)
            {
                var holidayDates = new List<CalendarDate>();
                foreach (var calendar in _holidays)
                {
                    holidayDates.AddRange(calendar.Value.Select(d => new CalendarDate{CalendarId = calendar.Key, Date = d}));
                }
                return Task.FromResult<List<CalendarDate>>(holidayDates);
            }

            public bool IsHoliday(DateTime date, int calendarId)
            {
                if (!_holidays.ContainsKey(calendarId))
                {
                    return false;
                }
                return _holidays[calendarId].Contains(date);
            }

            public bool IsWorkingDay(DateTime date, int calendarId)
            {
                if (!_holidays.ContainsKey(calendarId) || !_dayOffs.ContainsKey(calendarId))
                {
                    return true;
                }
                return !_holidays[calendarId].Contains(date) && !_dayOffs[calendarId].Contains(date);
            }
        }
    }
}
