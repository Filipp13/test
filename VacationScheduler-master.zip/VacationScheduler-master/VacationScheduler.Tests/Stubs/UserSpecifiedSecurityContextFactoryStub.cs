﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViennaNET.Security;

namespace VacationScheduler.Tests.Stubs
{
    internal class UserSpecifiedSecurityContextFactoryStub : ISecurityContextFactory
    {
        private readonly string _userName;

        public UserSpecifiedSecurityContextFactoryStub(string userName)
        {
            _userName = userName;
        }

        public ISecurityContext Create()
        {
            return CreateAsync().Result;
        }

        public Task<ISecurityContext> CreateAsync()
        {
            return Task.FromResult<ISecurityContext>(new SecurityContext(_userName, "", new string[] { }));
        }

        private class SecurityContext : ISecurityContext
        {
            private readonly string[] _permissions;

            public SecurityContext(string name, string ip, string[] permissions)
            {
                UserName = name;
                UserIp = ip;
                _permissions = permissions;
            }

            public Task<bool> HasPermissionsAsync(params string[] permissions)
            {
                return Task.FromResult(_permissions.Any(permissions.Contains));
            }

            public Task<IEnumerable<string>> GetUserPermissionsAsync()
            {
                throw new System.NotImplementedException();
            }

            public string UserName { get; }

            public string UserIp { get; }
        }
    }
}
