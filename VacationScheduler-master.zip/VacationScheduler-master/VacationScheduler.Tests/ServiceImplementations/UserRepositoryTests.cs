﻿using System.Linq;
using System.Threading.Tasks;
using HrManagerPermissions.Client;
using HrManagerPermissions.Client.Dto;
using Moq;
using NUnit.Framework;
using VacationScheduler.Api.ServicesImplementations;
using VacationScheduler.Tests.Stubs;

namespace VacationScheduler.Tests.ServiceImplementations
{
    [TestFixture]
    internal class UserRepositoryTests
    {
        private const string UserLogin = "ruapus9";
        private readonly string[] IsHrForEmployeesNumbers = {"01234", "02121" };
        private const string someOtherEmployeeNumber = "99999";

        private static IHrManagerPermissionsClient CreateHrManagerPermissionsClientWithHrForEmployees(string[] hrForEmployeesNumbers)
        {
            var hrPermissionDtos = hrForEmployeesNumbers.Select(login => new HrPermissionDto {EmployeeNumber = login})
                .ToList();

            var hrManagerPermissionsClientMock = new Mock<IHrManagerPermissionsClient>();
            hrManagerPermissionsClientMock.Setup(h => h.GetHrUserPermissionsAsync(UserLogin))
                .ReturnsAsync(hrPermissionDtos);
            
            return hrManagerPermissionsClientMock.Object;
        }
        
        [Test]
        public async Task GetUser_ShouldReturnCorrectUser()
        {
            // Arrange
            var hrManagerPermissionsClientMock = CreateHrManagerPermissionsClientWithHrForEmployees(IsHrForEmployeesNumbers);

            var userRepository = new UserRepository(hrManagerPermissionsClientMock,
                new UserSpecifiedSecurityContextFactoryStub(UserLogin));

            // Act
            var user = await userRepository.GetUserAsync(UserLogin);

            // Assert
            Assert.That(user, Is.Not.Null);
            
            Assert.That(user.Login, Is.EqualTo(UserLogin));

            Assert.That(user.IsHrForEmployee(IsHrForEmployeesNumbers[0]), Is.True);
            Assert.That(user.IsHrForEmployee(IsHrForEmployeesNumbers[1]), Is.True);
            Assert.That(user.IsHrForEmployee(someOtherEmployeeNumber), Is.False);
            Assert.That(user.IsHr, Is.True);
            Assert.That(user.GetEmployeeNumbersWhereHr(), Is.Not.Empty);
            Assert.That(user.GetEmployeeNumbersWhereHr().Count(), Is.EqualTo(IsHrForEmployeesNumbers.Length));
        }
        
        [Test]
        public async Task GetCurrentUser_ShouldReturnCorrectUser()
        {
            // Arrange
            var hrManagerPermissionsClientMock = CreateHrManagerPermissionsClientWithHrForEmployees(IsHrForEmployeesNumbers);

            var userRepository = new UserRepository(hrManagerPermissionsClientMock,
                new UserSpecifiedSecurityContextFactoryStub(UserLogin));

            // Act
            var user = await userRepository.GetCurrentUserAsync();

            // Assert
            Assert.That(user, Is.Not.Null);
            
            Assert.That(user.Login, Is.EqualTo(UserLogin));

            Assert.That(user.IsHrForEmployee(IsHrForEmployeesNumbers[0]), Is.True);
            Assert.That(user.IsHrForEmployee(IsHrForEmployeesNumbers[1]), Is.True);
            Assert.That(user.IsHrForEmployee(someOtherEmployeeNumber), Is.False);
            Assert.That(user.IsHr, Is.True);
            Assert.That(user.GetEmployeeNumbersWhereHr(), Is.Not.Empty);
            Assert.That(user.GetEmployeeNumbersWhereHr().Count(), Is.EqualTo(IsHrForEmployeesNumbers.Length));
        }
    }
}
