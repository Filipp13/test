﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;
using VacationScheduler.Api.Helpers;
using VacationScheduler.Api.ServicesImplementations;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Domain.Services.CalendarService;
using ViennaNET.TestUtils.Orm;

namespace VacationScheduler.Tests.ServiceImplementations
{
    [TestFixture]
    class CalendarServiceTests
    {
        private HolidayDate[] holidayDates => new HolidayDate[]
        {
            new HolidayDate{CalendarId = 1, HolidayDateValue = new DateTime(2021,1,1) , CalendarDayType = CalendarDayType.Holiday},
            new HolidayDate{CalendarId = 1, HolidayDateValue = new DateTime(2022,1,1) , CalendarDayType = CalendarDayType.Holiday}
        };

        private static HolidayDate CreateHoliday(int calendarId, DateTime date) => new HolidayDate()
        {
            CalendarId = calendarId, CalendarDayType = CalendarDayType.Holiday, HolidayDateValue = date
        };
        
        private static HolidayDate CreateDayOff(int calendarId, DateTime date) => new HolidayDate()
        {
            CalendarId = calendarId, CalendarDayType = CalendarDayType.Dayoff, HolidayDateValue = date
        };

        private static IMemoryCache CreateInMemoryCache() => new MemoryCache(new MemoryCacheOptions());

        [Test]
        public async Task GetHolidayDates_WhenGetData_ShouldFilteredByYear()
        {
            // Arrange
            var entityRepositoryFactory =  EntityFactoryServiceStubBuilder.Create()
                .WithRepository(EntityRepositoryStub.Create(holidayDates))
                .Build();

            var cache = CreateInMemoryCache();

            var calendarService = new CalendarService(entityRepositoryFactory, cache);

            // Act
            var result = await calendarService.GetHolidayDatesAsync(2021, CancellationToken.None);

            // Assert
            var cachedValue = cache.Get<List<CalendarDate>>(CacheHelper.GetHolidayCalendarDatesCacheKey(2021));
            Assert.That(result.Count, Is.EqualTo(1), "Dates were not filtered by year");
        }

        [Test]
        public async Task GetHolidayDates_WhenCacheIsEmpty_ShouldSetCache()
        {
            // Arrange
            var entityRepositoryFactory =  EntityFactoryServiceStubBuilder.Create()
                .WithRepository(EntityRepositoryStub.Create(holidayDates))
                .Build();

            var cache = CreateInMemoryCache();

            var calendarService = new CalendarService(entityRepositoryFactory, cache);

            // Act
            var result = await calendarService.GetHolidayDatesAsync(2021, CancellationToken.None);

            // Assert
            var cachedValue = cache.Get<List<CalendarDate>>(CacheHelper.GetHolidayCalendarDatesCacheKey(2021));
            Assert.That(result.Count, Is.EqualTo(1), "Dates were not filtered by year");
            Assert.That(cachedValue.Count, Is.EqualTo(result.Count), "Values were not cached");
        }
        
        [Test]
        public async Task GetHolidayDates_WhenCacheIsNotEmpty_ShouldUseCache()
        {
            // Arrange
            var entityRepositoryFactory =  EntityFactoryServiceStubBuilder.Create()
                .WithRepository(EntityRepositoryStub.Create(new HolidayDate[]{}))
                .Build();

            var cache = CreateInMemoryCache();
            cache.Set(CacheHelper.GetHolidayCalendarDatesCacheKey(2021), 
                holidayDates.Select(hd => new CalendarDate
                    {
                        CalendarId = hd.CalendarId,
                        Date = hd.HolidayDateValue
                    }).ToList());
            var calendarService = new CalendarService(entityRepositoryFactory, cache);

            // Act
            var result = await calendarService.GetHolidayDatesAsync(2021, CancellationToken.None);

            // Assert
            Assert.That(result.Count, Is.EqualTo(holidayDates.Length), "No cache used");
        }
        
        [Test]
        public void IsHoliday_WhenThereAreDifferentCalendars_ShouldReturnCorrectHolidayForCalendar()
        {
            // Arrange
            var may1 = new DateTime(2022, 5, 1);
            var may2 = new DateTime(2022, 5, 2);
            var may3 = new DateTime(2022, 5, 3);

            var entityRepositoryFactory = EntityFactoryServiceStubBuilder.Create()
                .WithRepository(EntityRepositoryStub.Create(new[]
                {
                    CreateHoliday(1, may1), CreateHoliday(2, may2)
                }))
                .Build();

            var calendarService = new CalendarService(entityRepositoryFactory, CreateInMemoryCache());

            // Act
            var isHolidayMay1InCalendar1 = calendarService.IsHoliday(may1, 1);
            var isHolidayMay2InCalendar1 = calendarService.IsHoliday(may2, 1);
            var isHolidayMay3InCalendar1 = calendarService.IsHoliday(may3, 1);
            var isHolidayMay1InCalendar2 = calendarService.IsHoliday(may1, 2);
            var isHolidayMay2InCalendar2 = calendarService.IsHoliday(may2, 2);
            var isHolidayMay3InCalendar2 = calendarService.IsHoliday(may3, 2);

            // Assert
            Assert.IsTrue(isHolidayMay1InCalendar1);
            Assert.IsFalse(isHolidayMay2InCalendar1);
            Assert.IsFalse(isHolidayMay3InCalendar1);
            Assert.IsFalse(isHolidayMay1InCalendar2);
            Assert.IsTrue(isHolidayMay2InCalendar2);
            Assert.IsFalse(isHolidayMay3InCalendar2);
        }
        
        [Test]
        public void IsWorkingDay_WhenThereAreDifferentCalendars_ShouldReturnCorrectWorkdayForCalendar()
        {
            // Arrange
            var may1 = new DateTime(2022, 5, 1);
            var may2 = new DateTime(2022, 5, 2);
            var may3 = new DateTime(2022, 5, 3);

            var entityRepositoryFactory = EntityFactoryServiceStubBuilder.Create()
                .WithRepository(EntityRepositoryStub.Create(new[]
                {
                    CreateHoliday(1, may1), CreateDayOff(1, may2),
                    CreateHoliday(2, may2), CreateDayOff(2, may3)
                }))
                .Build();

            var calendarService = new CalendarService(entityRepositoryFactory, CreateInMemoryCache());

            // Act
            var isHolidayMay1InCalendar1 = calendarService.IsWorkingDay(may1, 1);
            var isHolidayMay2InCalendar1 = calendarService.IsWorkingDay(may2, 1);
            var isHolidayMay3InCalendar1 = calendarService.IsWorkingDay(may3, 1);
            var isHolidayMay1InCalendar2 = calendarService.IsWorkingDay(may1, 2);
            var isHolidayMay2InCalendar2 = calendarService.IsWorkingDay(may2, 2);
            var isHolidayMay3InCalendar2 = calendarService.IsWorkingDay(may3, 2);

            // Assert
            Assert.IsFalse(isHolidayMay1InCalendar1);
            Assert.IsFalse(isHolidayMay2InCalendar1);
            Assert.IsTrue(isHolidayMay3InCalendar1);
            Assert.IsTrue(isHolidayMay1InCalendar2);
            Assert.IsFalse(isHolidayMay2InCalendar2);
            Assert.IsFalse(isHolidayMay3InCalendar2);
        }
        
        [Test]
        public void IsHoliday_ShouldReturnCachedResult()
        {
            // Arrange
            var may1 = new DateTime(2022, 5, 1);

            var entityRepositoryFactory = EntityFactoryServiceStubBuilder.Create()
                .WithRepository(EntityRepositoryStub.Create(new[]
                {
                    CreateHoliday(1, may1)
                }))
                .Build();
            var emptyEntityFactoryService = EntityFactoryServiceStubBuilder.Create()
                .WithRepository(EntityRepositoryStub.Create(Enumerable.Empty<HolidayDate>()))
                .Build();

            var inMemoryCache = CreateInMemoryCache();
            var calendarServiceWithData = new CalendarService(entityRepositoryFactory, inMemoryCache);
            var calendarServiceWithCacheOnly = new CalendarService(emptyEntityFactoryService, inMemoryCache);

            // Act
            var isHolidayMay1FromDataResult = calendarServiceWithData.IsHoliday(may1, 1);
            var isHolidayMay1FromCacheResult = calendarServiceWithCacheOnly.IsHoliday(may1, 1);

            // Assert
            Assert.IsTrue(isHolidayMay1FromDataResult);
            Assert.IsTrue(isHolidayMay1FromCacheResult);
        }
        [Test]
        public void IsWorkingDay_ShouldReturnCachedResult()
        {
            // Arrange
            var may1 = new DateTime(2022, 5, 1);
            var may2 = new DateTime(2022, 5, 2);

            var entityRepositoryFactory = EntityFactoryServiceStubBuilder.Create()
                .WithRepository(EntityRepositoryStub.Create(new[]
                {
                    CreateHoliday(1, may1)
                }))
                .Build();
            var emptyEntityFactoryService = EntityFactoryServiceStubBuilder.Create()
                .WithRepository(EntityRepositoryStub.Create(Enumerable.Empty<HolidayDate>()))
                .Build();

            var inMemoryCache = CreateInMemoryCache();
            var calendarServiceWithData = new CalendarService(entityRepositoryFactory, inMemoryCache);
            var calendarServiceWithCacheOnly = new CalendarService(emptyEntityFactoryService, inMemoryCache);

            // Act
            var isHolidayMay1FromDataResult = calendarServiceWithData.IsWorkingDay(may1, 1);
            var isHolidayMay1FromCacheResult = calendarServiceWithCacheOnly.IsWorkingDay(may1, 1);
            var isHolidayMay2FromDataResult = calendarServiceWithData.IsWorkingDay(may2, 1);
            var isHolidayMay2FromCacheResult = calendarServiceWithCacheOnly.IsWorkingDay(may2, 1);

            // Assert
            Assert.IsFalse(isHolidayMay1FromDataResult);
            Assert.IsFalse(isHolidayMay1FromCacheResult);
            Assert.IsTrue(isHolidayMay2FromDataResult);
            Assert.IsTrue(isHolidayMay2FromCacheResult);
        }
    }
}
