﻿using System.Linq;
using FluentNHibernate.Conventions;
using NUnit.Framework;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Domain.Services.PermissionService;
using VacationScheduler.Tests.EntityFactories;

namespace VacationScheduler.Tests.ServiceImplementations
{
    [TestFixture]
    class PermissionServiceTests
    {
        [TestCase(ScheduleStatus.Formation)]
        [TestCase(ScheduleStatus.ManagerApprovement)]
        [TestCase(ScheduleStatus.HrApprovement)]
        [TestCase(ScheduleStatus.Approved)]
        public void GetEmployeeScheduleActions_WhenUserNotConnectedWithEmployeeSchedule_ShouldReturnEmpty(
            ScheduleStatus status)
        {
            // Arrange
            var employeeSchedule = EmployeeVacationScheduleBuilder.Create()
                .SetVacationSchedule(VacationScheduleBuilder.Create().SetStatus(status).Build()).Build();
            var user = UserBuilder.Create().Build();

            // Act
            var result = new PermissionService().GetEmployeeScheduleActions(employeeSchedule, user);

            // Assert
            Assert.That(result, Is.Empty);
        }

        [TestCase(ScheduleStatus.Formation, true)]
        [TestCase(ScheduleStatus.ManagerApprovement, false)]
        [TestCase(ScheduleStatus.HrApprovement, false)]
        [TestCase(ScheduleStatus.Approved, false)]
        public void GetEmployeeScheduleActions_WhenUserIsCreatorOfEmployeeSchedule_ShouldReturnCorrect(
            ScheduleStatus status, bool hasRightsToEdit)
        {
            // Arrange
            var user = UserBuilder.Create().Build();
            var employeeSchedule = EmployeeVacationScheduleBuilder.Create()
                .SetVacationSchedule(VacationScheduleBuilder.Create().SetStatus(status).Build()).SetLogin(user.Login)
                .Build();

            // Act
            var result = new PermissionService().GetEmployeeScheduleActions(employeeSchedule, user);

            // Assert
            if (hasRightsToEdit)
            {
                Assert.That(result.Single(), Is.EqualTo(EmployeeScheduleAction.Edit));
            }
            else
            {
                Assert.That(result.IsEmpty);
            }
        }

        [TestCase(ScheduleStatus.Formation, false)]
        [TestCase(ScheduleStatus.ManagerApprovement, true)]
        [TestCase(ScheduleStatus.HrApprovement, false)]
        [TestCase(ScheduleStatus.Approved, false)]
        public void GetEmployeeScheduleActions_WhenUserIsResponsibleManager_ShouldReturnCorrect(ScheduleStatus status,
            bool hasRightsToEdit)
        {
            // Arrange
            var user = UserBuilder.Create().Build();
            var employeeSchedule = EmployeeVacationScheduleBuilder.Create()
                .SetVacationSchedule(VacationScheduleBuilder.Create().WithResponsibleManager(user.Login)
                    .SetStatus(status).Build())
                .Build();

            // Act
            var result = new PermissionService().GetEmployeeScheduleActions(employeeSchedule, user);

            // Assert
            if (hasRightsToEdit)
            {
                Assert.That(result.Single(), Is.EqualTo(EmployeeScheduleAction.Edit));
            }
            else
            {
                Assert.That(result.IsEmpty);
            }
        }

        [TestCase(ScheduleStatus.Formation, false)]
        [TestCase(ScheduleStatus.ManagerApprovement, false)]
        [TestCase(ScheduleStatus.HrApprovement, true)]
        [TestCase(ScheduleStatus.Approved, false)]
        public void GetEmployeeScheduleActions_WhenUserIsHr_ShouldReturnCorrect(ScheduleStatus status,
            bool hasRightsToEdit)
        {
            // Arrange
            const string employeeNumber = "employeeNumber";
            var user = UserBuilder.Create().IsHrFor(employeeNumber).Build();
            var employeeSchedule = EmployeeVacationScheduleBuilder.Create().SetEmployeeNumber(employeeNumber)
                .SetVacationSchedule(VacationScheduleBuilder.Create().SetStatus(status).Build()).Build();

            // Act
            var result = new PermissionService().GetEmployeeScheduleActions(employeeSchedule, user);

            // Assert
            if (hasRightsToEdit)
            {
                Assert.That(result.Single(), Is.EqualTo(EmployeeScheduleAction.Edit));
            }
            else
            {
                Assert.That(result.IsEmpty);
            }
        }

        [TestCase(ScheduleStatus.Formation)]
        [TestCase(ScheduleStatus.ManagerApprovement)]
        [TestCase(ScheduleStatus.HrApprovement)]
        [TestCase(ScheduleStatus.Approved)]
        public void GetVacationScheduleActions_WhenUserNotConnectedWithEmployeeSchedule_ShouldReturnEmpty(
            ScheduleStatus status)
        {
            // Arrange
            var user = UserBuilder.Create().Build();
            var schedule = VacationScheduleBuilder.Create().SetStatus(status).Build();

            // Act
            var result = new PermissionService().GetVacationScheduleActions(schedule, user);

            // Assert
            Assert.That(result.IsEmpty());
        }

        [TestCase(ScheduleStatus.Formation, new[] { VacationScheduleAction.ToManagerApprove })]
        [TestCase(ScheduleStatus.ManagerApprovement,
            new[] { VacationScheduleAction.ToFormation, VacationScheduleAction.ToHrApprove })]
        [TestCase(ScheduleStatus.HrApprovement, new VacationScheduleAction[0])]
        [TestCase(ScheduleStatus.Approved, new VacationScheduleAction[0])]
        public void GetVacationScheduleActions_WhenUserIsResponsibleManager_ShouldReturnCorrect(ScheduleStatus status,
            VacationScheduleAction[] actions)
        {
            // Arrange
            var user = UserBuilder.Create().Build();
            var schedule = VacationScheduleBuilder.Create().SetStatus(status).WithResponsibleManager(user.Login)
                .Build();

            // Act
            var result = new PermissionService().GetVacationScheduleActions(schedule, user);

            // Assert
            Assert.That(result, Is.EquivalentTo(actions));
        }

        [TestCase(ScheduleStatus.Formation, new VacationScheduleAction[0])]
        [TestCase(ScheduleStatus.ManagerApprovement, new VacationScheduleAction[0])]
        [TestCase(ScheduleStatus.HrApprovement, new[] { VacationScheduleAction.Approve })]
        [TestCase(ScheduleStatus.Approved, new VacationScheduleAction[0])]
        public void GetVacationScheduleActions_WhenUserIsHrForSchedule_ShouldReturnCorrect(ScheduleStatus status,
            VacationScheduleAction[] actions)
        {
            // Arrange
            const string employeeNumber = "number";
            var user = UserBuilder.Create().IsHrFor(employeeNumber).Build();
            var employeeSchedule = EmployeeVacationScheduleBuilder.Create().SetEmployeeNumber(employeeNumber).Build();
            var schedule = VacationScheduleBuilder.Create().SetStatus(status)
                .SetEmployeesSchedules(employeeSchedule)
                .Build();

            // Act
            var result = new PermissionService().GetVacationScheduleActions(schedule, user);

            // Assert
            Assert.That(result, Is.EquivalentTo(actions));
        }
    }
}
