﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using CnB.HRIntegrationService.Client;
using CnB.HRIntegrationService.Client.Dto;
using Home.Client;
using Home.Client.Dto;
using Moq;
using NUnit.Framework;
using VacationScheduler.Api.ServicesImplementations.BuildSchedulesExternalContext;
using VacationScheduler.Tests.EntityFactories;

namespace VacationScheduler.Tests.ServiceImplementations
{
    [TestFixture]
    public class ExternalContextProviderTests
    {
        private const string OwnerRole = "Owner";
        private const string TechLeadRole = "Tech Lead";
        private const string ScrumMasterRole = "Scrum Master";

        private static ExternalContextProvider CreateProvider(IEnumerable<DepartmentDto> departments,
            IEnumerable<EmployeeDto> employees, IEnumerable<TeamDto> teams)
        {
            var hrIntegrationMock = new Mock<IHrIntegrationServiceClient>(MockBehavior.Strict);
            hrIntegrationMock.Setup(h => h.GetDepartments())
                .ReturnsAsync(departments.ToList());
            hrIntegrationMock.Setup(h => h.GetEmployees())
                .ReturnsAsync(employees.ToList());

            var homeClientMock = new Mock<IHomeClient>(MockBehavior.Strict);
            homeClientMock.Setup(h => h.GetTeams(It.IsAny<CancellationToken>()))
                .ReturnsAsync(teams.ToList());

            return new ExternalContextProvider(hrIntegrationMock.Object, homeClientMock.Object);
        }

        [Test]
        public async Task GetExternalContextAsync_ShouldCorrectlyMapDepartmentAndEmployeeToExternal()
        {
            // Arrange
            var departmentDto = DepartmentDtoBuilder.Create().BuildSimple(1);
            var employeeDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var provider = CreateProvider(new[] {departmentDto}, new[] {employeeDto}, new TeamDto[0]);

            // Act
            var result = await provider.GetExternalContextAsync(CancellationToken.None);

            // Assert
            var department = result.AllDepartments.Single();
            Assert.That(department.Id, Is.EqualTo(departmentDto.Id));
            Assert.That(department.Name, Is.EqualTo(departmentDto.Name));

            var employee = department.Employees.Single();
            Assert.That(employee.EmployeeNumber, Is.EqualTo(employeeDto.Id));
            Assert.That(employee.Login, Is.EqualTo(employeeDto.Login));
            Assert.That(employee.FirstName, Is.EqualTo(employeeDto.FirstNameRus));
            Assert.That(employee.LastName, Is.EqualTo(employeeDto.LastNameRus));
            Assert.That(employee.MiddleName, Is.EqualTo(employeeDto.MiddleNameRus));
            Assert.That(employee.Position, Is.EqualTo(employeeDto.Position));
            Assert.That(employee.Region, Is.EqualTo(employeeDto.RegionRus));
            Assert.That(employee.Directorate, Is.EqualTo(employeeDto.DirectorateRus));
            Assert.That(employee.Division, Is.EqualTo(employeeDto.DivisionRus));
            Assert.That(employee.Department, Is.EqualTo(employeeDto.DepartmentRus));
            Assert.That(employee.Group, Is.EqualTo(employeeDto.GroupRus));
            Assert.That(employee.Sector, Is.EqualTo(employeeDto.SectorRus));
            Assert.That(employee.Email, Is.EqualTo(employeeDto.Email));
            Assert.That(employee.EmployeeId, Is.EqualTo(employeeDto.EmployeeId));
        }
        
        [Test]
        public async Task GetExternalContextAsync_ShouldMapTeamWithCorrectAttributes()
        {
            // Arrange
            var departmentDto = DepartmentDtoBuilder.Create().BuildSimple(1);
            var employeeDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var teamDto = TeamDtoBuilder.Create().BuildSimple(777);
            var provider = CreateProvider(new[] {departmentDto}, new[] {employeeDto}, new[] {teamDto});

            // Act
            var result = await provider.GetExternalContextAsync(CancellationToken.None);

            // Assert
            Assert.That(result.AllTeams, Has.One.Items);
            var team = result.AllTeams.Single();
            Assert.That(team.Id, Is.EqualTo(teamDto.Id));
            Assert.That(team.Name, Is.EqualTo(teamDto.Name));
        }
        
        [Test]
        public async Task GetExternalContextAsync_ShouldSkipCommunities()
        {
            // Arrange
            var departmentDto = DepartmentDtoBuilder.Create().BuildSimple(1);
            var employeeDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var communityDto = TeamDtoBuilder.Create().WithIdAndName(12, "Developer community").IsCommunity(true)
                .Build();
            var provider = CreateProvider(new[] {departmentDto}, new[] {employeeDto}, new[] {communityDto});

            // Act
            var result = await provider.GetExternalContextAsync(CancellationToken.None);

            // Assert
            Assert.That(result.AllTeams, Is.Empty);
        }

        [Test]
        public async Task GetExternalContextAsync_ShouldAddOTSToTeams()
        {
            // Arrange
            var departmentDto = DepartmentDtoBuilder.Create().BuildSimple(1);
            var ownerDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var techLeadDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(2);
            var scrumMasterDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(3);
            var teamDto = TeamDtoBuilder.Create().WithIdAndName(12, "Team 12")
                .WithManager(ownerDto, OwnerRole)
                .WithManager(techLeadDto, TechLeadRole)
                .WithManager(scrumMasterDto, ScrumMasterRole)
                .Build();
            var provider = CreateProvider(new[] {departmentDto}, new[] {ownerDto, techLeadDto, scrumMasterDto},
                new[] {teamDto});

            // Act
            var result = await provider.GetExternalContextAsync(CancellationToken.None);

            // Assert
            Assert.That(result.AllTeams, Has.One.Items);
            var externalOwner = result.AllDepartments.Single().Employees.Single(e => e.EmployeeNumber == ownerDto.Id);
            var externalTechLead =
                result.AllDepartments.Single().Employees.Single(e => e.EmployeeNumber == techLeadDto.Id);
            var externalScrumMaster = result.AllDepartments.Single().Employees
                .Single(e => e.EmployeeNumber == scrumMasterDto.Id);

            var team = result.AllTeams.Single();
            Assert.That(team.Owners, Is.EquivalentTo(new[] {externalOwner}));
            Assert.That(team.TechLeads, Is.EquivalentTo(new[] {externalTechLead}));
            Assert.That(team.ScrumMasters, Is.EquivalentTo(new[] {externalScrumMaster}));
        }
        
        [Test]
        public async Task GetExternalContextAsync_ShouldAddActualMembersToTeams()
        {
            // Arrange
            var departmentDto = DepartmentDtoBuilder.Create().BuildSimple(1);
            var teamMember1Dto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var teamMember2Dto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(2);
            var teamFormerMemberDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(3);
            var teamFutureMemberDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(4);
            var teamMemberWithLinearActivityDto = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(5);

            var teamDto = TeamDtoBuilder.Create().WithIdAndName(12, "Team 12")
                .WithEmployee(teamMember1Dto)
                .WithEmployee(teamMember2Dto)
                .WithEmployee(teamFormerMemberDto, DateTime.Today.AddMonths(-5), DateTime.Today.AddDays(-1))
                .WithEmployee(teamFutureMemberDto, DateTime.Today.AddDays(1), DateTime.Today.AddMonths(5))
                .WithEmployee(teamMemberWithLinearActivityDto, hasNonTeamActivities: true)
                .Build();
            
            var provider = CreateProvider(new[] {departmentDto},
                new[]
                {
                    teamMember1Dto, teamMember2Dto, teamFormerMemberDto, teamFutureMemberDto,
                    teamMemberWithLinearActivityDto
                },
                new[] {teamDto});

            // Act
            var result = await provider.GetExternalContextAsync(CancellationToken.None);

            // Assert
            Assert.That(result.AllTeams, Has.One.Items);
            var externalTeamMember1Dto = result.AllDepartments.Single().Employees.Single(e => e.EmployeeNumber == teamMember1Dto.Id);
            var externalTeamMember2Dto = result.AllDepartments.Single().Employees.Single(e => e.EmployeeNumber == teamMember2Dto.Id);

            var team = result.AllTeams.Single();
            Assert.That(team.Employees, Is.EquivalentTo(new[] {externalTeamMember1Dto, externalTeamMember2Dto}));
        }
    }
}
