﻿using System.Linq;
using NUnit.Framework;
using VacationScheduler.Api.ServicesImplementations.BuildSchedulesExternalContext;
using VacationScheduler.Tests.EntityFactories;

namespace VacationScheduler.Tests.ServiceImplementations
{
    [TestFixture]
    public class ExternalContextTests
    {
        [Test]
        public void ShouldCorrectlyMapDepartmentsAndEmployees()
        {
            // Arrange
            var department1 = DepartmentDtoBuilder.Create().BuildSimple(1);
            var department2 = DepartmentDtoBuilder.Create().BuildSimple(2);

            var employee1 = EmployeeDtoBuilder.Create().SetDepartmentId(1).BuildSimple(1);
            var employee2 = EmployeeDtoBuilder.Create().SetDepartmentId(2).BuildSimple(2);
            var employee3TeamMember1 = EmployeeDtoBuilder.Create().SetDepartmentId(2).BuildSimple(3);
            var employee4TeamMember2 = EmployeeDtoBuilder.Create().SetDepartmentId(2).BuildSimple(4);
            var employee5TeamOwner = EmployeeDtoBuilder.Create().SetDepartmentId(2).BuildSimple(5);
            var employee6TeamTechLead = EmployeeDtoBuilder.Create().SetDepartmentId(2).BuildSimple(6);
            var employee7TeamScrumMaster = EmployeeDtoBuilder.Create().SetDepartmentId(2).BuildSimple(7);

            var team = ProviderTeamBuilder.Create(777)
                .WithMembers(employee3TeamMember1.Id, employee4TeamMember2.Id)
                .WithOwners(employee5TeamOwner.Id)
                .WithTechLeads(employee6TeamTechLead.Id)
                .WithScrumMasters(employee7TeamScrumMaster.Id)
                .Build();

            // Act
            var externalContext = new ExternalContext(new[] {department1, department2},
                new[]
                {
                    employee1, employee2, employee3TeamMember1, employee4TeamMember2, employee5TeamOwner,
                    employee6TeamTechLead, employee7TeamScrumMaster
                }, new[] {team});

            // Assert
            Assert.That(externalContext.AllDepartments.Count, Is.EqualTo(2));

            Assert.That(externalContext.AllDepartments.First().Id, Is.EqualTo(department1.Id));
            Assert.That(externalContext.AllDepartments.First().Name, Is.EqualTo(department1.Name));
            var externalEmployee1 = externalContext.AllDepartments.First().Employees.Single();
            Assert.That(externalEmployee1.EmployeeId, Is.EqualTo(employee1.EmployeeId));
            Assert.That(externalEmployee1.Email, Is.EqualTo(employee1.Email));
            Assert.That(externalEmployee1.FirstName, Is.EqualTo(employee1.FirstNameRus));
            Assert.That(externalEmployee1.MiddleName, Is.EqualTo(employee1.MiddleNameRus));
            Assert.That(externalEmployee1.LastName, Is.EqualTo(employee1.LastNameRus));
            Assert.That(externalEmployee1.Login, Is.EqualTo(employee1.Login));
            Assert.That(externalEmployee1.EmployeeNumber, Is.EqualTo(employee1.Id));
            Assert.That(externalEmployee1.Position, Is.EqualTo(employee1.Position));
            Assert.That(externalEmployee1.Region, Is.EqualTo(employee1.RegionRus));
            Assert.That(externalEmployee1.Directorate, Is.EqualTo(employee1.DirectorateRus));
            Assert.That(externalEmployee1.Division, Is.EqualTo(employee1.DivisionRus));
            Assert.That(externalEmployee1.Department, Is.EqualTo(employee1.DepartmentRus));
            Assert.That(externalEmployee1.Group, Is.EqualTo(employee1.GroupRus));
            Assert.That(externalEmployee1.Sector, Is.EqualTo(employee1.SectorRus));

            Assert.That(externalContext.AllDepartments.Last().Id, Is.EqualTo(department2.Id));
            Assert.That(externalContext.AllDepartments.Last().Name, Is.EqualTo(department2.Name));
            var externalEmployee2 = externalContext.AllDepartments.Last().Employees
                .Single(e => e.EmployeeNumber == employee2.Id);
            Assert.That(externalEmployee2.EmployeeId, Is.EqualTo(employee2.EmployeeId));
            Assert.That(externalEmployee2.Email, Is.EqualTo(employee2.Email));
            Assert.That(externalEmployee2.FirstName, Is.EqualTo(employee2.FirstNameRus));
            Assert.That(externalEmployee2.MiddleName, Is.EqualTo(employee2.MiddleNameRus));
            Assert.That(externalEmployee2.LastName, Is.EqualTo(employee2.LastNameRus));
            Assert.That(externalEmployee2.Login, Is.EqualTo(employee2.Login));
            Assert.That(externalEmployee2.EmployeeNumber, Is.EqualTo(employee2.Id));
            Assert.That(externalEmployee2.Position, Is.EqualTo(employee2.Position));
            Assert.That(externalEmployee2.Region, Is.EqualTo(employee2.RegionRus));
            Assert.That(externalEmployee2.Directorate, Is.EqualTo(employee2.DirectorateRus));
            Assert.That(externalEmployee2.Division, Is.EqualTo(employee2.DivisionRus));
            Assert.That(externalEmployee2.Department, Is.EqualTo(employee2.DepartmentRus));
            Assert.That(externalEmployee2.Group, Is.EqualTo(employee2.GroupRus));
            Assert.That(externalEmployee2.Sector, Is.EqualTo(employee2.SectorRus));

            var externalEmployee3TeamMember1 = externalContext.AllDepartments.Last().Employees
                .Single(e => e.EmployeeNumber == employee3TeamMember1.Id);
            var externalEmployee4TeamMember2 = externalContext.AllDepartments.Last().Employees
                .Single(e => e.EmployeeNumber == employee4TeamMember2.Id);
            var externalEmployee5TeamOwner = externalContext.AllDepartments.Last().Employees
                .Single(e => e.EmployeeNumber == employee5TeamOwner.Id);
            var externalEmployee6TeamTechLead = externalContext.AllDepartments.Last().Employees
                .Single(e => e.EmployeeNumber == employee6TeamTechLead.Id);
            var externalEmployee7TeamScrumMaster = externalContext.AllDepartments.Last().Employees
                .Single(e => e.EmployeeNumber == employee7TeamScrumMaster.Id);
            
            Assert.That(externalContext.AllTeams, Has.One.Items);
            var externalTeam = externalContext.AllTeams.Single();
            Assert.That(externalTeam.Id, Is.EqualTo(team.Id));
            Assert.That(externalTeam.Name, Is.EqualTo(team.Name));
            Assert.That(externalTeam.Employees,
                Is.EquivalentTo(new[] {externalEmployee3TeamMember1, externalEmployee4TeamMember2}));
            Assert.That(externalTeam.Owners,
                Is.EquivalentTo(new[] {externalEmployee5TeamOwner}));
            Assert.That(externalTeam.TechLeads,
                Is.EquivalentTo(new[] {externalEmployee6TeamTechLead}));
            Assert.That(externalTeam.ScrumMasters,
                Is.EquivalentTo(new[] {externalEmployee7TeamScrumMaster}));
        }

    }
}
