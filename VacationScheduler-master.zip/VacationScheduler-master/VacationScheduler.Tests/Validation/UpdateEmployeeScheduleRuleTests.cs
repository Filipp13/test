﻿using System;
using System.Linq;
using FluentNHibernate.Conventions;
using NUnit.Framework;
using VacationScheduler.Domain.Dto;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Domain.Services.CalendarService;
using VacationScheduler.Domain.Validation;
using VacationScheduler.Domain.Validation.Applications.Rules;
using VacationScheduler.Tests.EntityFactories;
using VacationScheduler.Tests.Stubs;
using ViennaNET.Validation.Rules.ValidationResults;

namespace VacationScheduler.Tests.Validation
{
    [TestFixture]
    class UpdateEmployeeScheduleRuleTests
    {
        private const int CalendarId = 7;
        private static readonly DateTime yesterday = DateTime.Today.AddDays(-1);
        private static readonly DateTime today = DateTime.Today;
        private static readonly DateTime tomorrow = DateTime.Today.AddDays(1);

        private UpdateEmployeeScheduleRule CreateRule(ICalendarService? service = null) =>
            new UpdateEmployeeScheduleRule(new VacationPeriodsRule(),
                service ?? CalendarServiceStubBuilder.Create().Build());

        private static VacationPeriod CreatePeriod(DateTime oneDay) => new VacationPeriod
        {
            From = oneDay, To = oneDay, Type = PeriodType.ByDays
        };

        private static VacationPeriod CreatePeriod(DateTime from, DateTime to) => new VacationPeriod
        {
            From = from, To = to, Type = PeriodType.ByDays
        };

        private static UpdateEmployeeScheduleDto CreateUpdateDto(int availableDays, params VacationPeriod[] periods) =>
            new UpdateEmployeeScheduleDto
            {
                VacationPeriodDtos = periods.Select(p =>
                    new VacationPeriodDto { VacationPeriod = p, ScheduleYear = p.From.Year }
                ).ToList(),
                EmployeeVacationSchedule = EmployeeVacationScheduleBuilder.Create()
                    .SetCalendarId(CalendarId)
                    .SetAvailableDays(availableDays)
                    .Build()
            };

        private static void AssertResultIsValid(RuleValidationResult result)
        {
            Assert.That(result.IsValid);
            Assert.That(result.Messages.IsEmpty());
        }
        
        private static void AssertResultIsNotValidWithError(RuleValidationResult result, string errorCode)
        {
            Assert.That(result.IsValid, Is.False);
            Assert.That(result.Messages, Has.One.Items);
            Assert.That(result.Messages.Single().Identity.Code, Is.EqualTo(errorCode));
        }

        [Test]
        public void Validate_WhenPeriodEqualToAvailableDays_ShouldReturnValid()
        {
            // Arrange
            var dto = CreateUpdateDto(1, CreatePeriod(today));

            // Act
            var res = CreateRule().Validate(dto, null);

            // Assert
            AssertResultIsValid(res);
        }

        [Test]
        public void Validate_WhenPeriodGreaterThanAvailableDays_ShouldReturnNotValid()
        {
            // Arrange
            var dto = CreateUpdateDto(1, CreatePeriod(today, tomorrow));

            // Act
            var res = CreateRule().Validate(dto, null);

            // Assert
            AssertResultIsNotValidWithError(res, CodeNames.AvailableDaysExceeded);
        }

        [Test]
        public void Validate_WhenPeriodLessThanAvailableDays_ShouldReturnNotValid()
        {
            // Arrange
            var dto = CreateUpdateDto(3, CreatePeriod(today, tomorrow));;

            // Act
            var res = CreateRule().Validate(dto, null);

            // Assert

            AssertResultIsNotValidWithError(res, CodeNames.AvailableDaysNotSpent);
        }
        
        [TestCase(2, 3, 4, true)]
        [TestCase(3, 3, 4, false)]
        [TestCase(4, 3, 4, true)]
        [TestCase(5, 3, 4, true)]
        public void Validate_WhenFirstDayOfPeriodIsHoliday_ShouldReturnNotValid(int holidayDay, int firstDay, int lastDay, bool isValid)
        {
            // Arrange
            var holidayDate = new DateTime(2022, 10, holidayDay);
            var fromDate = new DateTime(2022, 10, firstDay);
            var toDate = new DateTime(2022, 10, lastDay);
            var dto = CreateUpdateDto(2, CreatePeriod(fromDate, toDate));;
            var rule = CreateRule(CalendarServiceStubBuilder.Create()
                .WithHolidays(CalendarId, holidayDate)
                .Build());

            // Act
            var res = rule.Validate(dto, null);

            // Assert
            if (isValid)
            {
                AssertResultIsValid(res);
            }
            else
            {
                AssertResultIsNotValidWithError(res, CodeNames.VacationPeriodShouldNotStartFromHoliday);
            }
        }
        
        [Test]
        public void Validate_WhenAllDaysOfPeriodAreNotWorkingDays_ShouldReturnNotValid()
        {
            // Arrange
            var dto = CreateUpdateDto(3, CreatePeriod(yesterday, tomorrow));;
            var rule = CreateRule(CalendarServiceStubBuilder.Create()
                .WithHolidays(CalendarId, today)
                .WithDayOffs(CalendarId, yesterday, tomorrow)
                .Build());

            // Act
            var res = rule.Validate(dto, null);

            // Assert
            AssertResultIsNotValidWithError(res, CodeNames.VacationPeriodShouldHaveAtLeastOneWorkday);
        }
    }
}
