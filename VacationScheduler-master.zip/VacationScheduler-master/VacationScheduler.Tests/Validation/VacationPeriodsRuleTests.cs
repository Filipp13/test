﻿using System;
using System.Collections.Generic;
using System.Linq;
using FluentNHibernate.Conventions;
using NUnit.Framework;
using VacationScheduler.Domain.Dto;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Validation;
using VacationScheduler.Domain.Validation.Applications.Rules;

namespace VacationScheduler.Tests.Validation
{
    [TestFixture]
    public class VacationPeriodsRuleTests
    {
        private readonly VacationPeriodsRule _rule = new VacationPeriodsRule();

        [Test]
        public void Validate_WhenToYearIsIncorrect_ShouldReturnNotValid()
        {
            // Arrange
            var periods = new List<VacationPeriodDto>
            {
                new VacationPeriodDto
                {
                    VacationPeriod = new VacationPeriod {From = DateTime.Today, To = DateTime.Today.AddYears(1)},
                    ScheduleYear = DateTime.Today.Year
                }
            };

            // Act
            var res = _rule.Validate(periods, null);

            // Assert
            Assert.That(res.IsValid, Is.False);
            Assert.That(res.Messages, Has.One.Items);
            Assert.That(res.Messages.Single().Identity.Code, Is.EqualTo(CodeNames.VacationPeriodsYearMismatch));
        }

        [Test]
        public void Validate_WhenFromYearIsIncorrect_ShouldReturnNotValid()
        {
            // Arrange
            var periods = new List<VacationPeriodDto>
            {
                new VacationPeriodDto
                {
                    VacationPeriod = new VacationPeriod {From = DateTime.Today.AddYears(-1), To = DateTime.Today},
                    ScheduleYear = DateTime.Today.Year
                }
            };

            // Act
            var res = _rule.Validate(periods, null);

            // Assert
            Assert.That(res.IsValid, Is.False);
            Assert.That(res.Messages, Has.One.Items);
            Assert.That(res.Messages.Single().Identity.Code, Is.EqualTo(CodeNames.VacationPeriodsYearMismatch));
        }

        [Test]
        public void Validate_WhenPeriodsCorrect_ShouldReturnValid()
        {
            // Arrange
            var today = DateTime.Today;
            var tomorrow = DateTime.Today.AddDays(1);
            var periods = new List<VacationPeriodDto>
            {
                new VacationPeriodDto
                {
                    VacationPeriod = new VacationPeriod {From = today, To = today},
                    ScheduleYear = today.Year
                },
                new VacationPeriodDto
                {
                    VacationPeriod = new VacationPeriod {From = tomorrow, To = tomorrow},
                    ScheduleYear = today.Year
                }
            };

            // Act
            var res = _rule.Validate(periods, null);

            // Assert
            Assert.That(res.IsValid);
            Assert.That(res.Messages.IsEmpty());
        }

        [Test]
        public void Validate_WhenPeriodsIntersect_ShouldReturnNotValid()
        {
            // Arrange
            var yesterday = DateTime.Today.AddDays(-1);
            var today = DateTime.Today;
            var tomorrow = DateTime.Today.AddDays(1);
            var periods = new List<VacationPeriodDto>
            {
                new VacationPeriodDto
                {
                    VacationPeriod = new VacationPeriod {From = yesterday, To = today},
                    ScheduleYear = DateTime.Today.Year
                },
                new VacationPeriodDto
                {
                    VacationPeriod = new VacationPeriod {From = today, To = tomorrow},
                    ScheduleYear = DateTime.Today.Year
                }
            };

            // Act
            var res = _rule.Validate(periods, null);

            // Assert
            Assert.That(res.IsValid, Is.False);
            Assert.That(res.Messages, Has.One.Items);
            Assert.That(res.Messages.Single().Identity.Code, Is.EqualTo(CodeNames.VacationPeriodsIntersect));
        }

        [Test]
        public void Validate_WhenPeriodFromGreaterThanTo_ShouldReturnNotValid()
        {
            // Arrange
            var periods = new List<VacationPeriodDto>
            {
                new VacationPeriodDto
                {
                    VacationPeriod = new VacationPeriod {From = DateTime.Today.AddDays(1), To = DateTime.Today},
                    ScheduleYear = DateTime.Today.Year
                }
            };

            // Act
            var res = _rule.Validate(periods, null);

            // Assert
            Assert.That(res.IsValid, Is.False);
            Assert.That(res.Messages, Has.One.Items);
            Assert.That(res.Messages.Single().Identity.Code, Is.EqualTo(CodeNames.VacationPeriodsFromGreaterThanTo));
        }
    }
}
