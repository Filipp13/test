﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using VacationScheduler.Application.Queries.GetAvailableSchedules;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Tests.EntityFactories;
using ViennaNET.TestUtils.Orm;

namespace VacationScheduler.Tests.ApplicationQueries
{
    [TestFixture]
    public class GetAvailableSchedulesQueryHandlerTests
    {
        private const string UserLogin = "rualogin";
        private const string UserEmployeeNumber = "123777";

        private static GetAvailableSchedulesQueryHandler CreateHandler(IEnumerable<VacationSchedule> vacationSchedules,
            IEnumerable<string>? isHrForEmployees = null)
        {
            var user = UserBuilder.Create()
                .WithLogin(UserLogin)
                .WithEmployees(isHrForEmployees?.ToArray() ?? new string[] { })
                .Build();
            var efs = EntityFactoryServiceStubBuilder.Create()
                .WithRepository(EntityRepositoryStub.Create(vacationSchedules))
                .Build();
            return new GetAvailableSchedulesQueryHandler(efs,
                UserRepositoryBuilder.CreateRepositoryWithCurrentUser(user));
        }

        [Test]
        public async Task Handle_WhenNoSchedules_ShouldReturnEmpty()
        {
            // Arrange
            var handler = CreateHandler(new VacationSchedule[0]);
            
            // Act
            var result = await handler.HandleAsync(new GetAvailableSchedulesQuery(), CancellationToken.None);
            
            // Assert
            Assert.That(result.MyOwnSchedule, Is.Null);
            Assert.That(result.ManagedSchedules, Is.Not.Null.And.Empty);
        }
        
        [Test]
        public async Task Handle_WhenHasOwnSchedule_ShouldReturn()
        {
            // Arrange
            var ownSchedule = VacationScheduleBuilder.Create()
                .WithScheduleForEmployee(UserEmployeeNumber, UserLogin)
                .WithScheduleForEmployee("9999")
                .Build();
            var ownInformationalSchedule = VacationScheduleBuilder.Create()
                .WithInformationalScheduleForEmployee(UserEmployeeNumber, UserLogin)
                .WithScheduleForEmployee("8888")
                .Build();
            var otherSchedule = VacationScheduleBuilder.Create()
                .WithScheduleForEmployee("7777")
                .WithInformationalScheduleForEmployee("0000")
                .Build();
            var handler = CreateHandler(new[] {ownSchedule, ownInformationalSchedule, otherSchedule});
            
            // Act
            var result = await handler.HandleAsync(new GetAvailableSchedulesQuery(), CancellationToken.None);
            
            // Assert
            Assert.That(result.MyOwnSchedule, Is.EqualTo(ownSchedule));
        }
        
        [Test]
        public async Task Handle_WhenHasManagedSchedules_ShouldReturnThemExceptOwn()
        {
            // Arrange
            var ownSchedule = VacationScheduleBuilder.Create()
                .WithScheduleForEmployee(UserEmployeeNumber, UserLogin)
                .WithScheduleForEmployee("9999")
                .WithResponsibleManager(UserLogin)
                .Build();
            var managedSchedule1 = VacationScheduleBuilder.Create()
                .WithResponsibleManager(UserLogin)
                .WithInformationalScheduleForEmployee(UserEmployeeNumber, UserLogin)
                .WithScheduleForEmployee("8888")
                .Build();
            var managedSchedule2 = VacationScheduleBuilder.Create()
                .WithResponsibleManager(UserLogin)
                .WithResponsibleManager("ruaother")
                .WithScheduleForEmployee("8888")
                .WithInformationalScheduleForEmployee("7897")
                .Build();
            var otherSchedule = VacationScheduleBuilder.Create()
                .WithScheduleForEmployee("7777")
                .WithInformationalScheduleForEmployee("0000")
                .Build();
            var handler = CreateHandler(new[] {ownSchedule, managedSchedule1, managedSchedule2, otherSchedule});
            
            // Act
            var result = await handler.HandleAsync(new GetAvailableSchedulesQuery(), CancellationToken.None);
            
            // Assert
            Assert.That(result.ManagedSchedules, Is.EquivalentTo(new [] {managedSchedule1, managedSchedule2}));
        }
        
        [Test]
        public async Task Handle_WhenHrHasEmployeesManaged_ShouldReturnOwnSchedulesOfThoseEmployees()
        {
            // Arrange
            const string managedEmployee1 = "1111";
            const string managedEmployee2 = "2222";
            const string managedEmployee3 = "3333";
            const string otherEmployee = "4444";
            const string informationalEmployee = "5555";
            var managedSchedule1 = VacationScheduleBuilder.Create()
                .WithScheduleForEmployee(managedEmployee1)
                .WithScheduleForEmployee(managedEmployee2)
                .Build();
            var managedSchedule2 = VacationScheduleBuilder.Create()
                .WithScheduleForEmployee(managedEmployee3)
                .Build();
            var otherSchedule = VacationScheduleBuilder.Create()
                .WithScheduleForEmployee(otherEmployee)
                .WithInformationalScheduleForEmployee(informationalEmployee)
                .WithInformationalScheduleForEmployee(managedEmployee1)
                .WithResponsibleManager("somelogin", managedEmployee2)
                .Build();
            var handler = CreateHandler(new[] {managedSchedule1, managedSchedule2, otherSchedule},
                new[] {managedEmployee1, managedEmployee2, managedEmployee3});
            
            // Act
            var result = await handler.HandleAsync(new GetAvailableSchedulesQuery(), CancellationToken.None);
            
            // Assert
            Assert.That(result.ManagedSchedules, Is.EquivalentTo(new [] {managedSchedule1, managedSchedule2}));
        }
    }
}
