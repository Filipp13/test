﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using VacationScheduler.Application.Exceptions;
using VacationScheduler.Application.Queries.GetSpecifiedVacationSchedule;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Services.PermissionService;
using VacationScheduler.Domain.Services.UserService;
using VacationScheduler.Tests.EntityFactories;
using VacationScheduler.Tests.Stubs;
using ViennaNET.TestUtils.Orm;

namespace VacationScheduler.Tests.ApplicationQueries
{
    [TestFixture]
    class GetSpecifiedVacationScheduleQueryHandlerTests
    {
        private const int Calendar1Id = 1;
        private static readonly string[] hrForEmployees = new[] { "111222", "333444" };
        private static readonly DateTime[] calendar1HolidayDates = new[] { new DateTime(2020,1,1), new DateTime(2020, 1, 2) };

        private static readonly IUser currentUser = UserBuilder.Create()
            .WithLogin("rualogin")
            .WithEmployees(hrForEmployees)
            .Build();

        private static GetSpecifiedVacationScheduleQueryHandler CreateHandler(
            params VacationSchedule[] entities)
        {
            var factoryService = EntityFactoryServiceStubBuilder
                .Create()
                .WithRepository(EntityRepositoryStub.Create(entities))
                .Build();

            var calendarService = CalendarServiceStubBuilder.Create()
                .WithHolidays(Calendar1Id, calendar1HolidayDates)
                .Build();

            return new GetSpecifiedVacationScheduleQueryHandler(factoryService,
                UserRepositoryBuilder.CreateRepositoryWithCurrentUser(currentUser),
                Mock.Of<IPermissionService>(MockBehavior.Loose),
                calendarService);
        }

        private static GetSpecifiedVacationScheduleQueryHandler CreateHandler(
            VacationSchedule schedule, IPermissionService permissionService)
        {
            var factoryService = EntityFactoryServiceStubBuilder
                .Create()
                .WithRepository(EntityRepositoryStub.Create(new[] { schedule }))
                .Build();

            var calendarService = CalendarServiceStubBuilder.Create().Build();

            return new GetSpecifiedVacationScheduleQueryHandler(factoryService,
                UserRepositoryBuilder.CreateRepositoryWithCurrentUser(currentUser),
                permissionService,
                calendarService);
        }

        [Test]
        public void Handle_WhenScheduleRepositoryIsEmpty_ShouldThrow()
        {
            // Arrange
            var handler = CreateHandler();

            // Act
            // Assert
            Assert.ThrowsAsync<DbObjectNotFoundException>(() =>
                handler.HandleAsync(new GetSpecifiedVacationScheduleQuery(), CancellationToken.None));
        }

        [Test]
        public async Task Handle_WhenScheduleRepositoryHasManySchedules_ShouldReturnCorrectById()
        {
            // Arrange
            var currentSchedule = VacationScheduleBuilder.Create()
                .SetId(1)
                .Build();
            var anotherSchedule = VacationScheduleBuilder.Create()
                .SetId(2)
                .Build();

            var handler = CreateHandler(currentSchedule, anotherSchedule);

            // Act
            var result =
                await handler.HandleAsync(new GetSpecifiedVacationScheduleQuery
                {
                    VacationScheduleId = currentSchedule.Id
                }, CancellationToken.None);

            // Assert
            Assert.That(result.Id, Is.EqualTo(currentSchedule.Id));
            Assert.That(result.Name, Is.EqualTo(currentSchedule.Name));
            Assert.That(result.Status, Is.EqualTo(currentSchedule.Status));
            Assert.That(result.Year, Is.EqualTo(currentSchedule.Year));
            Assert.That(result.ResponsibleManagers, Is.EqualTo(currentSchedule.ResponsibleManagers));
            Assert.That(result.EmployeesSchedulesForInformation, Is.EqualTo(currentSchedule.EmployeesSchedulesForInformation));
        }

        [TestCase(new VacationScheduleAction[0] )]
        [TestCase(new [] { VacationScheduleAction.Approve} )]
        [TestCase(new [] { VacationScheduleAction.ToFormation} )]
        [TestCase(new [] { VacationScheduleAction.ToHrApprove} )]
        [TestCase(new [] { VacationScheduleAction.ToManagerApprove} )]
        public async Task Handle_WhenHasSomeEmployeeSchedules_ShouldReturnCorrectPermissionsForEachEmployeeSchedule(VacationScheduleAction[] actions)
        {
            // Arrange
            var es1 = EmployeeVacationScheduleBuilder.Create().SetEmployeeNumber("es1").Build();
            var es1Permissions = new EmployeeScheduleAction[] { };
            var es2 = EmployeeVacationScheduleBuilder.Create().SetEmployeeNumber("es2").Build();
            var es2Permissions = new[] { EmployeeScheduleAction.Edit };
            var es3 = EmployeeVacationScheduleBuilder.Create().SetEmployeeNumber("es3").Build();
            var es3Permissions = new[]
            {
                EmployeeScheduleAction.Edit, EmployeeScheduleAction.Edit, EmployeeScheduleAction.Edit
            };
            var currentSchedule = VacationScheduleBuilder.Create()
                .SetId(1)
                .SetEmployeesSchedules(es1, es2, es3)
                .Build();

            var permissionService = PermissionServiceStubBuilder.Create()
                .WithEmployeeScheduleActions(es1, currentUser, es1Permissions)
                .WithEmployeeScheduleActions(es2, currentUser, es2Permissions)
                .WithEmployeeScheduleActions(es3, currentUser, es3Permissions)
                .WithVacationScheduleActions(currentSchedule, currentUser, actions)
                .Build();

            var handler = CreateHandler(currentSchedule, permissionService);

            // Act
            var result =
                await handler.HandleAsync(new GetSpecifiedVacationScheduleQuery
                {
                    VacationScheduleId = currentSchedule.Id
                }, CancellationToken.None);

            // Assert
            Assert.That(result.EmployeesSchedules.Select(esitem => esitem.EmployeeSchedule),
                Is.EquivalentTo(new[] { es1, es2, es3 }));

            var es1Item = result.EmployeesSchedules.SingleOrDefault(es => es.EmployeeSchedule == es1);
            Assert.NotNull(es1Item);
            Assert.That(es1Item!.Actions, Is.EquivalentTo(es1Permissions));

            var es2Item = result.EmployeesSchedules.SingleOrDefault(es => es.EmployeeSchedule == es2);
            Assert.NotNull(es2Item);
            Assert.That(es2Item!.Actions, Is.EquivalentTo(es2Permissions));

            var es3Item = result.EmployeesSchedules.SingleOrDefault(es => es.EmployeeSchedule == es3);
            Assert.NotNull(es3Item);
            Assert.That(es3Item!.Actions, Is.EquivalentTo(es3Permissions));

            Assert.That(result.VacationScheduleActions, Is.EqualTo(actions));
        }

        [Test]
        public async Task Handle_WhenQueryExecute_ShouldReturnHolidayDates()
        {
            // Arrange
            var es1 = EmployeeVacationScheduleBuilder.Create().SetEmployeeNumber("es1").SetCalendarId(1).Build();
            var currentSchedule = VacationScheduleBuilder.Create()
                .SetId(1)
                .SetEmployeesSchedules(es1)
                .Build();

            var handler = CreateHandler(currentSchedule);

            // Act
            var result =
                await handler.HandleAsync(
                    new GetSpecifiedVacationScheduleQuery { VacationScheduleId = currentSchedule.Id },
                    CancellationToken.None);

            // Assert
            Assert.That(result.HolidayDates.Select(hd => hd.Date), Is.EquivalentTo(calendar1HolidayDates),
                "Query must return holiday dates");
        }
    }
}
