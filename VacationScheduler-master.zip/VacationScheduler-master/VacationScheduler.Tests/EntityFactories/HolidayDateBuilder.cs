﻿using System;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;

namespace VacationScheduler.Tests.EntityFactories
{
    internal class HolidayDateBuilder
    {
        private readonly HolidayDate _holidayDate = new HolidayDate();

        public static HolidayDateBuilder Create()
        {
            return new HolidayDateBuilder();
        }

        public HolidayDateBuilder SetId(int id)
        {
            _holidayDate.Id = id;

            return this;
        }

        public HolidayDateBuilder SetCalendarId(int id)
        {
            _holidayDate.CalendarId = id;

            return this;
        }

        public HolidayDateBuilder SetHolidayDateValue(DateTime date)
        {
            _holidayDate.HolidayDateValue = date;

            return this;
        }

        public HolidayDateBuilder SetUploadDate(DateTime date)
        {
            _holidayDate.UploadDate = date;

            return this;
        }

        public HolidayDateBuilder SetCalendarName(string name)
        {
            _holidayDate.CalendarName = name;

            return this;
        }

        public HolidayDateBuilder SetCalendarDayType(CalendarDayType type)
        {
            _holidayDate.CalendarDayType = type;

            return this;
        }

        public HolidayDate Build() => _holidayDate;
    }
}
