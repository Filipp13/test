﻿using System;
using System.Linq;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Domain.ValueObjects;

namespace VacationScheduler.Tests.EntityFactories
{
    internal class VacationScheduleBuilder
    {
        private readonly VacationSchedule _schedule = new VacationSchedule();

        public static VacationScheduleBuilder Create()
        {
            return new VacationScheduleBuilder();
        }

        public VacationScheduleBuilder SetEmployeesSchedules(params EmployeeVacationSchedule[] employeesSchedules)
        {
            _schedule.EmployeesSchedules = employeesSchedules.ToHashSet();

            return this;
        }

        public VacationScheduleBuilder SetStatus(ScheduleStatus status)
        {
            _schedule.Status = status;

            return this;
        }

        public VacationScheduleBuilder SetId(int id)
        {
            _schedule.Id = id;

            return this;
        }

        public VacationScheduleBuilder WithScheduleForEmployee(string employeeNumber, string? login = null)
        {
            _schedule.EmployeesSchedules.Add(new EmployeeVacationSchedule()
            {
                EmployeeNumber = employeeNumber, EmployeeLogin = login
            });

            return this;
        }

        public VacationScheduleBuilder WithInformationalScheduleForEmployee(string employeeNumber, string? login = null)
        {
            _schedule.EmployeesSchedulesForInformation.Add(
                new EmployeeVacationSchedule { EmployeeNumber = employeeNumber, EmployeeLogin = login });

            return this;
        }

        public VacationScheduleBuilder WithResponsibleManager(string login, string? employeeNumber = null)
        {
            _schedule.ResponsibleManagers.Add(new Manager
            {
                Login = login, EmployeeNumber = employeeNumber ?? Guid.NewGuid().ToString()
            });

            return this;
        }

        public VacationSchedule Build() => _schedule;
    }
}
