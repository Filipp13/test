﻿using VacationScheduler.Api.ServicesImplementations.BuildSchedulesExternalContext;

namespace VacationScheduler.Tests.EntityFactories
{
    public class ProviderTeamBuilder
    {
        private readonly Team _team = new Team();
        
        private ProviderTeamBuilder() {}

        public static ProviderTeamBuilder Create(int seed)
        {
            var builder = new ProviderTeamBuilder {_team = {Id = seed, Name = $"Team {seed}"}};

            return builder;
        }

        public Team Build() => _team;

        public ProviderTeamBuilder WithMembers(params string[] employeeNumbers)
        {
            _team.MembersEmployeeNumbers = employeeNumbers;
            return this;
        }

        public ProviderTeamBuilder WithOwners(params string[] employeeNumbers)
        {
            _team.OwnersEmployeeNumbers = employeeNumbers;
            return this;
        }
        
        public ProviderTeamBuilder WithTechLeads(params string[] employeeNumbers)
        {
            _team.TechLeadsEmployeeNumbers = employeeNumbers;
            return this;
        }

        public ProviderTeamBuilder WithScrumMasters(params string[] employeeNumbers)
        {
            _team.ScrumMastersEmployeeNumbers = employeeNumbers;
            return this;
        }
    }
}
