﻿using System.Collections.Generic;
using System.Linq;
using CnB.HRIntegrationService.Client.Dto;

namespace VacationScheduler.Tests.EntityFactories
{
    internal class DepartmentDtoBuilder
    {
        private readonly DepartmentDto _department = new DepartmentDto
        {
            Children = new List<DepartmentDto>()
        };

        public static DepartmentDtoBuilder Create() => new DepartmentDtoBuilder();

        public DepartmentDtoBuilder SetId(int id)
        {
            _department.Id = id;

            return this;
        }

        public DepartmentDtoBuilder SetName(string name)
        {
            _department.Name = name;

            return this;
        }

        public DepartmentDtoBuilder AddChild(DepartmentDto department)
        {
            _department.Children.Add(department);

            return this;
        }

        public DepartmentDtoBuilder AddChildren(params DepartmentDto[] departments)
        {
            foreach (var department in departments)
            {
                _department.Children.Add(department);
            }

            return this;
        }

        public DepartmentDtoBuilder SetExtraDays(int extraDays)
        {
            _department.ExtraDays = extraDays;

            return this;
        }
        
        public DepartmentDtoBuilder SetAdminHead(EmployeeSlimDto? employee)
        {
            _department.AdministrativeHead = employee;

            return this;
        }

        public DepartmentDtoBuilder SetFuncHeads(params EmployeeSlimDto[]? employees)
        {
            _department.OtherManagerEmployees = employees?.ToList();

            return this;
        }

        public DepartmentDto Build() => _department;

        public DepartmentDto BuildSimple(int seed)
        {
            _department.Id = seed;
            _department.Name = $"name{seed}";

            return _department;
        }
    }
}
