﻿using System.Collections.Generic;
using System.Linq;
using Moq;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Services.UserService;

namespace VacationScheduler.Tests.EntityFactories
{
    internal class UserBuilder
    {
        private string _login = "ruasomelogin";
        private readonly ISet<string> _isHrForEmployeeNumbers = new HashSet<string>();
        
        private UserBuilder()
        {
        }

        public static UserBuilder Create() => new UserBuilder();

        public IUser Build()
        {
            var userMock = new Mock<IUser>(MockBehavior.Strict);
            
            userMock.Setup(u => u.Login)
                .Returns(_login);
            userMock.Setup(u => u.IsHrForEmployee(It.IsAny<string>()))
                .Returns((string employeeNumber) => _isHrForEmployeeNumbers.Contains(employeeNumber));
            userMock.Setup(u => u.GetEmployeeNumbersWhereHr())
                .Returns(_isHrForEmployeeNumbers);
            userMock.Setup(u => u.IsHrForVacationSchedule(It.IsAny<VacationSchedule>()))
                .Returns((VacationSchedule schedule) => _isHrForEmployeeNumbers
                    .Intersect(schedule.EmployeesSchedules.Select(e => e.EmployeeNumber)).Any());
            userMock.Setup(u => u.IsHr)
                .Returns(_isHrForEmployeeNumbers.Any());

            return userMock.Object;
        }

        public UserBuilder WithEmployees(params string[] employeeNumbers)
        {
            foreach (var employeeNumber in employeeNumbers.Where(e => e != null))
            {
                _isHrForEmployeeNumbers.Add(employeeNumber);
            }

            return this;
        }

        public UserBuilder IsHrFor(string employeeNumber)
        {
            _isHrForEmployeeNumbers.Add(employeeNumber);

            return this;
        }

        public UserBuilder WithLogin(string login)
        {
            _login = login;
            
            return this;
        }
    }
}
