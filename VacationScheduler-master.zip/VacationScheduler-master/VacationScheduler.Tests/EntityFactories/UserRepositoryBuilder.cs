﻿using Moq;
using VacationScheduler.Domain.Services.UserService;

namespace VacationScheduler.Tests.EntityFactories
{
    internal class UserRepositoryBuilder
    {
        private readonly Mock<IUserRepository> _userRepositoryMock = new Mock<IUserRepository>(MockBehavior.Strict);

        private UserRepositoryBuilder()
        {
        }

        public static UserRepositoryBuilder Create() => new UserRepositoryBuilder();

        public UserRepositoryBuilder WithUser(string login, IUser user)
        {
            _userRepositoryMock.Setup(r => r.GetUserAsync(login))
                .ReturnsAsync(user);

            return this;
        }

        public UserRepositoryBuilder WithCurrentUser(IUser user)
        {
            _userRepositoryMock.Setup(r => r.GetCurrentUserAsync())
                .ReturnsAsync(user);

            return this;
        }

        public UserRepositoryBuilder WithUser(IUser user)
        {
            _userRepositoryMock.Setup(r => r.GetUserAsync(It.IsAny<string>()))
                .ReturnsAsync(user);

            return this;
        }

        public IUserRepository Build() => _userRepositoryMock.Object;

        public static IUserRepository CreateRepositoryWithUser(IUser user) =>
            Create()
                .WithUser(user)
                .Build();

        public static IUserRepository CreateRepositoryWithCurrentUser(IUser user) =>
            Create()
                .WithCurrentUser(user)
                .Build();
    }
}
