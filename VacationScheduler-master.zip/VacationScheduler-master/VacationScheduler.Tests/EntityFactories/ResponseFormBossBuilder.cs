﻿using System;
using VacationScheduler.Application.Commands.SynchronizeHolidayDates;

namespace VacationScheduler.Tests.EntityFactories
{
    internal class ResponseFormBossBuilder
    {
        private readonly HolidayDateFormBoss _responseFormBoss = new HolidayDateFormBoss();

        public static ResponseFormBossBuilder Create()
        {
            return new ResponseFormBossBuilder();
        }


        public ResponseFormBossBuilder SetCalendarId(int id)
        {
            _responseFormBoss.CalendarId = id;

            return this;
        }

        public ResponseFormBossBuilder SetHolidayDateValue(DateTime date)
        {
            _responseFormBoss.HolidayDate = date;

            return this;
        }

        public ResponseFormBossBuilder SetCalendarName(string name)
        {
            _responseFormBoss.CalendarName = name;

            return this;
        }

        public HolidayDateFormBoss Build() => _responseFormBoss;
    }
}
