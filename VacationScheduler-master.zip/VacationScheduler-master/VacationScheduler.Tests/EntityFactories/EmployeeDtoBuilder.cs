﻿using CnB.HRIntegrationService.Client.Dto;

namespace VacationScheduler.Tests.EntityFactories
{
    internal class EmployeeDtoBuilder
    {
        private readonly EmployeeDto _employee = new EmployeeDto();

        public static EmployeeDtoBuilder Create() => new EmployeeDtoBuilder();

        public EmployeeDtoBuilder SetId(string id)
        {
            _employee.Id = id;

            return this;
        }

        public EmployeeDtoBuilder SetFirstNameRus(string nameRus)
        {
            _employee.FirstNameRus = nameRus;

            return this;
        }

        public EmployeeDtoBuilder SetLastNameRus(string surnameRus)
        {
            _employee.LastNameRus = surnameRus;

            return this;
        }

        public EmployeeDtoBuilder SetMiddleNameRus(string? middleNameRus)
        {
            _employee.MiddleNameRus = middleNameRus;

            return this;
        }

        public EmployeeDtoBuilder SetLogin(string login)
        {
            _employee.Login = login;

            return this;
        }

        public EmployeeDtoBuilder SetEmail(string email)
        {
            _employee.Email = email;

            return this;
        }

        public EmployeeDtoBuilder SetEmployeeNumber(string employeeNumber)
        {
            _employee.Id = employeeNumber;

            return this;
        }

        public EmployeeDtoBuilder SetDepartmentId(int departmentId)
        {
            _employee.Department = new DepartmentSlimDto { Id = departmentId };

            return this;
        }

        public EmployeeDto Build()
        {
            return _employee;
        }

        public EmployeeDto BuildSimple(int seed)
        {
            _employee.Id = $"{seed}";
            _employee.Login = $"rua{seed}";
            _employee.FirstNameRus = $"nameRus{seed}";
            _employee.LastNameRus = $"surnameRus{seed}";
            _employee.MiddleNameRus = $"middleNameRus{seed}";
            _employee.EmployeeId = seed;
            _employee.Email = $"email{seed}";
            _employee.Position = $"position{seed}";
            _employee.RegionRus = $"region{seed}";
            _employee.DirectorateRus = $"directorate{seed}";
            _employee.DivisionRus = $"division{seed}";
            _employee.DepartmentRus = $"department{seed}";
            _employee.GroupRus = $"group{seed}";
            _employee.SectorRus = $"sector{seed}";

            return _employee;
        }
    }
}
