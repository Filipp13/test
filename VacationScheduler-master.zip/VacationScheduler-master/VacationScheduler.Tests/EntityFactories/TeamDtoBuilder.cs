﻿using System;
using System.Collections.Generic;
using CnB.HRIntegrationService.Client.Dto;
using Home.Client.Dto;

namespace VacationScheduler.Tests.EntityFactories
{
    internal class TeamDtoBuilder
    {
        private readonly TeamDto _team = new TeamDto
        {
            TeamType = new TeamTypeDto { IsCommunity = false },
            LeaderRelations = new List<RelationDto>(),
            FteTeamRelations = new List<FteTeamRelationDto>()
        };
        
        private TeamDtoBuilder()
        {

        }

        public static TeamDtoBuilder Create() => new TeamDtoBuilder();

        public TeamDto Build() => _team;

        public TeamDto BuildSimple(int seed)
        {
            _team.Id = seed;
            _team.Name = $"Team {seed}";

            return _team;
        }

        public TeamDtoBuilder WithIdAndName(int id, string name)
        {
            _team.Id = id;
            _team.Name = name;
            
            return this;
        }

        public TeamDtoBuilder IsCommunity(bool isCommunity)
        {
            _team.TeamType.IsCommunity = isCommunity;
            return this;
        }

        public TeamDtoBuilder WithEmployee(EmployeeDto employee, DateTime? start = null, DateTime? end = null, bool hasNonTeamActivities = false)
        {
            _team.FteTeamRelations.Add(new FteTeamRelationDto
            {
                Fte = new FteDto
                {
                    EmployeeNumber = employee.Id,
                    Login = employee.Login,
                    TeamsEngagement = hasNonTeamActivities ? "NON_TEAM_ACTIVITY_EXISTS" : "ONE_TEAM",
                },
                StartDate = start,
                EndDate = end
            });
            return this;
        }

        public TeamDtoBuilder WithManager(EmployeeDto employee, string role)
        {
            _team.LeaderRelations.Add(new RelationDto
            {
                Employee = new ManagerDto
                {
                    EmployeeNumber = employee.Id,
                    Login = employee.Login
                },
                Role = new RoleDto
                {
                    Name = role
                }
            });
            return this;
        }
    }
}
