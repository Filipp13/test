﻿using VacationScheduler.Domain.Entities;

namespace VacationScheduler.Tests.EntityFactories
{
    internal class EmployeeVacationScheduleBuilder
    {
        private readonly EmployeeVacationSchedule _schedule = new EmployeeVacationSchedule();

        public static EmployeeVacationScheduleBuilder Create()
        {
            return new EmployeeVacationScheduleBuilder();
        }

        public EmployeeVacationScheduleBuilder SetEmployeeNumber(string employeeId)
        {
            _schedule.EmployeeNumber = employeeId;

            return this;
        }

        public EmployeeVacationScheduleBuilder SetVacationSchedule(VacationSchedule schedule)
        {
            _schedule.VacationSchedule = schedule;

            return this;
        }

        public EmployeeVacationScheduleBuilder SetLogin(string login)
        {
            _schedule.EmployeeLogin = login;

            return this;
        }
        
        public EmployeeVacationScheduleBuilder SetCalendarId(int id)
        {
            _schedule.CalendarId = id;

            return this;
        }
        
        public EmployeeVacationScheduleBuilder SetAvailableDays(int days)
        {
            _schedule.AvailableDays = days;

            return this;
        }
        
        public EmployeeVacationSchedule Build() => _schedule;
    }
}
