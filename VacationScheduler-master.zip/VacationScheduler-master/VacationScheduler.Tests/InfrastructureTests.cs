﻿using System.Net.Http;
using System.Threading.Tasks;
using GraphQL;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using NUnit.Framework;
using SimpleInjector;
using SimpleInjector.Lifestyles;
using VacationScheduler.Api;
using VacationScheduler.Api.Controllers;
using VacationScheduler.Api.Schema;
using ViennaNET.Security;

namespace VacationScheduler.Tests
{
    [TestFixture]
    class InfrastructureTests
    {
        [Test]
        public void VerifyDIConfiguration()
        {
            var container = new Container();
            container.Options.DefaultScopedLifestyle = new AsyncScopedLifestyle();

            container.RegisterSingleton(() => new Mock<IHttpClientFactory>().Object);
            container.RegisterSingleton<IConfiguration>(() => new ConfigurationBuilder().AddJsonFile("./conf/appsettings.json").Build());
            container.RegisterSingleton(() => new Mock<ISecurityContextFactory>().Object);
            container.RegisterSingleton(typeof(ILogger<>), typeof(NullLogger<>));

            container.RegisterPackages(new[] { typeof(ApiPackage).Assembly });

            container.Verify();

            Assert.Pass();
        }

        [Test]
        public async Task GraphQlQuery_WhenServiceSchemeQueried_ShouldReturnWithoutErrors()
        {
            var container = new Container();
            container.Options.DefaultScopedLifestyle = new AsyncScopedLifestyle();

            container.RegisterSingleton(() => new Mock<IHttpClientFactory>().Object);
            container.RegisterSingleton<IConfiguration>(() => new ConfigurationBuilder().AddJsonFile("./conf/appsettings.json").Build());
            container.RegisterSingleton(() => new Mock<ISecurityContextFactory>().Object);
            container.RegisterSingleton(typeof(ILogger<>), typeof(NullLogger<>));

            container.RegisterPackages(new[] { typeof(ApiPackage).Assembly });

            var graphQlController = new GraphQlController(container.GetInstance<VacationSchedulerSchema>(),
                container.GetInstance<IDocumentExecuter>());

            var result = await graphQlController.Post(new GraphQlQuery { Query = "_service" });

            Assert.Pass();
        }
    }
}
