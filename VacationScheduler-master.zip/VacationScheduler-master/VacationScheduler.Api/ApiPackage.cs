﻿using BossKadrovik.Client;
using CnB.HRIntegrationService.Client;
using GraphQL;
using Home.Client;
using HrManagerPermissions.Client;
using Microsoft.Extensions.Caching.Memory;
using SimpleInjector;
using SimpleInjector.Packaging;
using VacationScheduler.Api.Schema;
using VacationScheduler.Api.ServicesImplementations;
using VacationScheduler.Api.ServicesImplementations.BuildSchedulesExternalContext;
using VacationScheduler.Application;
using VacationScheduler.Application.Commands.BuildSchedules.ExternalContext;
using VacationScheduler.Domain;
using VacationScheduler.Domain.Services.CalendarService;
using VacationScheduler.Domain.Services.UserService;
using ViennaNET.SimpleInjector.Extensions;

namespace VacationScheduler.Api
{
    internal class ApiPackage : IPackage
    {
        public void RegisterServices(Container container)
        {
            container.AddPackage(new ApplicationPackage())
                .AddPackage(new ClientPackage())
                .AddPackage(new DomainPackage())
                .AddPackage(new BossKadrovikClientPackage())
                .AddPackage(new HomeClientPackage())
                .AddPackage(new HrManagerPermissionsClientPackage());

            container.Register<IDependencyResolver>(() => new FuncDependencyResolver(container.GetInstance),
                Lifestyle.Singleton);
            container.Register<IDocumentExecuter>(() => new SerialDocumentExecuter(), Lifestyle.Singleton);
            container.Register<VacationSchedulerSchema>(Lifestyle.Singleton);
            container.Register<IExternalContextProvider, ExternalContextProvider>(Lifestyle.Singleton);
            container.Register<IUserRepository, UserRepository>(Lifestyle.Singleton);
            container.Register<ICalendarService, CalendarService>(Lifestyle.Singleton);
            container.Register(typeof(IMemoryCache), () => new MemoryCache(new MemoryCacheOptions()), Lifestyle.Singleton);

            container.Register<Mutation>();
            container.Register<Query>();
        }
    }
}
