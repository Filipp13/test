﻿using GraphQL.Types;
using VacationScheduler.Application.Commands.UpdateEmployeeVacationSchedule;
using VacationScheduler.Domain.Enums;

namespace VacationScheduler.Api.Schema.InputTypes
{
    public sealed class VacationPeriodDtoType : InputObjectGraphType<VacationPeriodDto>
    {
        public VacationPeriodDtoType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "Vacation period info";
            Field(e => e.Type, type: typeof(NonNullGraphType<EnumerationGraphType<PeriodType>>)).Description("Period type");
            Field(e => e.From).Description("Period begin");
            Field(e => e.To).Description("Period end");
        }
    }
}
