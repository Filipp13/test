﻿using GraphQL.Types;
using VacationScheduler.Application.Commands.UpdateEmployeeVacationSchedule;

namespace VacationScheduler.Api.Schema.InputTypes
{
    public class UpdateEmployeeVacationScheduleCommandType : InputObjectGraphType<UpdateEmployeeVacationScheduleCommand>
    {
        public UpdateEmployeeVacationScheduleCommandType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "A command to update employee vacation schedule";
            Field(e => e.VacationScheduleId).Description("Id of vacation schedule");
            Field(e => e.EmployeeVacationScheduleId).Description("Id of employee vacation schedule");
            Field(e => e.ScheduledPeriods,
                    type: typeof(NonNullGraphType<ListGraphType<NonNullGraphType<VacationPeriodDtoType>>>))
                .Description("New scheduled periods");
        }
    }
}
