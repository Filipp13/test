﻿using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json.Linq;

namespace VacationScheduler.Api.Schema
{
    [ExcludeFromCodeCoverage]
    public class GraphQlQuery
    {
        public string OperationName { get; set; }

        public string NamedQuery { get; set; }

        public string Query { get; set; }

        public JObject Variables { get; set; }
    }
}
