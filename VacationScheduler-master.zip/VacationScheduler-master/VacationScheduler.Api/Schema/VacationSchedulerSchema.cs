﻿using GraphQL;

namespace VacationScheduler.Api.Schema
{
    public class VacationSchedulerSchema : GraphQL.Types.Schema
    {
        public const string SchemaPrefix = "vacationScheduler";

        public VacationSchedulerSchema(IDependencyResolver dependencyResolver) : base(dependencyResolver)
        {
            Query = dependencyResolver.Resolve<Query>();
            Mutation = dependencyResolver.Resolve<Mutation>();
        }
    }
}
