﻿using System;
using System.Collections.Generic;
using GraphQL;
using GraphQL.Types;
using Microsoft.Extensions.Logging;
using VacationScheduler.Api.Helpers;
using VacationScheduler.Api.Schema.Requests.GetAvailableSchedules;
using VacationScheduler.Api.Schema.Requests.GetSpecifiedVacationSchedule;
using VacationScheduler.Api.Schema.Requests.ValidateEmployeeSchedule;
using VacationScheduler.Application.Queries.GetAvailableSchedules;
using VacationScheduler.Application.Queries.GetSpecifiedVacationSchedule;
using VacationScheduler.Application.Queries.ValidateEmployeeSchedule;
using ViennaNET.Mediator;

namespace VacationScheduler.Api.Schema
{
    public class Query : ObjectGraphType
    {
        private const string QueryPrefix = VacationSchedulerSchema.SchemaPrefix;
        private const string RequestArgumentName = "request";
        private readonly IMediator _mediator;
        private readonly ILogger<Query> _logger;

        public Query(IMediator mediator, ILogger<Query> logger)
        {
            _mediator = mediator;
            _logger = logger;
            InitializeFields();
        }

        private void InitializeFields()
        {
            AddQueryField<GetSpecifiedVacationScheduleQueryType, GetSpecifiedVacationScheduleQuery,
                GetSpecifiedVacationScheduleQueryResultType, GetSpecifiedVacationScheduleQueryResult>(
                "A query to get specified vacation schedule",
                "Произошла ошибка при получении графика отпусков");

            AddQueryField<ValidateEmployeeScheduleQueryType, ValidateEmployeeScheduleQuery,
                ValidateEmployeeScheduleQueryResultType, ValidateEmployeeScheduleQueryResult>(
                "A query to validate update of employee schedule",
                "Произошла ошибка при валидации обновления графика отпусков сотрудника");

            AddQueryField<GetAvailableSchedulesQuery, GetAvailableSchedulesQueryResultType,
                GetAvailableSchedulesQueryResult>(
                "A query to get available vacation schedules for current user",
                "Произошла ошибка при получении графика отпусков");
        }

        private void AddQueryFieldReturningCollection<TArgument, TQuery, TGraphResult, TResult>(string description, string errorMessage)
            where TArgument : InputObjectGraphType<TQuery>
            where TQuery : class, IRequest
            where TGraphResult : GraphType
        {
            AddQueryField<TArgument,
                TQuery,
                NonNullGraphType<ListGraphType<NonNullGraphType<TGraphResult>>>,
                List<TResult>>(description, errorMessage);
        }

        private void AddQueryFieldReturningCollection<TQuery, TGraphResult, TResult>(string description, string errorMessage)
            where TQuery : class, IRequest, new()
            where TGraphResult : GraphType
        {
            AddQueryField<TQuery,
                NonNullGraphType<ListGraphType<NonNullGraphType<TGraphResult>>>,
                List<TResult>>(description, errorMessage);
        }

        private void AddQueryField<TArgument, TQuery, TGraphResult, TResult>(string description, string errorMessage)
            where TArgument : InputObjectGraphType<TQuery>
            where TQuery : class, IRequest
            where TGraphResult : IGraphType
        {
            FieldAsync<TGraphResult>(
                QueryPrefix + typeof(TQuery).Name,
                description,
                new QueryArguments(
                    new QueryArgument<NonNullGraphType<TArgument>> { Name = RequestArgumentName }),
                async context =>
                {
                    var request = context.GetArgument<TQuery>(RequestArgumentName);

                    try
                    {
                        return await _mediator.SendMessageAsync<TQuery, TResult>(request, context.CancellationToken);
                    }
                    catch (Exception exception)
                    {
                        context.Errors.Add(new ExecutionError(errorMessage,
                            ErrorHandlingHelper.GetErrorMessages(exception, _logger)));
                        return null;
                    }
                }
            );
        }

        private void AddQueryField<TQuery, TGraphResult, TResult>(string description, string errorMessage)
            where TQuery : class, IRequest, new()
            where TGraphResult : IGraphType
        {
            FieldAsync<TGraphResult>(
                QueryPrefix + typeof(TQuery).Name,
                description,
                arguments: null,
                async context =>
                {
                    var request = new TQuery();

                    try
                    {
                        return await _mediator.SendMessageAsync<TQuery, TResult>(request, context.CancellationToken);
                    }
                    catch (Exception exception)
                    {
                        context.Errors.Add(new ExecutionError(errorMessage,
                            ErrorHandlingHelper.GetErrorMessages(exception, _logger)));
                        return null;
                    }
                }
            );
        }
    }
}
