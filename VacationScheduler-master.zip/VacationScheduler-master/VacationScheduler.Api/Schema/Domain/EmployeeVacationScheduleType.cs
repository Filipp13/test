﻿using GraphQL.Types;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;

namespace VacationScheduler.Api.Schema.Domain
{
    public sealed class EmployeeVacationScheduleType : ObjectGraphType<EmployeeVacationSchedule>
    {
        public EmployeeVacationScheduleType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "Employee vacation schedule info";
            Field(e => e.Id).Description("Employee vacation schedule id");
            Field(e => e.Status, type: typeof(NonNullGraphType<EnumerationGraphType<ScheduleStatus>>))
                .Description("Employee vacation schedule status");
            Field(e => e.EmployeeNumber).Description("Employee personnel number");
            Field(e => e.EmployeeLogin, true).Description("Employee login");
            Field(e => e.EmployeeFirstName).Description("Employee first name");
            Field(e => e.EmployeeLastName).Description("Employee last name");
            Field(e => e.EmployeeMiddleName, true).Description("Employee middle name");
            Field(e => e.EmployeePosition).Description("Employee position");
            Field(e => e.EmployeeRegion, true).Description("Employee region");
            Field(e => e.EmployeeDirectorate, true).Description("Employee directorate");
            Field(e => e.EmployeeDivision, true).Description("Employee division");
            Field(e => e.EmployeeDepartment, true).Description("Employee department");
            Field(e => e.EmployeeGroup, true).Description("Employee group");
            Field(e => e.EmployeeSector, true).Description("Employee sector");
            Field(e => e.EmployeeEmail, true).Description("Employee email");
            Field(e => e.CalendarId, false).Description("Employee calendar id");
            Field(e => e.AvailableDays).Description("Available days for scheduling");
            Field(e => e.ScheduledPeriods,
                    type: typeof(NonNullGraphType<ListGraphType<NonNullGraphType<VacationPeriodType>>>))
                .Description("Scheduled periods");
        }
    }
}
