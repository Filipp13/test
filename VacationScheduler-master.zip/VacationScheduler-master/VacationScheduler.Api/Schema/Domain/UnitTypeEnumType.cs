﻿using GraphQL.Types;

namespace VacationScheduler.Api.Schema.Domain
{
    class UnitTypeEnumType : EnumerationGraphType<VacationScheduler.Domain.Enums.UnitType>
    { 
        public UnitTypeEnumType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
        }

    }
}
