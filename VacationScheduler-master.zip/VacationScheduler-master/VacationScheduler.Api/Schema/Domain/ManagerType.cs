﻿using GraphQL.Types;
using VacationScheduler.Domain.ValueObjects;

namespace VacationScheduler.Api.Schema.Domain
{
    public class ManagerType : ObjectGraphType<Manager>
    {
        public ManagerType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "Manager";

            Field(m => m.Login).Description("USer login");
            Field(m => m.EmployeeNumber).Description("User employee number");
            Field(m => m.Fio).Description("Fio");
            Field(m => m.Email).Description("User email");
        }
    }
}
