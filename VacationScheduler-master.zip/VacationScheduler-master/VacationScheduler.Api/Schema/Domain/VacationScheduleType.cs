﻿using GraphQL.Types;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;

namespace VacationScheduler.Api.Schema.Domain
{
    public sealed class VacationScheduleType : ObjectGraphType<VacationSchedule>
    {
        public VacationScheduleType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "Vacation schedule info";
            Field(e => e.Id).Description("Vacation schedule id");
            Field(e => e.Status, type: typeof(NonNullGraphType<EnumerationGraphType<ScheduleStatus>>))
                .Description("Vacation schedule status");
            Field(e => e.Name).Description("Vacation schedule name");
            Field(e => e.EmployeesSchedules,
                    type: typeof(NonNullGraphType<ListGraphType<NonNullGraphType<EmployeeVacationScheduleType>>>))
                .Description("Employees vacation schedules");
            Field(e => e.EmployeesSchedulesForInformation,
                    type: typeof(NonNullGraphType<ListGraphType<NonNullGraphType<EmployeeVacationScheduleType>>>))
                .Description("Informational employees vacation schedules");
            Field(e => e.Year).Description("Vacation schedule year of creation");
            Field(e => e.UnitId).Description("Vacation schedule unit id");
            Field(e => e.UnitType, type: typeof(NonNullGraphType<UnitTypeEnumType>))
                .Description("Vacation schedule unit type");

        }
    }
}
