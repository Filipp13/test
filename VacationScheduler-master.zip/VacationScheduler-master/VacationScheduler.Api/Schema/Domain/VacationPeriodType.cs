﻿using GraphQL.Types;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;

namespace VacationScheduler.Api.Schema.Domain
{
    public sealed class VacationPeriodType : ObjectGraphType<VacationPeriod>
    {
        public VacationPeriodType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "Vacation period info";
            Field(e => e.Id).Description("Period id");
            Field(e => e.Type, type: typeof(NonNullGraphType<EnumerationGraphType<PeriodType>>))
                .Description("Period type");
            Field(e => e.From).Description("Period begin");
            Field(e => e.To).Description("Period end");
        }
    }
}
