﻿using GraphQL.Types;
using VacationScheduler.Domain.Services.CalendarService;

namespace VacationScheduler.Api.Schema.Domain
{
    public class CalendarDateType : ObjectGraphType<CalendarDate>
    {
        public CalendarDateType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "Calendar date";

            Field(m => m.CalendarId).Description("Calendar id");
            Field(m => m.Date).Description("Date");
        }
    }
}
