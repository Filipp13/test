﻿using System;
using System.Collections.Generic;
using GraphQL;
using GraphQL.Types;
using VacationScheduler.Api.Schema.InputTypes;
using VacationScheduler.Api.Schema.Requests.TransferVacationScheduleToStatusCommandType;
using VacationScheduler.Application.Commands.TransferVacationScheduleToStatusCommand;
using VacationScheduler.Application.Commands.UpdateEmployeeVacationSchedule;
using ViennaNET.Mediator;

namespace VacationScheduler.Api.Schema
{
    internal class Mutation : ObjectGraphType
    {
        private const string CommandPrefix = VacationSchedulerSchema.SchemaPrefix;
        private const string RequestArgumentName = "request";
        private readonly IMediator _mediator;

        public Mutation(IMediator mediator)
        {
            _mediator = mediator;
            InitializeFields();
        }

        private void InitializeFields()
        {
            AddCommandField<UpdateEmployeeVacationScheduleCommandType, UpdateEmployeeVacationScheduleCommand>(
                "Возникла ошибка при обновлении графика отпусков сотрудника");
            AddCommandField<TransferVacationScheduleToStatusCommandType, TransferVacationScheduleToStatusCommand>(
                "При попытке изменить статус возникла ошибка");
        }

        private void AddCommandField<TArgument, TCommand>(string errorMessage)
            where TArgument : InputObjectGraphType<TCommand>
            where TCommand : class, ICommand
        {
            FieldAsync<BooleanGraphType>(
                CommandPrefix + typeof(TCommand).Name,
                arguments: new QueryArguments(
                    new QueryArgument<NonNullGraphType<TArgument>> { Name = RequestArgumentName }
                ),
                resolve: async context =>
                {
                    var command = context.GetArgument<TCommand>(RequestArgumentName);

                    try
                    {
                        await _mediator.SendMessageAsync(command, context.CancellationToken);
                        return true;
                    }
                    catch (Exception exception)
                    {
                        context.Errors.Add(new ExecutionError(errorMessage, GetErrorMessages(exception)));
                        return false;
                    }
                }
            );
        }

        private static Dictionary<string, string> GetErrorMessages(Exception exception)
        {
            return new Dictionary<string, string>
            {
                {"Error", exception.InnerException?.Message ?? exception.Message }
            };
        }
    }
}
