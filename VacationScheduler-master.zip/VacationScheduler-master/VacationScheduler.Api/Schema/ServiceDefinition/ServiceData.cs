﻿using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace VacationScheduler.Api.Schema.ServiceDefinition
{
    [ExcludeFromCodeCoverage]
    internal class ServiceData
    {
        /// <summary>
        /// Описание сервиса (для graphql потребителя)
        /// </summary>
        [JsonProperty(PropertyName = "_service")]
        public ServiceDefinition Service { get; set; }

        internal ServiceData(string serviceData)
        {
            Service = new ServiceDefinition
            {
                Sdl = serviceData
            };
        }
    }
}
