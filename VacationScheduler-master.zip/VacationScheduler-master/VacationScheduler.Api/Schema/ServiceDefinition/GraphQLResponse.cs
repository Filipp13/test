﻿using System.Diagnostics.CodeAnalysis;

namespace VacationScheduler.Api.Schema.ServiceDefinition
{
    [ExcludeFromCodeCoverage]
    internal class GraphQlResponse
    {
        public ServiceData Data { get; set; }
    }
}
