﻿using System.Diagnostics.CodeAnalysis;

namespace VacationScheduler.Api.Schema.ServiceDefinition
{
    [ExcludeFromCodeCoverage]
    internal class ServiceDefinition
    {
        public string Sdl { get; set; }
    }
}
