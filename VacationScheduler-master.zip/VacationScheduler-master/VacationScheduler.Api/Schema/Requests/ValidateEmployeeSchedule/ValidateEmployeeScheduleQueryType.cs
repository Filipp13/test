﻿using GraphQL.Types;
using VacationScheduler.Api.Schema.InputTypes;
using VacationScheduler.Application.Queries.ValidateEmployeeSchedule;

namespace VacationScheduler.Api.Schema.Requests.ValidateEmployeeSchedule
{
    class ValidateEmployeeScheduleQueryType : InputObjectGraphType<ValidateEmployeeScheduleQuery>
    {
        public ValidateEmployeeScheduleQueryType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "An employee schedule validation query";
            Field(s => s.EmployeeVacationScheduleId).Description("Employee vacation schedule Id");
            Field(s => s.VacationScheduleId).Description("Vacation schedule Id");
            Field(s => s.ScheduledPeriods,
                    type: typeof(NonNullGraphType<ListGraphType<NonNullGraphType<VacationPeriodDtoType>>>))
                .Description("Scheduled periods");
        }
    }
}
