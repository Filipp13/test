﻿using GraphQL.Types;
using VacationScheduler.Application.Queries.ValidateEmployeeSchedule;

namespace VacationScheduler.Api.Schema.Requests.ValidateEmployeeSchedule
{
    class ValidateEmployeeScheduleQueryResultType : ObjectGraphType<ValidateEmployeeScheduleQueryResult>
    {
        public ValidateEmployeeScheduleQueryResultType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "An employee schedule validation result";
            Field(r => r.IsValid).Description("Is employee schedule overall valid");
            Field(r => r.Errors, type: typeof(NonNullGraphType<ListGraphType<NonNullGraphType<StringGraphType>>>))
                .Description("List of employee schedule errors");
        }
    }
}
