﻿using GraphQL.Types;
using VacationScheduler.Api.Schema.Domain;
using VacationScheduler.Application.Queries.GetAvailableSchedules;

namespace VacationScheduler.Api.Schema.Requests.GetAvailableSchedules
{
    public class GetAvailableSchedulesQueryResultType : ObjectGraphType<GetAvailableSchedulesQueryResult>
    {
        public GetAvailableSchedulesQueryResultType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "All available schedules list dto";
            Field(d => d.MyOwnSchedule, type: typeof(VacationScheduleType)).Description("Own schedule, may be null");
            Field(d => d.ManagedSchedules,
                    type: typeof(NonNullGraphType<ListGraphType<NonNullGraphType<VacationScheduleType>>>))
                .Description("Managed schedules, for responsible managers and HRs");
        }
    }
}
