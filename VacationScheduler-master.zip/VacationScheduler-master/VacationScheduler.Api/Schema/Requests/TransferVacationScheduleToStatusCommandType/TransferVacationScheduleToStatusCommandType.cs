﻿using GraphQL.Types;
using VacationScheduler.Application.Commands.TransferVacationScheduleToStatusCommand;
using VacationScheduler.Domain.Enums;

namespace VacationScheduler.Api.Schema.Requests.TransferVacationScheduleToStatusCommandType
{
    public sealed class TransferVacationScheduleToStatusCommandType : InputObjectGraphType<TransferVacationScheduleToStatusCommand>
    {
        public TransferVacationScheduleToStatusCommandType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "Mutation to change status";
            Field(s => s.VacationScheduleId).Description("Vacation schedule id");
            Field(s => s.DesiredStatus, type: typeof(NonNullGraphType<EnumerationGraphType<ScheduleStatus>>)).Description("Desired status");
        }
    }
}
