﻿using GraphQL.Types;
using VacationScheduler.Api.Schema.Domain;
using VacationScheduler.Application.Queries.GetSpecifiedVacationSchedule;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Domain.Services.PermissionService;

namespace VacationScheduler.Api.Schema.Requests.GetSpecifiedVacationSchedule
{
    class GetSpecifiedVacationScheduleQueryResultType : ObjectGraphType<GetSpecifiedVacationScheduleQueryResult>
    {
        public GetSpecifiedVacationScheduleQueryResultType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "Specified vacation schedule query result";

            Field(e => e.Id).Description("Vacation schedule id");
            Field(e => e.Status, type: typeof(NonNullGraphType<EnumerationGraphType<ScheduleStatus>>))
                .Description("Vacation schedule status");
            Field(e => e.Name).Description("Vacation schedule name");
            Field(r => r.EmployeesSchedules,
                    type: typeof(NonNullGraphType<ListGraphType<NonNullGraphType<EmployeeScheduleItemType>>>))
                .Description("Employee schedules with actions allowed");
            Field(e => e.EmployeesSchedulesForInformation,
                    type: typeof(NonNullGraphType<ListGraphType<NonNullGraphType<EmployeeVacationScheduleType>>>))
                .Description("Informational employees vacation schedules");
            Field(e => e.Year).Description("Vacation schedule year of creation");
            Field(e => e.ResponsibleManagers,
                    type: typeof(NonNullGraphType<ListGraphType<NonNullGraphType<ManagerType>>>))
                .Description("Informational employees vacation schedules");
            Field(e => e.HolidayDates,
                    type: typeof(NonNullGraphType<ListGraphType<NonNullGraphType<CalendarDateType>>>))
                .Description("Holiday dates in the current schedule");
            Field(e => e.VacationScheduleActions,
                    type: typeof(NonNullGraphType<
                        ListGraphType<NonNullGraphType<EnumerationGraphType<VacationScheduleAction>>>>))
                .Description("Vacation schedule actions");
        }
    }
}
