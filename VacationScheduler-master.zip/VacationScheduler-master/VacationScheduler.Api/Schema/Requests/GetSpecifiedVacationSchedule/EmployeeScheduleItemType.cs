﻿using GraphQL.Types;
using VacationScheduler.Api.Schema.Domain;
using VacationScheduler.Application.Queries.GetSpecifiedVacationSchedule;
using VacationScheduler.Domain.Services.PermissionService;

namespace VacationScheduler.Api.Schema.Requests.GetSpecifiedVacationSchedule
{
    public class EmployeeScheduleItemType : ObjectGraphType<EmployeeScheduleItem>
    {
        public EmployeeScheduleItemType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "Specified vacation schedule query result";
            Field(e => e.EmployeeSchedule, type: typeof(NonNullGraphType<EmployeeVacationScheduleType>))
                .Description("Employee vacation schedule");
            Field(e => e.Actions,
                    type: typeof(NonNullGraphType<
                        ListGraphType<NonNullGraphType<EnumerationGraphType<EmployeeScheduleAction>>>>))
                .Description("Allowed actions");
        }
    }
}
