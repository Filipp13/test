﻿using GraphQL.Types;
using VacationScheduler.Application.Queries.GetSpecifiedVacationSchedule;

namespace VacationScheduler.Api.Schema.Requests.GetSpecifiedVacationSchedule
{
    class GetSpecifiedVacationScheduleQueryType : InputObjectGraphType<GetSpecifiedVacationScheduleQuery>
    {
        public GetSpecifiedVacationScheduleQueryType()
        {
            Name = VacationSchedulerSchema.SchemaPrefix + GetType().Name;
            Description = "A query to get specified vacation schedule";
            Field(s => s.VacationScheduleId).Description("Vacation schedule Id");
        }
    }
}
