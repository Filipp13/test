﻿namespace VacationScheduler.Api.Helpers
{
    internal static class CacheHelper
    {
        public static string GetHolidayCalendarDatesCacheKey(int year) => $"HolidayCalendarDates{ year }";

        public static string GetHolidayDatesSetCacheKey(int year, int calendarId) =>
            $"HolidayDatesSet{year}calendarId{calendarId}";

        public static string GetHolidayAndDayOffsDatesSetCacheKey(int year, int calendarId) =>
            $"HolidayAndDayOffsDatesSet{year}calendarId{calendarId}";
    }
}
