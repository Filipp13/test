﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.Logging;

namespace VacationScheduler.Api.Helpers
{
    [ExcludeFromCodeCoverage]
    internal static class ErrorHandlingHelper
    {
        public static Dictionary<string, string> GetErrorMessages(Exception exception, ILogger logger)
        {
            var dictionary = new Dictionary<string, string>();

            if (exception is AggregateException originalAggregateException)
            {
                foreach (var ex in originalAggregateException.InnerExceptions)
                {
                    logger.LogError(ex, "Произошла неизвестная ошибка при обработке GraphQL запроса.");
                    dictionary.Add("Error", $"{ex.Message}");
                }
            }
            else
            {
                logger.LogError(exception, "Произошла неизвестная ошибка при обработке GraphQL запроса.");
                dictionary.Add("Error", $"{exception.Message}");
            }

            return dictionary;
        }
    }
}
