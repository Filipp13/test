﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using VacationScheduler.Application.Commands.SynchronizeHolidayDates;
using ViennaNET.Mediator;

namespace VacationScheduler.Api.Controllers
{
    [ExcludeFromCodeCoverage]
    [Route("api/[controller]")]
    [AllowAnonymous]
    public sealed class JobsController : Controller
    {
        private readonly IMediator _mediator;
        private readonly ILogger _logger;

        public JobsController(IMediator mediator, ILogger<JobsController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        [HttpPost("SynchronizeHolidayDates")]
        public async Task<IActionResult> SynchronizeHolidayDates()
        {
            await SendMessageWithLogging<SynchronizeHolidayDatesCommand>();

            return Ok();
        }

        private Task SendMessageWithLogging<T>() where T : class, ICommand, new()
        {
            return SendMessageWithLogging(Activator.CreateInstance<T>());
        }

        private async Task SendMessageWithLogging<T>(T command) where T : class, ICommand
        {
            var timer = Stopwatch.StartNew();

            using var scope = _logger.BeginScope(new Dictionary<string, object>() {{"Job", typeof(T).Name}});

            try
            {
                _logger.LogInformation("Job {JobName} started", typeof(T).Name);
                await _mediator.SendMessageAsync(command);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Job {JobName} failed", typeof(T).Name);
                throw;
            }
            finally
            {
                timer.Stop();
                var timespan = timer.Elapsed;
                _logger.LogInformation("Job {JobName} ended in: {Timespan}", typeof(T).Name, timespan);
            }
        }
    }
}
