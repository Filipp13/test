﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using GraphQL;
using GraphQL.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VacationScheduler.Api.Schema;
using VacationScheduler.Api.Schema.ServiceDefinition;

namespace VacationScheduler.Api.Controllers
{
    [ExcludeFromCodeCoverage]
    [Route("[controller]")]
    public class GraphQlController : Controller
    {
        private readonly IDocumentExecuter _documentExecuter;
        private readonly VacationSchedulerSchema _schema;

        public GraphQlController(VacationSchedulerSchema schema, IDocumentExecuter documentExecuter)
        {
            _schema = schema;
            _documentExecuter = documentExecuter;
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Post([FromBody] GraphQlQuery query)
        {
            if (query == null)
            {
                throw new ArgumentNullException(nameof(query));
            }

            // Only graphql scheme is available for anonymous user
            if (query.Query.Contains("_service"))
            {
                var sdl = new SchemaPrinter(_schema).Print();
                return Ok(new GraphQlResponse { Data = new ServiceData(sdl) });
            }

            // Only authorized users are allowed to proceed
            if (User?.Identity?.IsAuthenticated != true)
            {
                return Unauthorized();
            }

            var inputs = query.Variables.ToInputs();
            var executionOptions = new ExecutionOptions
            {
                Schema = _schema,
                Query = query.Query,
                Inputs = inputs,
                ExposeExceptions = false
            };

            var result = await _documentExecuter.ExecuteAsync(executionOptions).ConfigureAwait(false);

            return result.Errors?.Count > 0
                ? BadRequest(result)
                : (IActionResult)Ok(result);
        }
    }
}
