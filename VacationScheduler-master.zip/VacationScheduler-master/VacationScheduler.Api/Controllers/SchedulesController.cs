﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using VacationScheduler.Application.Commands.BuildSchedules;
using ViennaNET.Mediator;

namespace VacationScheduler.Api.Controllers
{
    [Route("api/[controller]")]
    [ExcludeFromCodeCoverage]
    public sealed class SchedulesController : Controller
    {
        private readonly IMediator _mediator;

        public SchedulesController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost("BuildSchedules")]
        public async Task<IActionResult> BuildSchedules(int scheduleYear)
        {
            await _mediator.SendMessageAsync(new BuildSchedulesCommand
            {
                ScheduleYear = scheduleYear
            });

            return Ok();
        }
    }
}
