﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ViennaNET.WebApi.Configurators.HttpClients.NoAuthentication;
using ViennaNET.WebApi.Runners.BaseKestrel;

namespace VacationScheduler.Api
{
    [ExcludeFromCodeCoverage]
    static class Program
    {
        static void Main(string[] args)
        {
            BaseKestrelRunner.Configure()
                .UseNoAuthHttpClients()
                .AddMvcBuilderConfiguration(ConfigureMvcBuilder)
                .BuildWebHost(args)
                .Run();
        }

        private static void ConfigureMvcBuilder(IMvcCoreBuilder builder, IConfiguration configuration)
        {
            builder.AddNewtonsoftJson();
        }
    }
}
