﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using VacationScheduler.Application.Commands.SynchronizeHolidayDates;
using BossKadrovik.Client;
using BossKadrovik.Client.Dto;
using VacationScheduler.Domain.Enums;

namespace VacationScheduler.Api.ServicesImplementations
{
    public class SynchronizeHolidayDatesService : ISynchronizeHolidayDatesService
    {
        private readonly IBossKadrovikClient _bossKadrovikClient;

        public SynchronizeHolidayDatesService(IBossKadrovikClient bossKadrovikClient)
        {
            _bossKadrovikClient = bossKadrovikClient;
        }

        public async Task<List<HolidayDateFormBoss>> GetResponsesFormBossAsync()
        {
            var responses = await _bossKadrovikClient.GetHolidayDatesAsync();
            return responses.Select(MapQueryResultToDto).ToList();
        }

        [ExcludeFromCodeCoverage]
        private static HolidayDateFormBoss MapQueryResultToDto(HolidayDateDto responseDto)
        {
            return new HolidayDateFormBoss
            {
                HolidayDate = responseDto.HolidayDate,
                CalendarName = responseDto.CalendarName,
                CalendarDayType = MapCalendarDayType(responseDto.Type),
                CalendarId = responseDto.CalendarId
            };
        }

        private static CalendarDayType MapCalendarDayType(string dayType) =>
            dayType switch
            {
                "праздничный" => CalendarDayType.Holiday,
                "выходной" => CalendarDayType.Dayoff,
                _ => throw new ArgumentException($"Unknown calendar type={dayType}")
            };

    }
}
