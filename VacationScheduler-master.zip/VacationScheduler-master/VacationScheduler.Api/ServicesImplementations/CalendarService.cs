﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using NHibernate.Linq;
using VacationScheduler.Api.Helpers;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Domain.Services.CalendarService;
using ViennaNET.Orm.Seedwork;

namespace VacationScheduler.Api.ServicesImplementations
{
    internal class CalendarService: ICalendarService
    {
        private static readonly TimeSpan cacheExpiration = TimeSpan.FromDays(1);
        private static readonly MemoryCacheEntryOptions memoryCacheEntryOptions =
            new MemoryCacheEntryOptions().SetSlidingExpiration(cacheExpiration);
        
        private readonly IMemoryCache _cache;
        private readonly IEntityRepositoryFactory _entityRepositoryFactory;

        public CalendarService(IEntityRepositoryFactory entityRepositoryFactory, IMemoryCache memoryCache)
        {
            _entityRepositoryFactory = entityRepositoryFactory;
            _cache = memoryCache;
        }
        
        public bool IsHoliday(DateTime date, int calendarId)
        {
            var holidaysSet = GetOrAddCachedValue(CacheHelper.GetHolidayDatesSetCacheKey(date.Year, calendarId), () =>
            {
                var calendarItems = _entityRepositoryFactory.Create<HolidayDate>()
                    .Query()
                    .Where(hd =>
                        hd.CalendarId == calendarId
                        && hd.HolidayDateValue >= GetYearFirstDate(date.Year)
                        && hd.HolidayDateValue <= GetYearLastDate(date.Year))
                    .Where(hd => hd.CalendarDayType == CalendarDayType.Holiday)
                    .ToList();

                return calendarItems.Select(d => d.HolidayDateValue.Date)
                    .ToHashSet();
            });

            return holidaysSet.Contains(date.Date);
        }

        public bool IsWorkingDay(DateTime date, int calendarId)
        {
            var holidaysAndDayOffsSet = GetOrAddCachedValue(
                CacheHelper.GetHolidayAndDayOffsDatesSetCacheKey(date.Year, calendarId), () =>
                {
                    var calendarItems = _entityRepositoryFactory.Create<HolidayDate>()
                        .Query()
                        .Where(hd =>
                            hd.CalendarId == calendarId
                            && hd.HolidayDateValue >= GetYearFirstDate(date.Year)
                            && hd.HolidayDateValue <= GetYearLastDate(date.Year))
                        .Where(hd =>
                            hd.CalendarDayType == CalendarDayType.Dayoff ||
                            hd.CalendarDayType == CalendarDayType.Holiday)
                        .ToList();

                    return calendarItems.Select(d => d.HolidayDateValue.Date)
                        .ToHashSet();
                });

            return !holidaysAndDayOffsSet.Contains(date.Date);
        }

        public Task<List<CalendarDate>> GetHolidayDatesAsync(int year, CancellationToken cancellationToken)
        {
            return GetOrAddCachedValueAsync(CacheHelper.GetHolidayCalendarDatesCacheKey(year), () =>
            {
                return _entityRepositoryFactory.Create<HolidayDate>()
                    .Query()
                    .Where(hd =>
                        hd.HolidayDateValue >= GetYearFirstDate(year) && hd.HolidayDateValue <= GetYearLastDate(year))
                    .Where(hd => hd.CalendarDayType == CalendarDayType.Holiday)
                    .Select(hd => new CalendarDate { CalendarId = hd.CalendarId, Date = hd.HolidayDateValue })
                    .ToListAsync(cancellationToken);
            });
        }
        
        private T GetOrAddCachedValue<T>(string cacheKey, Func<T> valueFactory) =>
            _cache.GetOrCreate(cacheKey, entry =>
            {
                var result = valueFactory();

                entry.Value = result;
                entry.AbsoluteExpirationRelativeToNow = cacheExpiration;

                return result;
            });

        private Task<T> GetOrAddCachedValueAsync<T>(string cacheKey, Func<Task<T>> valueFactory) =>
            _cache.GetOrCreateAsync(cacheKey, async entry =>
            {
                var result = await valueFactory();

                entry.Value = result;
                entry.AbsoluteExpirationRelativeToNow = cacheExpiration;

                return result;
            });

        private static DateTime GetYearFirstDate(int year) =>
            new DateTime(year, 1, 1);
        private static DateTime GetYearLastDate(int year) =>
            new DateTime(year, 12, 31);
    }
}
