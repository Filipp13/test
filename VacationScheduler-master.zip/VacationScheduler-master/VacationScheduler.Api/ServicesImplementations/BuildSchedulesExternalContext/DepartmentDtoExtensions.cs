﻿using System.Collections.Generic;
using CnB.HRIntegrationService.Client.Dto;

namespace VacationScheduler.Api.ServicesImplementations.BuildSchedulesExternalContext
{
    internal static class DepartmentDtoExtensions
    {
        public static IEnumerable<DepartmentDto> GetAllDepartmentDtosRecursively(
            this IEnumerable<DepartmentDto> departments)
        {
            foreach (var department in departments)
            {
                yield return department;

                if (department.Children == null)
                {
                    continue;
                }

                foreach (var childDepartment in GetAllDepartmentDtosRecursively(department.Children))
                {
                    yield return childDepartment;
                }
            }
        }
    }
}
