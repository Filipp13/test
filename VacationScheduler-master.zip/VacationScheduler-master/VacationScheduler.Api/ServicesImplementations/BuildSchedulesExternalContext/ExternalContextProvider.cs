﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using CnB.HRIntegrationService.Client;
using Home.Client;
using Home.Client.Dto;
using VacationScheduler.Application.Commands.BuildSchedules.ExternalContext;

namespace VacationScheduler.Api.ServicesImplementations.BuildSchedulesExternalContext
{
    internal sealed class ExternalContextProvider : IExternalContextProvider
    {
        private readonly IHrIntegrationServiceClient _hrIntegrationClient;
        private readonly IHomeClient _homeClient;

        public ExternalContextProvider(IHrIntegrationServiceClient hrIntegrationClient, IHomeClient homeClient)
        {
            _hrIntegrationClient = hrIntegrationClient;
            _homeClient = homeClient;
        }

        public async Task<IExternalContext> GetExternalContextAsync(CancellationToken cancellationToken)
        {
            var departments = await _hrIntegrationClient.GetDepartments();
            var employees = await _hrIntegrationClient.GetEmployees();

            var teamDtos = await _homeClient.GetTeams(cancellationToken);

            var teams = teamDtos.Where(TeamsHelper.IsAgileTeam)
                .Select(MapTeamDtoToTeam)
                .ToArray();

            return new ExternalContext(departments, employees, teams);
        }

        private static Team MapTeamDtoToTeam(TeamDto team) =>
            new Team()
            {
                Id = team.Id,
                Name = team.Name,
                MembersEmployeeNumbers = team.FteTeamRelations.Where(TeamsHelper.IsCurrentlyTeamMember)
                    .Where(r => !TeamsHelper.HasLinearActivity(r))
                    .Select(r => r.Fte.EmployeeNumber)
                    .ToArray(),
                OwnersEmployeeNumbers = team.LeaderRelations.Where(TeamsHelper.IsOwner)
                    .Select(r => r.Employee.EmployeeNumber)
                    .ToArray(),
                TechLeadsEmployeeNumbers = team.LeaderRelations.Where(TeamsHelper.IsTechLead)
                    .Select(r => r.Employee.EmployeeNumber)
                    .ToArray(),
                ScrumMastersEmployeeNumbers = team.LeaderRelations.Where(TeamsHelper.IsScrumMaster)
                    .Select(r => r.Employee.EmployeeNumber)
                    .ToArray()
            };
    }
}
