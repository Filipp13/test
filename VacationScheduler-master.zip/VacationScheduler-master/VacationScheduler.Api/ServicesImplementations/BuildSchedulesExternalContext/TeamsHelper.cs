﻿using System;
using Home.Client.Dto;

namespace VacationScheduler.Api.ServicesImplementations.BuildSchedulesExternalContext
{
    internal static class TeamsHelper
    {
        private const string OwnerRole = "Owner";
        private const string TechLeadRole = "Tech Lead";
        private const string ScrumMasterRole = "Scrum Master";
        private const string TeamsEngagementNonTeamActivity = "NON_TEAM_ACTIVITY_EXISTS";

        private static readonly string[] otsRoles = {OwnerRole, TechLeadRole, ScrumMasterRole};

        public static bool IsAgileTeam(TeamDto team) => !team.TeamType.IsCommunity;

        public static bool IsOwner(RelationDto leader) => leader.Role.Name == OwnerRole;
        
        public static bool IsTechLead(RelationDto leader) => leader.Role.Name == TechLeadRole;
        
        public static bool IsScrumMaster(RelationDto leader) => leader.Role.Name == ScrumMasterRole;

        public static bool IsCurrentlyTeamMember(FteTeamRelationDto teamMember) =>
            (teamMember.StartDate == null || teamMember.StartDate <= DateTime.Today)
            && (teamMember.EndDate == null || DateTime.Today <= teamMember.EndDate);

        public static bool HasLinearActivity(FteTeamRelationDto teamMember) =>
            teamMember.Fte.TeamsEngagement == TeamsEngagementNonTeamActivity;
    }
}
