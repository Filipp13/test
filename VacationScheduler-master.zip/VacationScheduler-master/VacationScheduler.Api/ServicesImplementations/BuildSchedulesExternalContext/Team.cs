﻿using System.Collections.Generic;

namespace VacationScheduler.Api.ServicesImplementations.BuildSchedulesExternalContext
{
    public sealed class Team
    {
        public int Id { get; set; }
        
        public string  Name { get; set; }

        public IReadOnlyCollection<string> MembersEmployeeNumbers { get; set; } = new string[0];
        
        public IReadOnlyCollection<string> TechLeadsEmployeeNumbers { get; set; } = new string[0];
        
        public IReadOnlyCollection<string> OwnersEmployeeNumbers { get; set; } = new string[0];
        
        public IReadOnlyCollection<string> ScrumMastersEmployeeNumbers { get; set; } = new string[0];
    }
}
