﻿using System;
using System.Collections.Generic;
using System.Linq;
using CnB.HRIntegrationService.Client.Dto;
using VacationScheduler.Application.Commands.BuildSchedules.ExternalContext;
using ViennaNET.Utils;

namespace VacationScheduler.Api.ServicesImplementations.BuildSchedulesExternalContext
{
    class ExternalContext : IExternalContext
    {
        public ICollection<ExternalDepartment> AllDepartments => _allDepartments.Values;
        
        public ICollection<ExternalAgileTeam> AllTeams { get; }

        private Dictionary<ExternalEmployee, IEnumerable<ExternalAgileTeam>> _employeeIsOtsInTeams;

        private Dictionary<ExternalEmployee, IEnumerable<ExternalAgileTeam>> _employeeIsMemberInTeams;
        
        public bool IsEmployeeOts(ExternalEmployee employee)
        {
            return _employeeIsOtsInTeams.ContainsKey(employee);
        }

        public IEnumerable<ExternalAgileTeam> EmployeeIsOtsInTeams(ExternalEmployee employee)
        {
            return IsEmployeeOts(employee) ? _employeeIsOtsInTeams[employee] : Enumerable.Empty<ExternalAgileTeam>();
        }

        public bool IsEmployeeMemberOfAgileTeam(ExternalEmployee employee)
        {
            return _employeeIsMemberInTeams.ContainsKey(employee);
        }

        public IEnumerable<ExternalAgileTeam> EmployeeIsMemberOfAgileTeams(ExternalEmployee employee)
        {
            return IsEmployeeMemberOfAgileTeam(employee)
                ? _employeeIsMemberInTeams[employee]
                : Enumerable.Empty<ExternalAgileTeam>();
        }

        private readonly IDictionary<int, ExternalDepartment> _allDepartments;

        public ExternalContext(ICollection<DepartmentDto> departments, ICollection<EmployeeDto> employeeDtos,
            ICollection<Team> teams)
        {
            _allDepartments = new Dictionary<int, ExternalDepartment>(GetExternalDepartments(departments, null));
            
            foreach (var employeeDto in employeeDtos)
            {
                if (_allDepartments.TryGetValue(employeeDto.Department.Id, out var externalDepartment))
                {
                    externalDepartment.Employees.Add(
                        MapEmployeeDtoToExternal(employeeDto, externalDepartment.ExtraDays));
                }
            }

            var externalEmployeesByEmployeeNumber = _allDepartments.SelectMany(d => d.Value.Employees)
                .ToDictionary(e => e.EmployeeNumber);

            ExternalEmployee? GetExternalEmployee(string employeeNumber) =>
                externalEmployeesByEmployeeNumber.ContainsKey(employeeNumber)
                    ? externalEmployeesByEmployeeNumber[employeeNumber]
                    : null;
            
            foreach (var departmentDto in departments.GetAllDepartmentDtosRecursively())
            {
                if (_allDepartments.TryGetValue(departmentDto.Id, out var externalDepartment))
                {
                    SetupDepartmentManagers(departmentDto, externalDepartment, GetExternalEmployee);
                }
            }

            AllTeams = teams.Select(t => MapToExternalTeam(t, externalEmployeesByEmployeeNumber))
                .ToArray();

            _employeeIsOtsInTeams = AllTeams.SelectMany(t => t.Ots.Select(otsMember => (t, otsMember)))
                .GroupBy(pair => pair.otsMember)
                .ToDictionary(g => g.Key, g => g.Select(pair => pair.t));

            _employeeIsMemberInTeams = AllTeams.SelectMany(t => t.Employees.Select(member => (t, member)))
                .GroupBy(pair => pair.member)
                .ToDictionary(g => g.Key, g => g.Select(pair => pair.t));
        }

        private static ExternalAgileTeam MapToExternalTeam(Team team, Dictionary<string,ExternalEmployee> externalEmployeesByEmployeeNumber)
        {
            ISet<ExternalEmployee> GetExistingEmployees(IEnumerable<string> employeeNumbers) =>
                employeeNumbers.Where(externalEmployeesByEmployeeNumber.ContainsKey)
                    .Select(id => externalEmployeesByEmployeeNumber[id])
                    .ToHashSet();
            
            return new ExternalAgileTeam()
            {
                Id = team.Id,
                Name = team.Name,
                Employees = GetExistingEmployees(team.MembersEmployeeNumbers),
                Owners = GetExistingEmployees(team.OwnersEmployeeNumbers),
                TechLeads = GetExistingEmployees(team.TechLeadsEmployeeNumbers),
                ScrumMasters = GetExistingEmployees(team.ScrumMastersEmployeeNumbers),
            };
        }

        private static IEnumerable<KeyValuePair<int, ExternalDepartment>> GetExternalDepartments(
            IEnumerable<DepartmentDto> departments, ExternalDepartment? parent)
        {
            foreach (var dept in departments)
            {
                var externalDepartment = MapDepartmentDtoToExternal(dept);
                externalDepartment.Parent = parent;

                yield return new KeyValuePair<int, ExternalDepartment>(dept.Id, externalDepartment);

                foreach (var childrenParent in GetExternalDepartments(dept.Children, externalDepartment))
                {
                    yield return childrenParent;
                }
            }
        }

        private static ExternalDepartment MapDepartmentDtoToExternal(DepartmentDto departmentDto) =>
            new ExternalDepartment
            {
                Id = departmentDto.Id,
                Name = departmentDto.Name,
                ExtraDays = departmentDto.ExtraDays,
            };

        private static void SetupDepartmentManagers(DepartmentDto departmentDto, ExternalDepartment externalDepartment,
            Func<string, ExternalEmployee?> externalEmployeeGetter)
        {
            externalDepartment.AdminHead = departmentDto.AdministrativeHead.Return(a => externalEmployeeGetter(a!.Id));
            externalDepartment.FuncHeads =
                departmentDto.OtherManagerEmployees?.Select(e => externalEmployeeGetter(e.Id))
                    .Where(e => e != null)
                    .Select(e => e!)
                    .ToList()
                ?? new List<ExternalEmployee>();
        }

        private static ExternalEmployee MapEmployeeDtoToExternal(EmployeeDto employeeDto, int extraDays) =>
            new ExternalEmployee
            {
                EmployeeNumber = employeeDto.Id,
                EmployeeId = employeeDto.EmployeeId,
                Login = employeeDto.Login,
                Email = employeeDto.Email,
                FirstName = employeeDto.FirstNameRus,
                MiddleName = employeeDto.MiddleNameRus,
                LastName = employeeDto.LastNameRus,
                Position = employeeDto.Position,
                Region = employeeDto.RegionRus,
                Directorate = employeeDto.DirectorateRus,
                Division = employeeDto.DivisionRus,
                Department = employeeDto.DepartmentRus,
                Group = employeeDto.GroupRus,
                Sector = employeeDto.SectorRus,
                ExtraDays = extraDays
            };
    }
}
