﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HrManagerPermissions.Client;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Services.UserService;
using ViennaNET.Security;

namespace VacationScheduler.Api.ServicesImplementations
{
    internal class UserRepository : IUserRepository
    {
        private readonly IHrManagerPermissionsClient _hrManagerPermissionsClient;
        private readonly ISecurityContextFactory _securityContextFactory;

        public UserRepository(IHrManagerPermissionsClient hrManagerPermissionsClient, ISecurityContextFactory securityContextFactory)
        {
            _hrManagerPermissionsClient = hrManagerPermissionsClient;
            _securityContextFactory = securityContextFactory;
        }

        public async Task<IUser> GetUserAsync(string login)
        {
            var permissions = await _hrManagerPermissionsClient.GetHrUserPermissionsAsync(login);

            return new User(login, permissions.Select(p => p.EmployeeNumber));
        }

        public async Task<IUser> GetCurrentUserAsync()
        {
            var userContext = await _securityContextFactory.CreateAsync();

            var permissions = await _hrManagerPermissionsClient.GetHrUserPermissionsAsync(userContext.UserName);

            return new User(userContext.UserName, permissions.Select(p => p.EmployeeNumber));
        }

        private class User : IUser
        {
            private readonly ISet<string> _isHrForEmployeeNumbers;

            public string Login { get; }
            
            public bool IsHr => _isHrForEmployeeNumbers.Any();

            public User(string login, IEnumerable<string> isHrForEmployeeNumbers)
            {
                Login = login;
                _isHrForEmployeeNumbers = isHrForEmployeeNumbers.ToHashSet();
            }

            public bool IsHrForEmployee(string employeeNumber) => _isHrForEmployeeNumbers.Contains(employeeNumber);

            public bool IsHrForVacationSchedule(VacationSchedule schedule) => _isHrForEmployeeNumbers
                .Intersect(schedule.EmployeesSchedules.Select(e => e.EmployeeNumber)).Any();

            public IEnumerable<string> GetEmployeeNumbersWhereHr() => _isHrForEmployeeNumbers;
        }
    }
}
