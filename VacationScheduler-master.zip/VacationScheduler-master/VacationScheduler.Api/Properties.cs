﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("VacationScheduler.Tests")]
