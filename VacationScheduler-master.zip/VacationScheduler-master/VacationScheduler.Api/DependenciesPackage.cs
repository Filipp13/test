using SimpleInjector;
using SimpleInjector.Packaging;
using VacationScheduler.Api.ServicesImplementations;
using VacationScheduler.Application.Commands.SynchronizeHolidayDates;
using ViennaNET.Mediator.DefaultConfiguration;
using ViennaNET.Orm.DefaultConfiguration;
using ViennaNET.Orm.Oracle.DefaultConfiguration;
using ViennaNET.Orm.PostgreSql.DefaultConfiguration;
using ViennaNET.SimpleInjector.Extensions;

namespace VacationScheduler.Api
{
    public class DependenciesPackage : IPackage
    {
        public void RegisterServices(Container container)
        {
            container.AddPackage(new MediatorPackage())
                .AddPackage(new PostgreSqlOrmPackage())
                .AddPackage(new OrmPackage())
                .AddPackage(new OracleOrmPackage());

            container.Register<ISynchronizeHolidayDatesService, SynchronizeHolidayDatesService>(Lifestyle.Singleton);
        }
    }
}
