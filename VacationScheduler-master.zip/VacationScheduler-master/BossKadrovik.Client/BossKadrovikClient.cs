﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using BossKadrovik.Client.CustomQueries;
using BossKadrovik.Client.Dto;
using ViennaNET.Orm.Application;
using Microsoft.Extensions.Logging;

namespace BossKadrovik.Client
{
    [ExcludeFromCodeCoverage]
    public class BossKadrovikClient : IBossKadrovikClient
    {
        private readonly ILogger _logger;
        private readonly IEntityFactoryService _entityFactoryService;

        public BossKadrovikClient(IEntityFactoryService entityFactoryService, ILogger<BossKadrovikClient> logger)
        {
            _entityFactoryService = entityFactoryService;
            _logger = logger;
        }

        public async Task<List<HolidayDateDto>> GetHolidayDatesAsync()
        {
            var result = await _entityFactoryService
                .CreateCustomQueryExecutor<HolidayDateDto>()
                .CustomQueryAsync(new HolidayDatesQuery(_logger));

            return result.ToList();
        }
    }
}
