﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace BossKadrovik.Client.Dto
{
    [ExcludeFromCodeCoverage]
    public class HolidayDateDto
    {
        public int CalendarId { get; set; }

        public DateTime HolidayDate { get; set; }
        
        public string Type { get; set; }

        public string CalendarName { get; set; }
    }
}
