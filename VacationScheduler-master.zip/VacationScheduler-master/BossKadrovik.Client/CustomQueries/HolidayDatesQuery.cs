﻿using System;
using System.Diagnostics.CodeAnalysis;
using BossKadrovik.Client.Dto;
using ViennaNET.Orm.Repositories;
using Microsoft.Extensions.Logging;

namespace BossKadrovik.Client.CustomQueries
{
    [ExcludeFromCodeCoverage]
    public class HolidayDatesQuery : BaseQuery<HolidayDateDto>
    {
        private readonly ILogger _logger;
        private const string Query = @"
            select 		            
                CALENDARID,	--	0
                D, 	--	1
                TYPE_DAY, -- 2
                RNAME	--	3
            from 
                b2_hr.RBA_KEDO_CALEND
            where 
                    TYPE_DAY = 'праздничный' 
                or 
                    TYPE_DAY='выходной'";

        public HolidayDatesQuery(ILogger logger)
        {
            _logger = logger;
            Sql = Query;
        }


        protected override HolidayDateDto TransformTuple(object[] tuple, string[] aliases)
        {
            try
            {
                return new HolidayDateDto
                {
                    CalendarId = Convert.ToInt32(tuple[0]),
                    HolidayDate = DateTime.Parse(tuple[1].ToString()),
                    Type = tuple[2].ToString(),
                    CalendarName = tuple[3].ToString()
                };
            }
            catch (Exception e)
            {
                _logger.LogError(e,
                    $"Error occured during boss holiday date record to dto mapping, CalendarId={tuple[0]}, HolidayDate={tuple[1]}, Type = {tuple[2]}, CalendarName={tuple[3]}");
                throw;
            }
        }
    }
}
