﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BossKadrovik.Client.Dto;

namespace BossKadrovik.Client
{
    public interface IBossKadrovikClient
    {
        Task<List<HolidayDateDto>> GetHolidayDatesAsync();
    }
}
