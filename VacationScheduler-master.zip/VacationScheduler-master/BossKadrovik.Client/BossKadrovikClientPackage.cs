﻿using SimpleInjector;
using SimpleInjector.Packaging;
using ViennaNET.Orm.Seedwork;

namespace BossKadrovik.Client
{
    public class BossKadrovikClientPackage : IPackage
    {
        public void RegisterServices(Container container)
        {
            container.Register<IBossKadrovikClient, BossKadrovikClient>(Lifestyle.Singleton);
            container.Collection.Append<IBoundedContext, BossKadrovikClientContext>(Lifestyle.Singleton);
        }
    }
}
