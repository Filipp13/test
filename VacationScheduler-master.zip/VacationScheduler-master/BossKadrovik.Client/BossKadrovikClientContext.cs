﻿using BossKadrovik.Client.Dto;
using ViennaNET.Orm;

namespace BossKadrovik.Client
{
    public class BossKadrovikClientContext : ApplicationContext
    {
        public BossKadrovikClientContext()
        {
            AddCustomQuery<HolidayDateDto>("BossKadrovik");
        }
    }
}
