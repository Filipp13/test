﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace VacationScheduler.Application.Exceptions
{
    [Serializable]
    public class TransferVacationScheduleException : Exception
    {
        public TransferVacationScheduleException(string message) : base(message)
        {
        }

        [ExcludeFromCodeCoverage]
        protected TransferVacationScheduleException([NotNull] SerializationInfo info, StreamingContext context) : base(info,
            context)
        {
        }
    }
}
