﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace VacationScheduler.Application.Exceptions
{
    [Serializable]
    public class DbObjectNotFoundException : Exception
    {
        public DbObjectNotFoundException(string message) : base(message)
        {
        }

        [ExcludeFromCodeCoverage]
        protected DbObjectNotFoundException([NotNull] SerializationInfo info, StreamingContext context) : base(info,
            context)
        {
        }
    }
}
