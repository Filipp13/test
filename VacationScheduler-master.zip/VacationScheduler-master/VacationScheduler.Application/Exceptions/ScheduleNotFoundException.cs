﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace VacationScheduler.Application.Exceptions
{
    [Serializable]
    public class ScheduleNotFoundException : Exception
    {
        public ScheduleNotFoundException(string message) : base(message)
        {
        }

        [ExcludeFromCodeCoverage]
        protected ScheduleNotFoundException([NotNull] SerializationInfo info, StreamingContext context) : base(info,
            context)
        {
        }
    }
}
