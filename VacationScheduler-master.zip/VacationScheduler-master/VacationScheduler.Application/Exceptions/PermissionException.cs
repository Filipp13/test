﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace VacationScheduler.Application.Exceptions
{
    [Serializable]
    public class PermissionException : Exception
    {
        public PermissionException(string message) : base(message)
        {
        }

        [ExcludeFromCodeCoverage]
        protected PermissionException([NotNull] SerializationInfo info, StreamingContext context) : base(info,
            context)
        {
        }
    }
}
