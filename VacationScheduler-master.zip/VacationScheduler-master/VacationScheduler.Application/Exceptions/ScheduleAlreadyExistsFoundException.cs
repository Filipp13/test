﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace VacationScheduler.Application.Exceptions
{
    [Serializable]
    public class ScheduleAlreadyExistsFoundException : Exception
    {
        public ScheduleAlreadyExistsFoundException(string message) : base(message)
        {
        }

        [ExcludeFromCodeCoverage]
        protected ScheduleAlreadyExistsFoundException([NotNull] SerializationInfo info, StreamingContext context) : base(info,
            context)
        {
        }
    }
}
