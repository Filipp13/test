﻿using SimpleInjector;
using SimpleInjector.Packaging;
using ViennaNET.Mediator;

namespace VacationScheduler.Application
{
    public class ApplicationPackage : IPackage
    {
        public void RegisterServices(Container container)
        {
            foreach (var handler in container.GetTypesToRegister<IMessageHandlerAsync>(GetType().Assembly))
            {
                container.Collection.Append(typeof(IMessageHandlerAsync), handler, Lifestyle.Singleton);
            }
        }
    }
}
