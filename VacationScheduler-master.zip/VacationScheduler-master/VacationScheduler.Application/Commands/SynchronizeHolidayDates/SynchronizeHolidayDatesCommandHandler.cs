﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NHibernate.Linq;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Exceptions;
using ViennaNET.Mediator;
using ViennaNET.Orm.Application;

namespace VacationScheduler.Application.Commands.SynchronizeHolidayDates
{
    public class SynchronizeHolidayDatesCommandHandler : IMessageHandlerAsync<SynchronizeHolidayDatesCommand>
    {
        private readonly IEntityFactoryService _entityFactoryService;
        private readonly ISynchronizeHolidayDatesService _synchronizeHolidayDatesService;
        private readonly ILogger _logger;


        public SynchronizeHolidayDatesCommandHandler(IEntityFactoryService entityFactoryService,
            ISynchronizeHolidayDatesService synchronizeHolidayDatesService,
            ILogger<SynchronizeHolidayDatesCommandHandler> logger)
        {
            _synchronizeHolidayDatesService = synchronizeHolidayDatesService;
            _logger = logger;
            _entityFactoryService = entityFactoryService;
        }

        public async Task HandleAsync(SynchronizeHolidayDatesCommand message, CancellationToken cancellationToken)
        {
            try
            {
                _logger.LogInformation("Загрузка праздничных дней из БОСС начата");
                var responsesFormBoss = await _synchronizeHolidayDatesService.GetResponsesFormBossAsync();
                _logger.LogInformation(
                    $"Загрузка праздничных дней из БОСС закончена получено - {responsesFormBoss.Count} записей");
                using var unitOfWork = _entityFactoryService.Create();
                var applicationRepository = _entityFactoryService.Create<HolidayDate>();

                await applicationRepository.Query().DeleteAsync(cancellationToken);

                var newHolidayDates = responsesFormBoss.Select(MapResponseFormBossToHolidayDate);

                foreach (var item in newHolidayDates)
                {
                    await applicationRepository.InsertAsync(item, cancellationToken);
                }

                await unitOfWork.CommitAsync(cancellationToken);
                _logger.LogInformation("Синхронизация праздничных дней c БОСС закончена");
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Во время синхронизации праздничных дней c БОСС произошла ошибка");
                throw new SynchronizeHolidayDatesException(
                    "Во время загрузки праздничных дней из БОСС произошла ошибка");
            }
        }

        private static HolidayDate MapResponseFormBossToHolidayDate(HolidayDateFormBoss responseDto)
        {
            return new HolidayDate
            {
                HolidayDateValue = responseDto.HolidayDate,
                CalendarName = responseDto.CalendarName,
                CalendarId = responseDto.CalendarId,
                CalendarDayType = responseDto.CalendarDayType,
                UploadDate = DateTime.Now
            };
        }
    }
}
