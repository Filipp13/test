﻿using System.Diagnostics.CodeAnalysis;
using ViennaNET.Mediator;

namespace VacationScheduler.Application.Commands.SynchronizeHolidayDates
{
    [ExcludeFromCodeCoverage]
    public class SynchronizeHolidayDatesCommand : ICommand
    {
        public bool IsCompleted { get; set; }

        public object Reason { get; set; }
    }
}
