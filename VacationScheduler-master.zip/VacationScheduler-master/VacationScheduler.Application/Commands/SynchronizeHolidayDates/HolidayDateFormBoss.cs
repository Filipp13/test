﻿using System;
using VacationScheduler.Domain.Enums;

namespace VacationScheduler.Application.Commands.SynchronizeHolidayDates
{
    public class HolidayDateFormBoss
    {
        public int CalendarId { get; set; }

        public DateTime HolidayDate { get; set; }

        public CalendarDayType CalendarDayType { get; set; }

        public string CalendarName { get; set; }
    }
}
