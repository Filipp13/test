﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace VacationScheduler.Application.Commands.SynchronizeHolidayDates
{
    public interface ISynchronizeHolidayDatesService
    {
        Task<List<HolidayDateFormBoss>> GetResponsesFormBossAsync();
    }
}
