﻿using System.Collections.Generic;
using VacationScheduler.Domain.Entities;
using ViennaNET.Mediator;

namespace VacationScheduler.Application.Commands.UpdateEmployeeVacationSchedule
{
    public class UpdateEmployeeVacationScheduleCommand : ICommand
    {
        public bool IsCompleted { get; set; }

        public object Reason { get; set; }

        public int VacationScheduleId { get; set; }

        public int EmployeeVacationScheduleId { get; set; }

        public List<VacationPeriod> ScheduledPeriods { get; set; }
    }
}
