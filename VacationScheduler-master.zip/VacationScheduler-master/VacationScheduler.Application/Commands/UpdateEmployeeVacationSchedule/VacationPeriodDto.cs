﻿using System;
using VacationScheduler.Domain.Enums;

namespace VacationScheduler.Application.Commands.UpdateEmployeeVacationSchedule
{
    public class VacationPeriodDto
    {
        public virtual PeriodType Type { get; set; }

        public virtual DateTime From { get; set; }

        public virtual DateTime To { get; set; }
    }
}
