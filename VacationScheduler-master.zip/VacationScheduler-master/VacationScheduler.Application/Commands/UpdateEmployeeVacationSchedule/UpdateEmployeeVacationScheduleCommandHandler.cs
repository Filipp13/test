﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using NHibernate.Linq;
using VacationScheduler.Application.Exceptions;
using VacationScheduler.Domain.Dto;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Exceptions;
using VacationScheduler.Domain.Services.PermissionService;
using VacationScheduler.Domain.Services.UserService;
using VacationScheduler.Domain.Validation.Applications;
using ViennaNET.Mediator;
using ViennaNET.Orm.Application;
using ViennaNET.Validation.Rules.ValidationResults;
using ViennaNET.Validation.Validators;

namespace VacationScheduler.Application.Commands.UpdateEmployeeVacationSchedule
{
    internal sealed class UpdateEmployeeVacationScheduleCommandHandler : IMessageHandlerAsync<UpdateEmployeeVacationScheduleCommand>
    {
        private readonly IEntityFactoryService _entityFactoryService;
        private readonly IValidator _validator;
        private readonly IUpdateEmployeeScheduleRuleSet _updateEmployeeScheduleRuleSet;
        private readonly IUserRepository _userRepository;
        private readonly IPermissionService _permissionService;

        public UpdateEmployeeVacationScheduleCommandHandler(IEntityFactoryService entityFactoryService,
            IValidator validator, IUpdateEmployeeScheduleRuleSet updateEmployeeScheduleRuleSet,
            IUserRepository userRepository, IPermissionService permissionService)
        {
            _entityFactoryService = entityFactoryService;
            _validator = validator;
            _updateEmployeeScheduleRuleSet = updateEmployeeScheduleRuleSet;
            _userRepository = userRepository;
            _permissionService = permissionService;
        }

        public async Task HandleAsync(UpdateEmployeeVacationScheduleCommand message, CancellationToken cancellationToken)
        {
            var user = await _userRepository.GetCurrentUserAsync();
            using var uow = _entityFactoryService.Create();

            var vacationSchedule = await _entityFactoryService
                .Create<VacationSchedule>()
                .Query()
                .FetchMany(schedule => schedule.EmployeesSchedules)
                .ThenFetchMany(e => e.ScheduledPeriods)
                .SingleOrDefaultAsync(e => e.Id == message.VacationScheduleId, cancellationToken);

            if (vacationSchedule == null)
            {
                throw new DbObjectNotFoundException(
                    $"Не найден график отпусков с Id = {message.VacationScheduleId}");
            }

            var employeeVacationSchedule =
                vacationSchedule.EmployeesSchedules.SingleOrDefault(v => v.Id == message.EmployeeVacationScheduleId);

            if (employeeVacationSchedule == null)
            {
                throw new DbObjectNotFoundException(
                    $"Не найден график отпусков сотрудника с Id = {message.EmployeeVacationScheduleId}");
            }

            var permissions = _permissionService.GetEmployeeScheduleActions(employeeVacationSchedule, user);
            if (!permissions.Contains(EmployeeScheduleAction.Edit))
            {
                throw new PermissionException(
                    $"User {user.Login} has no permission to update schedule " +
                    $"for employee {employeeVacationSchedule.EmployeeNumber} {employeeVacationSchedule.Fio}");
            }

            var updateEmployeeScheduleDto = new UpdateEmployeeScheduleDto
            {
                EmployeeVacationSchedule = employeeVacationSchedule,
                VacationPeriodDtos = message.ScheduledPeriods.Select(p => new Domain.Dto.VacationPeriodDto
                {
                    VacationPeriod = p,
                    ScheduleYear = vacationSchedule.Year
                }).ToList()
            };

            var validationResult = _validator.Validate(_updateEmployeeScheduleRuleSet, updateEmployeeScheduleDto, null);

            if (!validationResult.IsValid)
            {
                throw new EmployeeVacationScheduleValidationErrorException(validationResult.Results.ToErrorsString());
            }

            employeeVacationSchedule.ScheduledPeriods.Clear();

            foreach (var period in message.ScheduledPeriods)
            {
                employeeVacationSchedule.ScheduledPeriods.Add(new VacationPeriod
                {
                    From = period.From,
                    To = period.To,
                    Type = period.Type
                });
            }

            await uow.CommitAsync(cancellationToken);
        }
    }
}
