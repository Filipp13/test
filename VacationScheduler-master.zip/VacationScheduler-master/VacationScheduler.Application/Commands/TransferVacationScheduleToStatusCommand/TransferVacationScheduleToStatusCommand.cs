﻿using VacationScheduler.Domain.Enums;
using ViennaNET.Mediator;

namespace VacationScheduler.Application.Commands.TransferVacationScheduleToStatusCommand
{
    public class TransferVacationScheduleToStatusCommand : ICommand
    {
        public bool IsCompleted { get; set; }
        public object? Reason { get; set; }
        public int VacationScheduleId { get; set; }
        public ScheduleStatus DesiredStatus { get; set; }
    }
}
