﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using VacationScheduler.Application.Exceptions;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Domain.Services.PermissionService;
using VacationScheduler.Domain.Services.UserService;
using ViennaNET.Mediator;
using ViennaNET.Orm.Application;
// ReSharper disable StringLiteralTypo

namespace VacationScheduler.Application.Commands.TransferVacationScheduleToStatusCommand
{
    public class TransferVacationScheduleToStatusCommandHandler : IMessageHandlerAsync<TransferVacationScheduleToStatusCommand>
    {
        private readonly IEntityFactoryService _entityFactoryService;
        private readonly IPermissionService _permissionService;
        private readonly IUserRepository _userRepository;
        private readonly ILogger<TransferVacationScheduleToStatusCommandHandler> _logger;
        
        public TransferVacationScheduleToStatusCommandHandler(IEntityFactoryService entityFactoryService,
            IPermissionService permissionService, IUserRepository userRepository, ILogger<TransferVacationScheduleToStatusCommandHandler> logger)
        {
            _entityFactoryService = entityFactoryService;
            _permissionService = permissionService;
            _userRepository = userRepository;
            _logger = logger;
        }

        public async Task HandleAsync(TransferVacationScheduleToStatusCommand message, CancellationToken cancellationToken)
        {
            using var unitOfWork = _entityFactoryService.Create();
            var user = await _userRepository.GetCurrentUserAsync();

            var vacationSchedule = await _entityFactoryService.Create<VacationSchedule>().GetAsync(message.VacationScheduleId, cancellationToken);

            if (vacationSchedule == null)
            {
                throw new DbObjectNotFoundException($"График с VacationScheduleId - {message.VacationScheduleId} не найден в БД");
            }

            var actionForCurrentApplicationStatus = GetActionForCurrentVacationScheduleStatus(vacationSchedule.Status, message.DesiredStatus)
                ?? throw new TransferVacationScheduleException(
                    $"Для графика с VacationScheduleId - {message.VacationScheduleId} не разрешён переход из статуса {vacationSchedule.Status} в статус {message.DesiredStatus}");

            var vacationScheduleActions = _permissionService.GetVacationScheduleActions(vacationSchedule, user);
            if (!vacationScheduleActions.Contains(actionForCurrentApplicationStatus))
            {
                throw new PermissionException(
                    $"Нет прав для операции перехода графика с VacationScheduleId - {message.VacationScheduleId} из статуса {vacationSchedule.Status} в статус {message.DesiredStatus}");
            }

            switch (actionForCurrentApplicationStatus)
            {
                case VacationScheduleAction.ToFormation:
                    vacationSchedule.SetStatusFormation();
                    break;
                case VacationScheduleAction.ToManagerApprove:
                    vacationSchedule.SetStatusToManagerApprove();
                    break;
                case VacationScheduleAction.ToHrApprove:
                    vacationSchedule.SetStatusToHrApprove();
                    break;
                case VacationScheduleAction.Approve:
                    vacationSchedule.SetStatusApprove();
                    break;
                default:
                    throw new TransferVacationScheduleException($"Unknown action {actionForCurrentApplicationStatus}");
            }

            await unitOfWork.CommitAsync(cancellationToken);

            _logger.LogInformation("График {VacationScheduleId} переведен в статус {DesiredStatus}", message.VacationScheduleId, message.DesiredStatus);
        }

        private static VacationScheduleAction? GetActionForCurrentVacationScheduleStatus(ScheduleStatus currentStatus, ScheduleStatus desiredStatus) =>
            (currentStatus, desiredStatus) switch
            {
                (ScheduleStatus.Formation, ScheduleStatus.ManagerApprovement) => VacationScheduleAction.ToManagerApprove,
                (ScheduleStatus.ManagerApprovement, ScheduleStatus.HrApprovement) => VacationScheduleAction.ToHrApprove,
                (ScheduleStatus.HrApprovement, ScheduleStatus.Approved) => VacationScheduleAction.Approve,
                (ScheduleStatus.ManagerApprovement, ScheduleStatus.Formation) => VacationScheduleAction.ToFormation,
                _ => null
            };
    }
}
