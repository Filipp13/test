﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NHibernate.Linq;
using VacationScheduler.Application.Commands.BuildSchedules.ExternalContext;
using VacationScheduler.Application.Exceptions;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Domain.ValueObjects;
using ViennaNET.Mediator;
using ViennaNET.Orm.Application;
using ViennaNET.Orm.Seedwork;

namespace VacationScheduler.Application.Commands.BuildSchedules
{
    internal sealed class BuildSchedulesCommandHandler : IMessageHandlerAsync<BuildSchedulesCommand>
    {
        private readonly IEntityFactoryService _entityFactoryService;
        private readonly IExternalContextProvider _externalContextProvider;
        private readonly ILogger<BuildSchedulesCommandHandler> _logger;
        private const int AvailableDays = 28;

        public BuildSchedulesCommandHandler(IExternalContextProvider externalContextProvider,
            IEntityFactoryService entityFactoryService, ILogger<BuildSchedulesCommandHandler> logger)
        {
            _entityFactoryService = entityFactoryService;
            _externalContextProvider = externalContextProvider;
            _logger = logger;
        }

        public async Task HandleAsync(BuildSchedulesCommand message, CancellationToken cancellationToken)
        {
            using var unitOfWork = _entityFactoryService.Create();

            var scheduleRepository = _entityFactoryService.Create<VacationSchedule>();
            await ThrowIfVacationsScheduleAlreadyExists(message, cancellationToken, scheduleRepository);

            _logger.LogInformation("Get fresh data from external service...");
            var external = await _externalContextProvider.GetExternalContextAsync(cancellationToken);

            _logger.LogInformation("Building schedules for each department...");
            var departmentSchedulesById =
                external.AllDepartments.Select(e => MapExternalDepartmentToSchedule(e, message.ScheduleYear))
                    .ToDictionary(ds => ds.UnitId);

            var teamSchedulesByTeamId = external.AllTeams
                .Select(t => MapExternalTeamToSchedule(t, message.ScheduleYear))
                .ToDictionary(ts => ts.UnitId);

            var externalEmployeesWithDepartments = external.AllDepartments.SelectMany(department => department.Employees.Select(employee => (department, employee)));
            foreach (var employeeAndDepartment in externalEmployeesWithDepartments)
            {
                var isOts = external.IsEmployeeOts(employeeAndDepartment.employee);
                var isTeamMember = external.IsEmployeeMemberOfAgileTeam(employeeAndDepartment.employee);
                var isManyTeamMembers = isTeamMember && external.EmployeeIsMemberOfAgileTeams(employeeAndDepartment.employee).Count() > 1;

                if (isTeamMember && !isOts && !isManyTeamMembers)
                {
                    var employeeTeam = external.EmployeeIsMemberOfAgileTeams(employeeAndDepartment.employee).Single();
                    var teamSchedule = teamSchedulesByTeamId[employeeTeam.Id];

                    var schedule = MapExternalEmployeeToSchedule(employeeAndDepartment.employee, teamSchedule);
                    teamSchedule.EmployeesSchedules.Add(schedule);

                    continue;
                }

                var employeeDepartmentSchedule = departmentSchedulesById[employeeAndDepartment.department.Id];
                var employeeSchedule =
                    MapExternalEmployeeToSchedule(employeeAndDepartment.employee, employeeDepartmentSchedule);

                employeeDepartmentSchedule.EmployeesSchedules.Add(employeeSchedule);

                var teams = external.EmployeeIsOtsInTeams(employeeAndDepartment.employee)
                    .Concat(external.EmployeeIsMemberOfAgileTeams(employeeAndDepartment.employee))
                    .Distinct();
                
                foreach (var team in teams)
                {
                    var teamSchedule = teamSchedulesByTeamId[team.Id];
                    teamSchedule.EmployeesSchedulesForInformation.Add(employeeSchedule);
                }
            }
            
            foreach (var schedule in departmentSchedulesById.Values.Concat(teamSchedulesByTeamId.Values))
            {
                if (schedule.EmployeesSchedules.Any() || schedule.EmployeesSchedulesForInformation.Any())
                {
                    await scheduleRepository.InsertAsync(schedule, cancellationToken);
                }
            }

            _logger.LogInformation("Done, commiting...");
            await unitOfWork.CommitAsync(cancellationToken);
        }

        private static async Task ThrowIfVacationsScheduleAlreadyExists(BuildSchedulesCommand message,
            CancellationToken cancellationToken, IEntityRepository<VacationSchedule> scheduleRepository)
        {
            var hasScheduleForThisYear = await scheduleRepository.Query()
                .Where(vs => vs.Year == message.ScheduleYear)
                .AnyAsync(cancellationToken);
            if (hasScheduleForThisYear)
            {
                throw new ScheduleAlreadyExistsFoundException("There already are some schedules for this year");
            }
        }

        private static VacationSchedule MapExternalDepartmentToSchedule(ExternalDepartment department, int year) =>
            new VacationSchedule
            {
                Name = $"График отпусков \"{department.Name}\"",
                Year = year,
                Status = ScheduleStatus.Formation,
                UnitId = department.Id,
                UnitType = UnitType.Department,
                ResponsibleManagers = GetDepartmentManagers(department).Select(MapExternalEmployeeToManager)
                    .ToHashSet()
            };

        private VacationSchedule MapExternalTeamToSchedule(ExternalAgileTeam externalAgileTeam, int year) =>
            new VacationSchedule
            {
                Name = $"График отпусков команды \"{externalAgileTeam.Name}\"",
                Year = year,
                Status = ScheduleStatus.Formation,
                UnitId = externalAgileTeam.Id,
                UnitType = UnitType.Team,
                ResponsibleManagers = externalAgileTeam.Ots.Select(MapExternalEmployeeToManager).ToHashSet()
            };

        private static EmployeeVacationSchedule MapExternalEmployeeToSchedule(ExternalEmployee employee, VacationSchedule vacationSchedule) =>
            new EmployeeVacationSchedule
            {
                EmployeeNumber = employee.EmployeeNumber,
                EmployeeFirstName = employee.FirstName,
                EmployeeMiddleName = employee.MiddleName,
                EmployeeLastName = employee.LastName,
                EmployeeLogin = employee.Login,
                EmployeePosition = employee.Position,
                EmployeeRegion = employee.Region,
                EmployeeDirectorate = employee.Directorate,
                EmployeeDivision = employee.Division,
                EmployeeDepartment = employee.Department,
                EmployeeGroup = employee.Group,
                EmployeeSector = employee.Sector,
                Status = ScheduleStatus.Formation,
                AvailableDays = AvailableDays+employee.ExtraDays,
                EmployeeEmail = employee.Email,
                VacationSchedule = vacationSchedule
            };

        private static Manager MapExternalEmployeeToManager(ExternalEmployee employee) =>
            new Manager
            {
                // null forgiving: we hope that all of our managers have login and email
                Login = employee.Login!,
                EmployeeNumber = employee.EmployeeNumber,
                Fio = employee.Fio,
                Email = employee.Email!
            };

        private static IEnumerable<ExternalEmployee> GetDepartmentManagers(ExternalDepartment department)
        {
            if (department.AdminHead != null)
            {
                return new[] {department.AdminHead};
            }

            if (department.FuncHeads.Any())
            {
                return department.FuncHeads;
            }

            if (department.Parent == null)
            {
                return Enumerable.Empty<ExternalEmployee>();
            }

            return GetDepartmentManagers(department.Parent);
        }
    }
}
