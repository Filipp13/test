﻿using System.Collections.Generic;

namespace VacationScheduler.Application.Commands.BuildSchedules.ExternalContext
{
    public sealed class ExternalDepartment
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public IList<ExternalEmployee> Employees { get; set; } = new List<ExternalEmployee>();
        
        public ExternalEmployee? AdminHead { get; set; }

        public IList<ExternalEmployee> FuncHeads { get; set; } = new List<ExternalEmployee>();
        
        public ExternalDepartment? Parent { get; set; }

        public int ExtraDays { get; set; }
    }
}
