﻿using System.Collections.Generic;

namespace VacationScheduler.Application.Commands.BuildSchedules.ExternalContext
{
    public interface IExternalContext
    {
        ICollection<ExternalDepartment> AllDepartments { get; }
        
        ICollection<ExternalAgileTeam> AllTeams { get; }

        bool IsEmployeeOts(ExternalEmployee employee);
        
        IEnumerable<ExternalAgileTeam> EmployeeIsOtsInTeams(ExternalEmployee employee);
        
        bool IsEmployeeMemberOfAgileTeam(ExternalEmployee employee);
        
        IEnumerable<ExternalAgileTeam> EmployeeIsMemberOfAgileTeams(ExternalEmployee employee);
    }
}
