﻿namespace VacationScheduler.Application.Commands.BuildSchedules.ExternalContext
{
    public sealed class ExternalEmployee
    {
        /// <summary>
        /// Табельный номер
        /// </summary>
        public string EmployeeNumber { get; set; }

        /// <summary>
        /// Логин учётной записи в AD
        /// </summary>
        public string? Login { get; set; }

        /// <summary>
        /// Уникальный идентификатор пользователя в Boss Kadrovik	
        /// </summary>
        public int EmployeeId { get; set; }

        /// <summary>
        /// Фамилия на русском
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Имя на русском
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Отчество на русском
        /// </summary>
        public string? MiddleName { get; set; }

        public string Fio => $"{LastName} {FirstName} {MiddleName}".TrimEnd();

        /// <summary>
        /// Должность (рус.)
        /// </summary>
        public string Position { get; set; }

        /// <summary>
        /// Регион (рус.) Level - 1
        /// </summary>
        public string? Region { get; set; }

        /// <summary>
        /// Дирекция (рус.) Level - 2
        /// </summary>
        public string? Directorate { get; set; }

        /// <summary>
        /// Дивизион (рус.) Level - 3
        /// </summary>
        public string? Division { get; set; }

        /// <summary>
        /// Департамент (рус.) Level - 4
        /// </summary>
        public string? Department { get; set; }

        /// <summary>
        /// Группа (рус.) Level - 5
        /// </summary>
        public string? Group { get; set; }

        /// <summary>
        /// Сектор (рус.) Level - 6
        /// </summary>
        public string? Sector { get; set; }

        /// <summary>
        /// Адрес электронной почты
        /// </summary>
        public string? Email { get; set; }

        public int ExtraDays { get; set; }
    }
}
