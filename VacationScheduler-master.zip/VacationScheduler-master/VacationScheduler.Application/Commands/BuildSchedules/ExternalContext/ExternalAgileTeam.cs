﻿using System.Collections.Generic;
using System.Linq;

namespace VacationScheduler.Application.Commands.BuildSchedules.ExternalContext
{
    public sealed class ExternalAgileTeam
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public ISet<ExternalEmployee> Employees { get; set; }

        public ISet<ExternalEmployee> TechLeads { get; set; }
        
        public ISet<ExternalEmployee> Owners { get; set; }
        
        public ISet<ExternalEmployee> ScrumMasters { get; set; }

        public IEnumerable<ExternalEmployee> Ots => TechLeads.Concat(Owners).Concat(ScrumMasters).Distinct();
    }
}
