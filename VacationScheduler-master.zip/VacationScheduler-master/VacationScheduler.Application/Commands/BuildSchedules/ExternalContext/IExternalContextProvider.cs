﻿using System.Threading;
using System.Threading.Tasks;

namespace VacationScheduler.Application.Commands.BuildSchedules.ExternalContext
{
    public interface IExternalContextProvider
    {
        Task<IExternalContext> GetExternalContextAsync(CancellationToken cancellationToken);
    }
}
