﻿using ViennaNET.Mediator;

namespace VacationScheduler.Application.Commands.BuildSchedules
{
    public class BuildSchedulesCommand : ICommand
    {
        public bool IsCompleted { get; set; }

        public object Reason { get; set; }

        public int ScheduleYear { get; set; }
    }
}
