﻿using System.Collections.Generic;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Services.PermissionService;

namespace VacationScheduler.Application.Queries.GetSpecifiedVacationSchedule
{
    public class EmployeeScheduleItem
    {
        public List<EmployeeScheduleAction> Actions { get; set; }
        
        public EmployeeVacationSchedule EmployeeSchedule { get; set; }
    }
}
