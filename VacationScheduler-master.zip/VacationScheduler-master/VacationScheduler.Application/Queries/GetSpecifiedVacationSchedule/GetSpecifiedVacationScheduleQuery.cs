﻿using ViennaNET.Mediator;

namespace VacationScheduler.Application.Queries.GetSpecifiedVacationSchedule
{
    public sealed class GetSpecifiedVacationScheduleQuery : IRequest
    {
        public int VacationScheduleId { get; set; }
    }
}
