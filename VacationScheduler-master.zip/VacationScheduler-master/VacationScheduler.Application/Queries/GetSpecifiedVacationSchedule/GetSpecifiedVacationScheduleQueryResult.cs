﻿using System.Collections.Generic;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Enums;
using VacationScheduler.Domain.Services.PermissionService;
using VacationScheduler.Domain.Services.CalendarService;
using VacationScheduler.Domain.ValueObjects;

namespace VacationScheduler.Application.Queries.GetSpecifiedVacationSchedule
{
    public class GetSpecifiedVacationScheduleQueryResult
    {
        public int Id { get; set; }

        public ScheduleStatus Status { get; set; }

        public string Name { get; set; }

        public int Year { get; set; }

        public List<EmployeeScheduleItem> EmployeesSchedules { get; set; }

        public List<EmployeeVacationSchedule> EmployeesSchedulesForInformation { get; set; }

        public List<Manager> ResponsibleManagers { get; set; }

        public List<VacationScheduleAction> VacationScheduleActions { get; set; }

        public List<CalendarDate> HolidayDates { get; set; }
    }
}
