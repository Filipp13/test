﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using NHibernate.Linq;
using VacationScheduler.Application.Exceptions;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Services.CalendarService;
using VacationScheduler.Domain.Services.PermissionService;
using VacationScheduler.Domain.Services.UserService;
using ViennaNET.Mediator;
using ViennaNET.Orm.Seedwork;

namespace VacationScheduler.Application.Queries.GetSpecifiedVacationSchedule
{
    class GetSpecifiedVacationScheduleQueryHandler : IMessageHandlerAsync<GetSpecifiedVacationScheduleQuery,
        GetSpecifiedVacationScheduleQueryResult>
    {
        private readonly IEntityRepositoryFactory _entityRepositoryFactory;
        private readonly IUserRepository _userRepository;
        private readonly IPermissionService _permissionService;
        private readonly ICalendarService _calendarService;

        public GetSpecifiedVacationScheduleQueryHandler(IEntityRepositoryFactory entityRepositoryFactory,
            IUserRepository userRepository, IPermissionService permissionService, ICalendarService calendarService)
        {
            _entityRepositoryFactory = entityRepositoryFactory;
            _userRepository = userRepository;
            _permissionService = permissionService;
            _calendarService = calendarService;
        }

        public async Task<GetSpecifiedVacationScheduleQueryResult> HandleAsync(
            GetSpecifiedVacationScheduleQuery message,
            CancellationToken cancellationToken)
        {
            var user = await _userRepository.GetCurrentUserAsync();

            var vacationSchedule = await _entityRepositoryFactory.Create<VacationSchedule>()
                .Query()
                .FetchMany(vs => vs.EmployeesSchedules)
                .SingleOrDefaultAsync(vs => vs.Id == message.VacationScheduleId, cancellationToken);

            if (vacationSchedule == null)
            {
                throw new DbObjectNotFoundException($"Не найден график отпусков с Id = {message.VacationScheduleId}");
            }

            var employeeScheduleItems = vacationSchedule.EmployeesSchedules.Select(es => new EmployeeScheduleItem
            {
                EmployeeSchedule = es,
                Actions = _permissionService.GetEmployeeScheduleActions(es, user).ToList()
            }).ToList();

            var scheduleActions = _permissionService.GetVacationScheduleActions(vacationSchedule, user).ToList();

            var allHolidayDates = await _calendarService.GetHolidayDatesAsync(vacationSchedule.Year, cancellationToken);
            var calendarIdsInSchedule = vacationSchedule.EmployeesSchedules.Select(es => es.CalendarId)
                .Distinct()
                .ToHashSet();
            var holidayDatesForSchedule = allHolidayDates.Where(cd => calendarIdsInSchedule.Contains(cd.CalendarId)).ToList();

            return new GetSpecifiedVacationScheduleQueryResult
            {
                Id = vacationSchedule.Id,
                Name = vacationSchedule.Name,
                Status = vacationSchedule.Status,
                Year = vacationSchedule.Year,
                EmployeesSchedules = employeeScheduleItems,
                ResponsibleManagers = vacationSchedule.ResponsibleManagers.ToList(),
                EmployeesSchedulesForInformation = vacationSchedule.EmployeesSchedulesForInformation.ToList(),
                VacationScheduleActions = scheduleActions,
                HolidayDates = holidayDatesForSchedule
            };
        }
    }
}
