﻿using System.Collections.Generic;
using VacationScheduler.Domain.Entities;
using ViennaNET.Mediator;

namespace VacationScheduler.Application.Queries.ValidateEmployeeSchedule
{
    public sealed class ValidateEmployeeScheduleQuery : IRequest
    {
        public int VacationScheduleId { get; set; }

        public int EmployeeVacationScheduleId { get; set; }

        public List<VacationPeriod> ScheduledPeriods { get; set; }
    }
}
