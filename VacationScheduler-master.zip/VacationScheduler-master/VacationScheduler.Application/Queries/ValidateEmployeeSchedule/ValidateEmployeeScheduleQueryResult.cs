﻿using System.Collections.Generic;

namespace VacationScheduler.Application.Queries.ValidateEmployeeSchedule
{
    public sealed class ValidateEmployeeScheduleQueryResult
    {
        public bool IsValid { get; set; }

        public List<string> Errors { get; set; }
    }
}
