﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using NHibernate.Linq;
using VacationScheduler.Application.Exceptions;
using VacationScheduler.Domain.Dto;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Validation.Applications;
using ViennaNET.Mediator;
using ViennaNET.Orm.Application;
using ViennaNET.Validation.Validators;

namespace VacationScheduler.Application.Queries.ValidateEmployeeSchedule
{
    class ValidateEmployeeScheduleQueryHandler : IMessageHandlerAsync<ValidateEmployeeScheduleQuery,
        ValidateEmployeeScheduleQueryResult>
    {
        private readonly IEntityFactoryService _entityFactoryService;
        private readonly IValidator _validator;
        private readonly IUpdateEmployeeScheduleRuleSet _updateEmployeeScheduleRuleSet;

        public ValidateEmployeeScheduleQueryHandler(IEntityFactoryService entityFactoryService, IValidator validator,
            IUpdateEmployeeScheduleRuleSet updateEmployeeScheduleRuleSet)
        {
            _entityFactoryService = entityFactoryService;
            _validator = validator;
            _updateEmployeeScheduleRuleSet = updateEmployeeScheduleRuleSet;
        }

        public async Task<ValidateEmployeeScheduleQueryResult> HandleAsync(ValidateEmployeeScheduleQuery message,
            CancellationToken cancellationToken)
        {
            var vacationSchedule = await _entityFactoryService
                .Create<VacationSchedule>()
                .Query()
                .FetchMany(schedule => schedule.EmployeesSchedules)
                .ThenFetchMany(e => e.ScheduledPeriods)
                .SingleOrDefaultAsync(e => e.Id == message.VacationScheduleId, cancellationToken);

            if (vacationSchedule == null)
            {
                throw new DbObjectNotFoundException(
                    $"Не найден график отпусков с Id = {message.VacationScheduleId}");
            }

            var employeeVacationSchedule =
                vacationSchedule.EmployeesSchedules.SingleOrDefault(s => s.Id == message.EmployeeVacationScheduleId);

            if (employeeVacationSchedule == null)
            {
                throw new DbObjectNotFoundException(
                    $"Не найден график отпусков сотрудника с Id = {message.EmployeeVacationScheduleId}");
            }

            var updateEmployeeScheduleDto = new UpdateEmployeeScheduleDto
            {
                EmployeeVacationSchedule = employeeVacationSchedule,
                VacationPeriodDtos = message.ScheduledPeriods.Select(p => new VacationPeriodDto
                {
                    VacationPeriod = p,
                    ScheduleYear = vacationSchedule.Year
                }).ToList()
            };

            var validationResult = _validator.Validate(_updateEmployeeScheduleRuleSet, updateEmployeeScheduleDto, null);

            var errors = validationResult.Results.SelectMany(r => r.Messages.Select(m => m.Error)).ToList();

            return new ValidateEmployeeScheduleQueryResult { IsValid = validationResult.IsValid, Errors = errors };
        }
    }
}
