﻿using System.Collections.Generic;
using VacationScheduler.Domain.Entities;

namespace VacationScheduler.Application.Queries.GetAvailableSchedules
{
    public class GetAvailableSchedulesQueryResult
    {
        public VacationSchedule? MyOwnSchedule { get; set; }
        
        public List<VacationSchedule> ManagedSchedules { get; set; }
    }
}
