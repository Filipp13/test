﻿using ViennaNET.Mediator;

namespace VacationScheduler.Application.Queries.GetAvailableSchedules
{
    public class GetAvailableSchedulesQuery : IRequest
    {        
    }
}
