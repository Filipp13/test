﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using NHibernate.Linq;
using VacationScheduler.Domain.Entities;
using VacationScheduler.Domain.Services.UserService;
using ViennaNET.Mediator;
using ViennaNET.Orm.Seedwork;

namespace VacationScheduler.Application.Queries.GetAvailableSchedules
{
    public class GetAvailableSchedulesQueryHandler : IMessageHandlerAsync<GetAvailableSchedulesQuery, GetAvailableSchedulesQueryResult>
    {
        private readonly IEntityRepositoryFactory _entityRepositoryFactory;
        private readonly IUserRepository _userRepository;

        public GetAvailableSchedulesQueryHandler(IEntityRepositoryFactory entityRepositoryFactory,
            IUserRepository userRepository)
        {
            _entityRepositoryFactory = entityRepositoryFactory;
            _userRepository = userRepository;
        }

        public async Task<GetAvailableSchedulesQueryResult> HandleAsync(GetAvailableSchedulesQuery message,
            CancellationToken cancellationToken)
        {
            var user = await _userRepository.GetCurrentUserAsync();

            var schedulesRepository = _entityRepositoryFactory.Create<VacationSchedule>();

            var ownSchedules = await schedulesRepository.Query()
                .Where(vs => vs.EmployeesSchedules.Any(
                    evs => evs.EmployeeLogin == user.Login))
                .FetchMany(vs => vs.EmployeesSchedules)
                .ThenFetchMany(es => es.ScheduledPeriods)
                .ToListAsync(cancellationToken: cancellationToken);

            var latestOwnSchedule = ownSchedules.OrderBy(s => s.Year).LastOrDefault();

            var managedSchedules = await schedulesRepository.Query()
                .Where(vs => vs.ResponsibleManagers.Any(evs => evs.Login == user.Login))
                .FetchMany(vs => vs.EmployeesSchedules)
                .ThenFetchMany(es => es.ScheduledPeriods)
                .ToListAsync(cancellationToken);

            var employeeNumbersWhereHr = user.GetEmployeeNumbersWhereHr().ToArray();

            var hrSchedules = await schedulesRepository.Query()
                .Where(vs => vs.EmployeesSchedules
                    .Any(evs => employeeNumbersWhereHr.Contains(evs.EmployeeNumber)))
                .FetchMany(vs => vs.EmployeesSchedules)
                .ThenFetchMany(es => es.ScheduledPeriods)
                .ToListAsync(cancellationToken);

            return new GetAvailableSchedulesQueryResult()
            {
                MyOwnSchedule = latestOwnSchedule,
                ManagedSchedules = managedSchedules.Concat(hrSchedules)
                    .Except(ownSchedules)
                    .Distinct()
                    .ToList()
            };
        }
    }
}
