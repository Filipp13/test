﻿using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Home.Client.GraphQl
{
    [ExcludeFromCodeCoverage]
    internal static class GraphQlClient
    {
        public static async Task<T> GetResponse<T>(HttpClient client, CancellationToken cancellationToken)
            where T: class, IGraphQlQuerySpecified, new()
        {
            var query = new T().GraphQlQuery;
            using var response = await client.PostAsJsonAsync("", new GraphQlRequestDto(query), cancellationToken);
            response.EnsureSuccessStatusCode();
            
            var result = await response.Content.ReadAsAsync<GraphQlResponseDto<T>>(cancellationToken);

            if (result.Data != null)
            {
                return result.Data;
            }

            var responseContent = await response.Content.ReadAsStringAsync();
            throw new GraphQlClientException($"No data received, answer from service: {responseContent}");
        }
    }
}
