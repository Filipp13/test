﻿using System;
using System.Runtime.Serialization;

namespace Home.Client.GraphQl
{
    [Serializable]
    public class GraphQlClientException : Exception
    {
        public GraphQlClientException(string message) : base(message)
        {
        }

        protected GraphQlClientException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
