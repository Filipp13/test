﻿namespace Home.Client.GraphQl
{
    internal interface IGraphQlQuerySpecified {
        string GraphQlQuery { get; }
    }
}
