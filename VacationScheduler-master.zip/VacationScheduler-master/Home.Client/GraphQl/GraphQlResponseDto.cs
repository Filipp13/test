﻿namespace Home.Client.GraphQl
{
    internal sealed class GraphQlResponseDto<T> 
        where T: class
    {
        public T? Data { get; set; }
    }
}
