﻿using Newtonsoft.Json;

namespace Home.Client.GraphQl
{
    public sealed class GraphQlRequestDto
    {
        public GraphQlRequestDto(string query)
        {
            Query = query;
        }

        [JsonProperty(PropertyName = "query")]
        public string Query { get; }
    }
}
