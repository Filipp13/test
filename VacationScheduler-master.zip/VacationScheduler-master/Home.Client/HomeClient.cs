﻿using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Home.Client.Authentication;
using Home.Client.Dto;
using Home.Client.GraphQl;
using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace Home.Client
{
    internal sealed class HomeClient : IHomeClient
    {
        /// <summary>
        ///     Наименование клиента из настроек
        /// </summary>
        private const string ClientName = "homeGraphQl";

        private readonly IHttpClientFactory _clientFactory;
        private readonly IAuthenticationClient _authenticationClient;

        public HomeClient(IHttpClientFactory clientFactory, IAuthenticationClient authenticationClient)
        {
            _clientFactory = clientFactory;
            _authenticationClient = authenticationClient;
        }

        public async Task<List<TeamDto>> GetTeams(CancellationToken cancellationToken)
        {
            var client = GetClient(cancellationToken);

            var response =
                await GraphQlClient.GetResponse<GetTeamsResponse>(client, cancellationToken);

            return response.GetTeams;
        }

        private HttpClient GetClient(CancellationToken cancellationToken)
        {
            var client = _clientFactory.CreateClient(ClientName);
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(
                JwtBearerDefaults.AuthenticationScheme,
                GetToken(_authenticationClient, cancellationToken));
            return client;
        }

        private static string GetToken(IAuthenticationClient authenticationClient, CancellationToken cancellationToken)
        {
            return authenticationClient.GetToken(cancellationToken).Result;
        }
    }
}
