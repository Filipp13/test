﻿namespace Home.Client.Dto
{
    public sealed class DomainDto
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public ManagerDto? Cto { get; set; }
    }
}
