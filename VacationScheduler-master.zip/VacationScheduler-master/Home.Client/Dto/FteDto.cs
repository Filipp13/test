﻿using Newtonsoft.Json;

namespace Home.Client.Dto
{
    /// <summary>
    /// Ставка (fte)
    /// </summary>
    public sealed class FteDto
    {
        /// <summary>
        /// Тип fte
        /// </summary>
        [JsonProperty(PropertyName = "__typename")]
        public string Type { get; set; }

        public string EmployeeNumber { get; set; }

        public string? Login { get; set; }

        public string FullName { get; set; }
        
        /// <summary>
        /// Тип работы в команде:  ONE_TEAM, SEVERAL_TEAMS, NON_TEAM_ACTIVITY_EXISTS
        /// </summary>
        public string TeamsEngagement { get; set; }
    }
}
