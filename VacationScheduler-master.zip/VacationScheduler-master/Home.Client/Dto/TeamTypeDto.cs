﻿namespace Home.Client.Dto
{
    /// <summary>
    ///   Тип команды
    /// </summary>
    public sealed class TeamTypeDto
    {
        public int Id { get; set; }

        public string Name { get; set; }

        /// <summary>
        ///   Является ли данный тип команды сообществом
        /// </summary>
        public bool IsCommunity { get; set; }
    }
}
