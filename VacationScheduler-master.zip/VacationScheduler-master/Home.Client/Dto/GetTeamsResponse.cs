﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Home.Client.GraphQl;

namespace Home.Client.Dto
{
    [ExcludeFromCodeCoverage]
    internal sealed class GetTeamsResponse : IGraphQlQuerySpecified
    {
        public string GraphQlQuery { get; } = @"
            query {
              getTeams {
                id
                name
                description
                teamType {
                  id
                  name
                  isCommunity
                }
                domain {
                  id
                  name
                  cto {
                    login
                    employeeNumber
                  }
                }
                leaderRelations {
                  employee {
                    login
                    employeeNumber
                  }
                  role {
                    id
                    name
                  }
                }
                bMinusOne {
                  login
                  employeeNumber
                }
                customCto {
                  login
                  employeeNumber
                }
                fteTeamRelations {
                  fte {
                    __typename
                    ... on User {
                      employeeNumber
                      login
                      fullName
                      teamsEngagement
                    }
                  }
                  startDate
                  endDate
                }
              }
            }";

        public List<TeamDto> GetTeams { get; set; }
    }
}
