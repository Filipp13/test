﻿using System.Collections.Generic;

namespace Home.Client.Dto
{
    /// <summary>
    /// Команда
    /// </summary>
    public sealed class TeamDto
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public TeamTypeDto TeamType { get; set; }

        public DomainDto Domain { get; set; }

        public List<RelationDto> LeaderRelations { get; set; }

        public ManagerDto? BMinusOne { get; set; }
        
        public ManagerDto? CustomCto { get; set; }
        
        public List<FteTeamRelationDto> FteTeamRelations { get; set; }
    }
}
