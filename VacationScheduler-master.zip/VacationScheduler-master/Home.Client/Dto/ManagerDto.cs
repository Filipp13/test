﻿namespace Home.Client.Dto
{
    public sealed class ManagerDto
    {
        public string? Login { get; set; }

        public string EmployeeNumber { get; set; }
    }
}
