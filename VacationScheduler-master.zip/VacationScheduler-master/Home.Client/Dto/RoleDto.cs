﻿namespace Home.Client.Dto
{
    /// <summary>
    /// Роль
    /// </summary>
    public sealed class RoleDto
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
