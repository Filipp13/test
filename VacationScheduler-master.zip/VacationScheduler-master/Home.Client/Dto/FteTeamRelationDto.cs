﻿using System;

namespace Home.Client.Dto
{
    public sealed class FteTeamRelationDto
    {
        public FteDto Fte { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }
    }
}
