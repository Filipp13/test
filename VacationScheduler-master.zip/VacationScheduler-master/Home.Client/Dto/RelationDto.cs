﻿namespace Home.Client.Dto
{
    public sealed class RelationDto
    {
        public ManagerDto Employee { get; set; }

        public RoleDto Role { get; set; }
    }
}
