﻿using Home.Client.Authentication;
using SimpleInjector;
using SimpleInjector.Packaging;

namespace Home.Client
{
    public sealed class HomeClientPackage : IPackage
    {
        public void RegisterServices(Container container)
        {
            container.Register<IAuthenticationClient, AuthenticationClient>(Lifestyle.Singleton);
            container.Register<IHomeClient, HomeClient>(Lifestyle.Singleton);
        }
    }
}
