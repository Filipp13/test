﻿using System.Threading;
using System.Threading.Tasks;

namespace Home.Client.Authentication
{
    /// <summary>
    /// Клиент к сервису Home.Аутентификации 
    /// </summary>
    public interface IAuthenticationClient
    {
        /// <summary>
        /// Возвращает токен
        /// </summary>
        Task<string> GetToken(CancellationToken cancellationToken);
    }
}
