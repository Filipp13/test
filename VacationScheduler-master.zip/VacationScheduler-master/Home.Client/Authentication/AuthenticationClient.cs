﻿using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace Home.Client.Authentication
{
    [ExcludeFromCodeCoverage]
    internal sealed class AuthenticationClient : IAuthenticationClient
    {
        /// <summary>
        ///     Наименование клиента из настроек
        /// </summary>
        private const string ClientName = "homeAuthentication";

        /// <summary>
        /// Название секции с логином/паролем в конфигурации
        /// </summary>
        private const string homeClientCredentials = "homeClientCredentials";

        private readonly HttpClient _client;
        private readonly IConfiguration _configuration;

        public AuthenticationClient(IHttpClientFactory clientFactory, IConfiguration configuration)
        {
            _client = clientFactory.CreateClient(ClientName);
            _configuration = configuration;
        }

        public async Task<string> GetToken(CancellationToken cancellationToken)
        {
            const string url = "api/v1/authenticate";

            var authRequest = _configuration.GetSection(homeClientCredentials).Get<AuthRequest>();

            var data = JsonConvert.SerializeObject(authRequest);
            var content = new StringContent(data, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync(url, content, cancellationToken);
            response.EnsureSuccessStatusCode();

            var authenticationResult = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<AuthenticationResult>(authenticationResult).token;
        }
    }
}
