﻿namespace Home.Client.Authentication
{
    internal class AuthRequest
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}
