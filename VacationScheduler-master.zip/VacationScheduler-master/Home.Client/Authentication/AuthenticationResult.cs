﻿namespace Home.Client.Authentication
{
    internal class AuthenticationResult
    {
        public string token { get; set; }
    }
}
