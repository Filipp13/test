﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Home.Client.Dto;

namespace Home.Client
{
    /// <summary>
    /// Клиент к сервису Home
    /// </summary>
    public interface IHomeClient
    {
        /// <summary>
        /// Возвращает список команд
        /// </summary>
        Task<List<TeamDto>> GetTeams(CancellationToken cancellationToken);
    }
}
